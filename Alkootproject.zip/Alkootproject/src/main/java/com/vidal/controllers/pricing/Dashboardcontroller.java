package com.vidal.controllers.pricing;

import java.io.ByteArrayOutputStream;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;
import javax.validation.Valid;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRResultSetDataSource;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import oracle.jdbc.rowset.OracleCachedRowSet;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.reports.TTKReportDataSource;
import com.vidal.command.common.CacheObject;
import com.vidal.command.pricing.DashboardVO;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.PolicyGroupVO;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.controller.vidalcontroller.VidalController;
import com.vidal.controllers.table.TableData;
import com.vidal.services.authentication.DashboardGeneralService;


@Controller
@RequestMapping("PricingDashboard")
public class Dashboardcontroller extends VidalController{
	private static Logger logger = Logger.getLogger(Dashboardcontroller.class );
	
	private static final String strPricingDashBoard="pricing.dashboard";
	private static final String strForward = "Forward";
	private static final String strBackward = "Backward";
	private static final String strPricingDashBoardDelete = "Delete";
	private static final String strGroupPricing = "groupPricing";
	private static final String strReportdisplay="/binaryFile";
	
	

	
	
	
	
	@RequestMapping(value ={"doDefault"})
	public ModelAndView doDefault(@Valid @ModelAttribute("DashboardVO") DashboardVO dashboardVO, HttpServletRequest request,HttpServletResponse response,Model model,BindingResult bindingResult)throws Exception{
	
		ModelAndView modelAndView = new ModelAndView(strPricingDashBoard);
	try{
		
		String[] identfierList = new String[] {"renewal","clientCodeList"}; 
		populateData(identfierList, "renewalDropdowns");
		TableData tableDataLog = new TableData();
		
		//create the required grid table
		tableDataLog.createTableInfo("SwInsurancePricingTable",new ArrayList());
		request.getSession().setAttribute("tableDataLog",tableDataLog);   
		modelAndView.addObject("DashboardVO", new DashboardVO());
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile");
		userAccessSecurityProfile.getSecurityProfile().setDefaultActiveLink();
		return modelAndView;
	}catch(Throwable throwable){
		return processErrorView(strPricingDashBoard, throwable);
	}
	
}
	
	
	@RequestMapping(value ={"Search"}, method = RequestMethod.POST)
	public ModelAndView doSearchPricing(@ModelAttribute("DashboardVO") DashboardVO dashboardVO,  HttpServletRequest request,HttpServletResponse response,Model model)throws Exception
	{
		ModelAndView modelAndView = new ModelAndView(strPricingDashBoard);
	     String acceptedYN =	request.getParameter("invsMYN");
	
		try{
		TableData tableDataLog=null;
		String ini = UXUtility.checkNull(dashboardVO.getPricinginitiateddate().trim());
		String cov = UXUtility.checkNull(dashboardVO.getCoveragestartdate().trim());
		
		
		
		request.setAttribute("pricingintiatedate",ini);
		request.setAttribute("coveragrestartdate",cov);
	   
		request.getSession().removeAttribute("approvedYN");
		request.getSession().removeAttribute("pendingYN");
		request.getSession().removeAttribute("rejectYN");
		String[] identfierList = new String[] {"renewal"}; 
		populateData(identfierList, "renewalDropdowns");
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile");
		if((request.getSession()).getAttribute("tableDataLog") == null)
		{
			tableDataLog = new TableData();
		}
		else
		{
			tableDataLog = (TableData)(request.getSession()).getAttribute("tableDataLog");
		}
		
		
		
			String strPageID = UXUtility.checkNull(request.getParameter("pageId"));
			String strSortID = UXUtility.checkNull(request.getParameter("sortId"));
				DashboardVO supportVo=new DashboardVO();
			if (!strPageID.equals("") || !strSortID.equals("")) {
				if (!strPageID.equals("")) {
					tableDataLog.setCurrentPage(Integer.parseInt(UXUtility.checkNull(request.getParameter("pageId"))));
					long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();
					
					
					if (tableDataLog != null) {
						ArrayList alObject = tableDataLog.getData() == null ? (new ArrayList()) : tableDataLog.getData();
					}
					modelAndView.addObject("DashboardVO", supportVo);

					return modelAndView;
				} else {
					tableDataLog.setSortData(UXUtility.checkNull(request.getParameter("sortId")));
					tableDataLog.modifySearchData("sort");
				}
			} else {
				tableDataLog.createTableInfo("SwInsurancePricingTable", null);
					tableDataLog.setSearchData(this.populateSearchCriteria((dashboardVO),request));
				//	tableDataLog.setSortData("0001");
					tableDataLog.setSortOrder("DESC");
			
				tableDataLog.modifySearchData("search");
			}
			// userAccessSecurityProfile.getWorkFlowMap();
			
			long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();
			Object[] results=DashboardGeneralService.getSwInsuranceProfileList(tableDataLog.getSearchData());
		
			ArrayList<Object> alSearchData=(ArrayList<Object>)results[0];
			//modelAndView.addObject("pendingApproval",results[1]);
			request.getSession().setAttribute("pendingApproval", results[1]);
			request.getSession().setAttribute("pendingApproval", request.getSession().getAttribute("pendingApproval"));
			
			
		/*	if(request.getParameter("pricingintiatedate")!=null){
				
				dashboardVO.setPricinginitiateddate(request.getParameter("pricingintiatedate"));
			}
			if(request.getParameter("coveragrestartdate")!=null){
				dashboardVO.setCoveragestartdate(request.getParameter("coveragrestartdate"));
			}*/
			
			tableDataLog.setData(alSearchData,"search");
			request.getSession().setAttribute("tableDataLog",tableDataLog);  
			modelAndView.addObject("DashboardVO", dashboardVO);
			return modelAndView;    
		}catch(Throwable throwable){
			return processErrorView(strPricingDashBoard, throwable);

		}

		
	}
	

    private ArrayList<Object> populateSearchCriteria(DashboardVO frmSwPricingHome,
			HttpServletRequest request)throws Exception
	{
		//build the column names along with their values to be searched
		ArrayList<Object> alSearchParams = new ArrayList<Object>();
	
	alSearchParams.add(UXUtility.checkNull(frmSwPricingHome.getPricingRefno().trim()));
		alSearchParams.add(UXUtility.checkNull(frmSwPricingHome.getPreviousPolicyNo().trim()));
		alSearchParams.add(UXUtility.checkNull(frmSwPricingHome.getClientCode().trim()));
		alSearchParams.add(UXUtility.checkNull(frmSwPricingHome.getCorporatename().trim()));
	
		alSearchParams.add(UXUtility.checkNull(frmSwPricingHome.getClientType().trim()));
		alSearchParams.add(UXUtility.checkNull(frmSwPricingHome.getPricinginitiateddate().trim()));
		alSearchParams.add(UXUtility.checkNull(frmSwPricingHome.getCoveragestartdate().trim()));
		alSearchParams.add(UXUtility.checkNull(frmSwPricingHome.getBrokername().trim()));
		
		
		
		
		if("Y".equals(request.getParameter("pendingApprovalYN").trim())){
			alSearchParams.add("Y");
		}else{
			alSearchParams.add("N");
		}
       if((frmSwPricingHome.getApprovedYN() !=null) && ("Y".equals(frmSwPricingHome.getApprovedYN()))){
    	 
    	   alSearchParams.add(frmSwPricingHome.getApprovedYN());
		}else{
			alSearchParams.add("N");
		}
		
       if((frmSwPricingHome.getPendingYN() !=null) && ("Y".equals(frmSwPricingHome.getPendingYN()))){
		
    	  
			alSearchParams.add(frmSwPricingHome.getPendingYN());
		}else{
			alSearchParams.add("N");
		}
       if((frmSwPricingHome.getRejectYN() !=null) && ("Y".equals(frmSwPricingHome.getRejectYN()))){
	
    	
			alSearchParams.add(frmSwPricingHome.getRejectYN());
		}else{
			alSearchParams.add("N");
		}
	
		alSearchParams.add(frmSwPricingHome.getSubsearch().trim());
    	return alSearchParams;
	}

	@RequestMapping(value ="forwardpricingsearch", method = RequestMethod.POST)
	public ModelAndView doForward(@ModelAttribute("DashboardVO") DashboardVO dashboardVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
	try{
    	ModelAndView modelAndView = new ModelAndView(strPricingDashBoard);
		setErrorPageData(strPricingDashBoard, model);
		// get the table data from session if exists
		TableData tableDataLog=null;
		if ((request.getSession()).getAttribute("tableDataLog") != null) {
			tableDataLog = (TableData)(request.getSession()).getAttribute("tableDataLog");
		} // end of if((request.getSession()).getAttribute("policyListData") != null)
		else {
			tableDataLog = new TableData();
		} // end of else

		tableDataLog.modifySearchData(strForward);
		// call the DAO to get the records
		Object[] results=DashboardGeneralService.getSwInsuranceProfileList(tableDataLog.getSearchData());
		
		ArrayList<Object> alSearchData=(ArrayList<Object>)results[0];
		modelAndView.addObject("pendingApproval",results[1]);
		tableDataLog.setData(alSearchData, strForward);
		/*long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();*/
		
		

		request.getSession().setAttribute("tableDataLog", tableDataLog);
		//supportVo.setStrTotalSupportCount(alLogList.size());
		//tableDataLog.setData(alLogList,"search");
		return modelAndView;
    	
	}catch(Throwable throwable){
		return processErrorView(strPricingDashBoard, throwable);

	}

	
}
	@RequestMapping(value ="backwardpricingsearch", method = RequestMethod.POST)
	public ModelAndView doBackward(@ModelAttribute("DashboardVO") DashboardVO dashboardVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {

    	ModelAndView modelAndView = new ModelAndView(strPricingDashBoard);
		try{

		setErrorPageData(strPricingDashBoard, model);
		// get the table data from session if exists
		TableData tableDataLog=null;
		if ((request.getSession()).getAttribute("tableDataLog") != null) {
			
			tableDataLog = (TableData)(request.getSession()).getAttribute("tableDataLog");
		} // end of if((request.getSession()).getAttribute("policyListData") != null)
		else {
			tableDataLog = new TableData();
		} // end of else

		tableDataLog.modifySearchData(strBackward);
		// call the DAO to get the records
		Object[] results=DashboardGeneralService.getSwInsuranceProfileList(tableDataLog.getSearchData());
		
		ArrayList<Object> alSearchData=(ArrayList<Object>)results[0];
		modelAndView.addObject("pendingApproval",results[1]);
		tableDataLog.setData(alSearchData, strBackward);
		/*long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();*/
		request.getSession().setAttribute("tableDataLog", tableDataLog);
		return modelAndView;
		}catch(Throwable throwable){
			return processErrorView(strPricingDashBoard, throwable);

		}

		
	}
	
	@RequestMapping(value ="doDelete", method = RequestMethod.POST)
	public ModelAndView dodoDelete(@ModelAttribute("DashboardVO") DashboardVO dashboardVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		try{
		Long groupseqId;
		String pricingnumber;
		ModelAndView modelAndView = new ModelAndView(strPricingDashBoardDelete);
		TableData tableDataLog =(TableData)request.getSession().getAttribute("tableDataLog");
		groupseqId=((DashboardVO)(tableDataLog).getData().get(Integer.parseInt(request.getParameter("rownum")))).getGroupProfileSeqID();
		pricingnumber=((DashboardVO)(tableDataLog).getData().get(Integer.parseInt(request.getParameter("rownum")))).getPricingRefno();
		request.setAttribute("pricingnumber", pricingnumber);
        request.setAttribute("delete", "Y");
		request.setAttribute("groupseqId", groupseqId);
         return modelAndView;
    	
	}catch(Throwable throwable){
		return processErrorView(strPricingDashBoardDelete, throwable);

	}
	}
	
	@RequestMapping(value ="doDeleteSave", method = RequestMethod.POST)
	public ModelAndView dodoDeleteSave(@ModelAttribute("DashboardVO") DashboardVO dashboardVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model,BindingResult bindingResult) throws Exception {
		try{
		Long groupseqId;
		ModelAndView modelAndView = new ModelAndView(strPricingDashBoardDelete);
		String userid=request.getParameter("groupseqId");
		Long UserSeqid=Long.valueOf(userid);
		String pricingnumber=request.getParameter("pricingnumber");
		
		Long userId=Long.valueOf(VidalCommon.getUserSeqId(request));
		ArrayList Delet=new ArrayList();
		Delet.add(UserSeqid);
		Delet.add(dashboardVO.getComments());
		Delet.add(userId);
		Delet.add(pricingnumber);
	
		
		
	int delete=	DashboardGeneralService.getDelete(Delet);
	if(delete>0){
		modelAndView = new ModelAndView(strPricingDashBoard);
		TableData tableDataLog=null;
		if((request.getSession()).getAttribute("tableDataLog") == null)
		{
			tableDataLog = new TableData();
		}
		else
		{
			tableDataLog = (TableData)(request.getSession()).getAttribute("tableDataLog");
		}
		
		Object[] results=DashboardGeneralService.getSwInsuranceProfileList(tableDataLog.getSearchData());
		
		ArrayList<Object> alSearchData=(ArrayList<Object>)results[0];
		//modelAndView.addObject("pendingApproval",results[1]);
		request.getSession().setAttribute("pendingApproval", results[1]);
		tableDataLog.setData(alSearchData,"search");
		request.getSession().setAttribute("tableDataLog",tableDataLog);   
		
	}
	
		return modelAndView;
    	
		}catch(Throwable throwable){
			return processErrorView(strPricingDashBoardDelete, throwable);

		}
	}
	@RequestMapping(value ="doBack", method = RequestMethod.POST)
	public ModelAndView doBackscreen(@ModelAttribute("DashboardVO") DashboardVO dashboardVO, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model,BindingResult bindingResult) throws Exception {
		ModelAndView modelAndView = new ModelAndView(strPricingDashBoardDelete);
		try{
			modelAndView = new ModelAndView(strPricingDashBoard);
			TableData tableDataLog=null;
			if((request.getSession()).getAttribute("tableDataLog") == null)
			{
				tableDataLog = new TableData();
			}
			else
			{
				tableDataLog = (TableData)(request.getSession()).getAttribute("tableDataLog");
			}
			
			Object[] results=DashboardGeneralService.getSwInsuranceProfileList(tableDataLog.getSearchData());
			
			ArrayList<Object> alSearchData=(ArrayList<Object>)results[0];
			//modelAndView.addObject("pendingApproval",results[1]);
			request.getSession().setAttribute("pendingApproval", results[1]);
			tableDataLog.setData(alSearchData,"search");
			request.getSession().setAttribute("tableDataLog",tableDataLog);   
			
		
		
			return modelAndView;
			
			
		}catch(Throwable throwable){
			return processErrorView(strPricingDashBoardDelete, throwable);

		}
	}
	
	
	
	@RequestMapping(value = {"getClientNamegroup"},method={RequestMethod.GET})
	public @ResponseBody String  getGroupName(@RequestParam("clientCode") String clientCode, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		
		  String clientName="";					  
		try {
			clientName =DashboardGeneralService.getClientName(clientCode);	
			request.getSession().setAttribute("groupPricingProducName",clientName);
		}catch(Exception e) {
			clientName="";
			e.printStackTrace();			
		}		     				
		  return clientName;		 
	}
	
	@RequestMapping(value = {"getFeatchFlag"},method={RequestMethod.GET})
	public @ResponseBody String getFetchFlag(@RequestParam("fetchseqId") String fetchseqId, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		
		  String fetchFalg="";					  
		try {
			
			fetchFalg =	DashboardGeneralService.getFetchFlag(fetchseqId);
		}catch(Exception e) {
			fetchFalg="false";
			e.printStackTrace();			
		}		     				
		  return fetchFalg;		 
	}
	
	@RequestMapping(value = {"selectGroupPricingClientName"},method={RequestMethod.GET})
	public @ResponseBody String  selectGroupPricngClientList(@RequestParam("rownum") String rownum, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		
		  String clientName="";	
		  TableData politableData = null;
		try {
			
			
			
			if ((request.getSession()).getAttribute("politableData") != null) {
				politableData = (TableData) (request.getSession()).getAttribute("politableData");
			
				if (!(UXUtility.checkNull(request.getParameter("rownum")).equals(""))) {
					
					PolicyGroupVO  policiGroupVo = (PolicyGroupVO) politableData.getRowInfo(Integer.parseInt(rownum));
					
												
					clientName = policiGroupVo.getGroupRegnSeqID() + "~" + policiGroupVo.getGroupName();
					request.getSession().setAttribute("groupPricingProducName",policiGroupVo.getGroupName());
					
				}
			}	
						
		}catch(Exception e) {
			clientName="";
			e.printStackTrace();			
		}		     				
		  return clientName;		 
	}
	
	
	
	@RequestMapping(value = {"serchGroupPricing"},method={RequestMethod.GET})
	public @ResponseBody String  serchGroupPricing(@RequestParam("clientCode") String clientCode,@RequestParam("clientName") String clientName,@RequestParam("startDate") String startDate,@RequestParam("endDate") String endDate, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		
		
		 ArrayList<InsPricingVO> groupList = new ArrayList<>();
		 
		 ArrayList searchList = new ArrayList();
		 
		 /*   String sDate1="20/08/2019";  
		    String sDate2 ="25/08/2019";*/
		    Date startD=new SimpleDateFormat("dd/MM/yyyy").parse(startDate);
		    Date endD=new SimpleDateFormat("dd/MM/yyyy").parse(endDate);
		 
		 searchList.add(clientCode.trim());
		 searchList.add(clientName);
		 searchList.add(startD);
		 searchList.add(endD);
		 
		StringBuilder sb = new  StringBuilder();		 			  
		try {
			groupList  = DashboardGeneralService.groupList(searchList);
			
			
			if(groupList !=null && groupList.size() > 0) {
				
				int count=0;
				for(InsPricingVO ins:groupList) {				
					sb.append("<div class=\"vd-form-control pl-4\">");
					sb.append("<div class=\"checkbox checkbox-primary\">");
					sb.append("<input id=\"groupPricing["+count+"]\" class=\"styled groupCheckClass\" type=\"checkbox\" />");	
					sb.append("<label for=\"groupPricing["+count+"]\" onclick=\"oncheck('"+count+"');\">");
					sb.append("<input type=\"hidden\" id=\"groupProSeqId["+count+"]\" value=\""+ins.getGroupProfileSeqID()+"\">");
					sb.append("<input type=\"hidden\" class=\"statusClass\"  id=\"groupSelectionId["+count+"]\" value=\""+ins.getGroupSelectionNo()+"\">");
					sb.append("<span class=\"main-label\">"+ins.getGroupRefNo()+"</span>");					
					sb.append("<span class=\"vd-badge-default ml-1\">"+ins.getGroupStatus()+"</span>");
					sb.append("<span class=\"hint-sub\">"+ins.getGroupiniatedDate()+"</span> ");
					sb.append("<span class=\"hint-sub\">"+ins.getGroupProductName()+"</span> ");
					sb.append(" </label>");
					sb.append("<input type=\"hidden\" id=\"checkSize\" value=\""+groupList.size()+"\">");
					sb.append(" </div>");
					sb.append("</div>");
					
					count ++;
				}
				
				
			}else {
				
				sb.append("<div class=\"vd-form-control pl-12\">");
				sb.append("<div class=\"checkbox checkbox-primary\">");
				sb.append("<span class=\"vd-badge-default ml-1\"><b>No Data Found</b></span>");
				sb.append("<input type=\"hidden\" id=\"checkSize\" value=\""+groupList.size()+"\">");
				sb.append(" </div>");
				sb.append("</div>");
			}
			
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}		     				
		  return sb.toString();		 
	}
	
	@RequestMapping(value ="groupPricingDisplay" , method = RequestMethod.POST)
	public ModelAndView groupPricing(HttpServletRequest request,@RequestParam("groupPricing") String groupSeqId ,Model model) throws Exception{		
		setLinks(request);		
		
		
		
		
	/*	groupSeqId ="||760||121||"; */
		
		ModelAndView modelAndView = new ModelAndView(strGroupPricing);
		setErrorPageData(strGroupPricing, model);			
         
		
		modelAndView.addObject("pricingList",groupSeqId);
	//	ArrayList groupPricingList = DashboardGeneralService.getGroupPricingDisplayList("||115||116||120||121||122||123||");	
		ArrayList groupPricingList = DashboardGeneralService.getGroupPricingDisplayList(0l,groupSeqId);		
		request.getSession().setAttribute("groupPricingSeqId","");
		request.getSession().setAttribute("groupPricingRefNo","");
		
	/*	ArrayList<InsPricingVO> list = (ArrayList<InsPricingVO>)groupPricingList.get(0);	
		ArrayList<InsPricingVO> list1 =(ArrayList<InsPricingVO>)groupPricingList.get(1);
		ArrayList<InsPricingVO> list2 =(ArrayList<InsPricingVO>)groupPricingList.get(2);
		ArrayList<InsPricingVO> list3=(ArrayList<InsPricingVO>)groupPricingList.get(3);
		ArrayList<InsPricingVO> list4=(ArrayList<InsPricingVO>)groupPricingList.get(4);
		ArrayList<InsPricingVO> list5=(ArrayList<InsPricingVO>)groupPricingList.get(5);
		ArrayList<InsPricingVO> list6=(ArrayList<InsPricingVO>)groupPricingList.get(6);
		ArrayList<InsPricingVO> list7=(ArrayList<InsPricingVO>)groupPricingList.get(7);
		ArrayList<InsPricingVO> list38=(ArrayList<InsPricingVO>)groupPricingList.get(7);
		ArrayList<InsPricingVO> list9=(ArrayList<InsPricingVO>)groupPricingList.get(9);
		ArrayList<InsPricingVO> list10=(ArrayList<InsPricingVO>)groupPricingList.get(10);
		*/
		
		/*ArrayList<InsPricingVO> listpro1=(ArrayList<InsPricingVO>)groupPricingList.get(11);
		
		ArrayList<InsPricingVO> listoPtical =(ArrayList<InsPricingVO>) groupPricingList.get(12); */
		
		
		
		
	
		
	
		request.setAttribute("groupPricingList",(ArrayList<InsPricingVO>)groupPricingList.get(0));
		request.setAttribute("groupPricingList1",(ArrayList<InsPricingVO>)groupPricingList.get(1));
		request.setAttribute("groupPricingList2",(ArrayList<InsPricingVO>)groupPricingList.get(2));
		request.setAttribute("groupPricingList3",(ArrayList<InsPricingVO>)groupPricingList.get(3));
		request.setAttribute("groupPricingList4",(ArrayList<InsPricingVO>)groupPricingList.get(4));
		request.setAttribute("groupPricingList5",(ArrayList<InsPricingVO>)groupPricingList.get(5));
		request.setAttribute("groupPricingList6",(ArrayList<InsPricingVO>)groupPricingList.get(6));
		request.setAttribute("groupPricingList7",(ArrayList<InsPricingVO>)groupPricingList.get(7));
		request.setAttribute("groupPricingList8",(ArrayList<InsPricingVO>)groupPricingList.get(8));
		request.setAttribute("groupPricingList9",(ArrayList<InsPricingVO>)groupPricingList.get(9));
		request.setAttribute("groupPricingList10",(ArrayList<InsPricingVO>)groupPricingList.get(10));	
		
		/*request.getSession().setAttribute("groupPricingList",(ArrayList<InsPricingVO>)groupPricingList.get(0));
		request.getSession().setAttribute("groupPricingList1",(ArrayList<InsPricingVO>)groupPricingList.get(1));
		request.getSession().setAttribute("groupPricingList2",(ArrayList<InsPricingVO>)groupPricingList.get(2));
		request.getSession().setAttribute("groupPricingList3",(ArrayList<InsPricingVO>)groupPricingList.get(3));
		request.getSession().setAttribute("groupPricingList4",(ArrayList<InsPricingVO>)groupPricingList.get(4));
		request.getSession().setAttribute("groupPricingList5",(ArrayList<InsPricingVO>)groupPricingList.get(5));
		request.getSession().setAttribute("groupPricingList6",(ArrayList<InsPricingVO>)groupPricingList.get(6));
		request.getSession().setAttribute("groupPricingList7",(ArrayList<InsPricingVO>)groupPricingList.get(7));
		request.getSession().setAttribute("groupPricingList8",(ArrayList<InsPricingVO>)groupPricingList.get(8));
		request.getSession().setAttribute("groupPricingList9",(ArrayList<InsPricingVO>)groupPricingList.get(9));
		request.getSession().setAttribute("groupPricingList10",(ArrayList<InsPricingVO>)groupPricingList.get(10));	*/
		
	
		
		
		
		
	/*	request.setAttribute("groupPricingProviderList1",(ArrayList<InsPricingVO>)groupPricingList.get(11));
		request.setAttribute("groupPricingProviderList2",(ArrayList<InsPricingVO>)groupPricingList.get(12));
		request.setAttribute("groupPricingProviderList3",(ArrayList<InsPricingVO>)groupPricingList.get(13));
		request.setAttribute("groupPricingProviderList4",(ArrayList<InsPricingVO>)groupPricingList.get(14));
		request.setAttribute("groupPricingProviderList5",(ArrayList<InsPricingVO>)groupPricingList.get(15));
		request.setAttribute("groupPricingProviderList6",(ArrayList<InsPricingVO>)groupPricingList.get(16));
		request.setAttribute("groupPricingProviderList7",(ArrayList<InsPricingVO>)groupPricingList.get(17));
		request.setAttribute("groupPricingProviderList8",(ArrayList<InsPricingVO>)groupPricingList.get(18));
		request.setAttribute("groupPricingProviderList9",(ArrayList<InsPricingVO>)groupPricingList.get(19));
		request.setAttribute("groupPricingProviderList10",(ArrayList<InsPricingVO>)groupPricingList.get(20));*/
	
		
		/*request.setAttribute("groupPricingOpticalList1",(ArrayList<InsPricingVO>)groupPricingList.get(21));
		request.setAttribute("groupPricingOpticalList2",(ArrayList<InsPricingVO>)groupPricingList.get(22));
		request.setAttribute("groupPricingOpticalList3",(ArrayList<InsPricingVO>)groupPricingList.get(23));
		request.setAttribute("groupPricingOpticalList4",(ArrayList<InsPricingVO>)groupPricingList.get(24));
		request.setAttribute("groupPricingOpticalList5",(ArrayList<InsPricingVO>)groupPricingList.get(25));
		request.setAttribute("groupPricingOpticalList6",(ArrayList<InsPricingVO>)groupPricingList.get(26));
		request.setAttribute("groupPricingOpticalList7",(ArrayList<InsPricingVO>)groupPricingList.get(27));
		request.setAttribute("groupPricingOpticalList8",(ArrayList<InsPricingVO>)groupPricingList.get(28));
		request.setAttribute("groupPricingOpticalList9",(ArrayList<InsPricingVO>)groupPricingList.get(29));
		request.setAttribute("groupPricingOpticalList10",(ArrayList<InsPricingVO>)groupPricingList.get(30));*/
		
		
		/*request.setAttribute("groupPricingOtherList1",(ArrayList<InsPricingVO>)groupPricingList.get(31));
		request.setAttribute("groupPricingOtherList2",(ArrayList<InsPricingVO>)groupPricingList.get(32));
		request.setAttribute("groupPricingOtherList3",(ArrayList<InsPricingVO>)groupPricingList.get(33));
		request.setAttribute("groupPricingOtherList4",(ArrayList<InsPricingVO>)groupPricingList.get(34));
		request.setAttribute("groupPricingOtherList5",(ArrayList<InsPricingVO>)groupPricingList.get(35));
		request.setAttribute("groupPricingOtherList6",(ArrayList<InsPricingVO>)groupPricingList.get(36));
		request.setAttribute("groupPricingOtherList7",(ArrayList<InsPricingVO>)groupPricingList.get(37));
		request.setAttribute("groupPricingOtherList8",(ArrayList<InsPricingVO>)groupPricingList.get(38));
		request.setAttribute("groupPricingOtherList9",(ArrayList<InsPricingVO>)groupPricingList.get(39));
		request.setAttribute("groupPricingOtherList10",(ArrayList<InsPricingVO>)groupPricingList.get(40));*/
		
		request.setAttribute("grossPremiumMemberGroupLevel",(InsPricingVO)groupPricingList.get(11));
		
		request.setAttribute("policyDuration",(InsPricingVO)groupPricingList.get(12));
		
		
		request.setAttribute("exprienceSummery",(ArrayList<InsPricingVO>)groupPricingList.get(13));
		
		 request.getSession().setAttribute("editflag","Y");
													
		
		
//		request.setAttribute("groupPricingList1",list1);
		/*modelAndView.addObject("groupPricingList",list);*/
		
		return modelAndView;
	}
	
	
	@RequestMapping(value ="groupPricingSave" , method = RequestMethod.POST)
	public ModelAndView groupPricingSave(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,HttpServletRequest request,Model model,BindingResult result) throws Exception{								
		setLinks(request);		
		
		ModelAndView modelAndView = new ModelAndView(strGroupPricing);
		 setErrorPageData(strGroupPricing, model);
	
           if(result.hasErrors()){				
			return modelAndView;
		}		
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();	
			
		modelAndView.addObject("pricingList",insPricingVO.getPricingList());
		if(insPricingVO.getGroupProfilePricingSeqid() == null) {
		
		InsPricingVO insPricingVO1 = DashboardGeneralService.generateGroupSeqId(0l,userseqid,insPricingVO.getPricingList());
	
		insPricingVO.setGroupProfilePricingSeqid(insPricingVO1.getGroupProfilePricingSeqid());
		insPricingVO.setGroupProfileRefNo(insPricingVO1.getGroupProfileRefNo());
		}
		System.out.println("save controller");
	
		insPricingVO.setUpdatedBy(userseqid);
		
     	Long re= DashboardGeneralService.saveGroupPricingDetails(insPricingVO);
     	
     	if(re > 0) {
     		modelAndView.addObject("msg", "Details added successfully");
     	}
     	
    	/*modelAndView.addObject("groupPricingSeqId",insPricingVO.getGroupProfilePricingSeqid());
		modelAndView.addObject("groupPricingRefNo",insPricingVO.getGroupProfileRefNo());*/
		
		request.getSession().setAttribute("groupPricingSeqId",insPricingVO.getGroupProfilePricingSeqid());
		request.getSession().setAttribute("groupPricingRefNo",insPricingVO.getGroupProfileRefNo());
		
    	ArrayList groupPricingList = DashboardGeneralService.getGroupPricingDisplayList(insPricingVO.getGroupProfilePricingSeqid(),"");	
    	

		
    	
		request.setAttribute("groupPricingList",(ArrayList<InsPricingVO>)groupPricingList.get(0));
		request.setAttribute("groupPricingList1",(ArrayList<InsPricingVO>)groupPricingList.get(1));
		request.setAttribute("groupPricingList2",(ArrayList<InsPricingVO>)groupPricingList.get(2));
		request.setAttribute("groupPricingList3",(ArrayList<InsPricingVO>)groupPricingList.get(3));
		request.setAttribute("groupPricingList4",(ArrayList<InsPricingVO>)groupPricingList.get(4));
		request.setAttribute("groupPricingList5",(ArrayList<InsPricingVO>)groupPricingList.get(5));
		request.setAttribute("groupPricingList6",(ArrayList<InsPricingVO>)groupPricingList.get(6));
		request.setAttribute("groupPricingList7",(ArrayList<InsPricingVO>)groupPricingList.get(7));
		request.setAttribute("groupPricingList8",(ArrayList<InsPricingVO>)groupPricingList.get(8));
		request.setAttribute("groupPricingList9",(ArrayList<InsPricingVO>)groupPricingList.get(9));
		request.setAttribute("groupPricingList10",(ArrayList<InsPricingVO>)groupPricingList.get(10));		
		
		
		/*request.setAttribute("groupPricingProviderList1",(ArrayList<InsPricingVO>)groupPricingList.get(11));
		request.setAttribute("groupPricingProviderList2",(ArrayList<InsPricingVO>)groupPricingList.get(12));
		request.setAttribute("groupPricingProviderList3",(ArrayList<InsPricingVO>)groupPricingList.get(13));
		request.setAttribute("groupPricingProviderList4",(ArrayList<InsPricingVO>)groupPricingList.get(14));
		request.setAttribute("groupPricingProviderList5",(ArrayList<InsPricingVO>)groupPricingList.get(15));
		request.setAttribute("groupPricingProviderList6",(ArrayList<InsPricingVO>)groupPricingList.get(16));
		request.setAttribute("groupPricingProviderList7",(ArrayList<InsPricingVO>)groupPricingList.get(17));
		request.setAttribute("groupPricingProviderList8",(ArrayList<InsPricingVO>)groupPricingList.get(18));
		request.setAttribute("groupPricingProviderList9",(ArrayList<InsPricingVO>)groupPricingList.get(19));
		request.setAttribute("groupPricingProviderList10",(ArrayList<InsPricingVO>)groupPricingList.get(20));*/
	
		
		/*request.setAttribute("groupPricingOpticalList1",(ArrayList<InsPricingVO>)groupPricingList.get(21));
		request.setAttribute("groupPricingOpticalList2",(ArrayList<InsPricingVO>)groupPricingList.get(22));
		request.setAttribute("groupPricingOpticalList3",(ArrayList<InsPricingVO>)groupPricingList.get(23));
		request.setAttribute("groupPricingOpticalList4",(ArrayList<InsPricingVO>)groupPricingList.get(24));
		request.setAttribute("groupPricingOpticalList5",(ArrayList<InsPricingVO>)groupPricingList.get(25));
		request.setAttribute("groupPricingOpticalList6",(ArrayList<InsPricingVO>)groupPricingList.get(26));
		request.setAttribute("groupPricingOpticalList7",(ArrayList<InsPricingVO>)groupPricingList.get(27));
		request.setAttribute("groupPricingOpticalList8",(ArrayList<InsPricingVO>)groupPricingList.get(28));
		request.setAttribute("groupPricingOpticalList9",(ArrayList<InsPricingVO>)groupPricingList.get(29));
		request.setAttribute("groupPricingOpticalList10",(ArrayList<InsPricingVO>)groupPricingList.get(30));*/
		
		
		/*request.setAttribute("groupPricingOtherList1",(ArrayList<InsPricingVO>)groupPricingList.get(31));
		request.setAttribute("groupPricingOtherList2",(ArrayList<InsPricingVO>)groupPricingList.get(32));
		request.setAttribute("groupPricingOtherList3",(ArrayList<InsPricingVO>)groupPricingList.get(33));
		request.setAttribute("groupPricingOtherList4",(ArrayList<InsPricingVO>)groupPricingList.get(34));
		request.setAttribute("groupPricingOtherList5",(ArrayList<InsPricingVO>)groupPricingList.get(35));
		request.setAttribute("groupPricingOtherList6",(ArrayList<InsPricingVO>)groupPricingList.get(36));
		request.setAttribute("groupPricingOtherList7",(ArrayList<InsPricingVO>)groupPricingList.get(37));
		request.setAttribute("groupPricingOtherList8",(ArrayList<InsPricingVO>)groupPricingList.get(38));
		request.setAttribute("groupPricingOtherList9",(ArrayList<InsPricingVO>)groupPricingList.get(39));
		request.setAttribute("groupPricingOtherList10",(ArrayList<InsPricingVO>)groupPricingList.get(40));*/
		
		request.setAttribute("grossPremiumMemberGroupLevel",(InsPricingVO)groupPricingList.get(11));
		request.setAttribute("policyDuration",(InsPricingVO)groupPricingList.get(12));
		
		InsPricingVO ins = (InsPricingVO)groupPricingList.get(12);		
        request.getSession().setAttribute("groupPricingProducName",ins.getClientCodeDesc());

		request.setAttribute("exprienceSummery",(ArrayList<InsPricingVO>)groupPricingList.get(13));	
	
		
		return modelAndView;
	}
	
	@RequestMapping(value ={"SearchwithStatus"}, method = RequestMethod.POST)
	public ModelAndView doSearchPricingWithStatus(@ModelAttribute("DashboardVO") DashboardVO dashboardVO, @RequestParam("approved") String approvedValue,@RequestParam("Pending") String PendingValue,@RequestParam("Reject") String RejectValue, HttpServletRequest request,HttpServletResponse response,Model model)throws Exception
	{
		ModelAndView modelAndView = new ModelAndView(strPricingDashBoard);
		/*System.out.println("test y.."+dashboardVO.getApprovedYN());*/
	
	    dashboardVO.setApprovedYN(approvedValue);
	    dashboardVO.setPendingYN(PendingValue);
	    dashboardVO.setRejectYN(RejectValue);
		try{
		TableData tableDataLog=null;
		String[] identfierList = new String[] {"renewal"}; 
		populateData(identfierList, "renewalDropdowns");
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile");
		if((request.getSession()).getAttribute("tableDataLog") == null)
		{
			tableDataLog = new TableData();
		}
		else
		{
			tableDataLog = (TableData)(request.getSession()).getAttribute("tableDataLog");
		}
		
		
		
			String strPageID = UXUtility.checkNull(request.getParameter("pageId"));
			String strSortID = UXUtility.checkNull(request.getParameter("sortId"));
				DashboardVO supportVo=new DashboardVO();
			if (!strPageID.equals("") || !strSortID.equals("")) {
				if (!strPageID.equals("")) {
					tableDataLog.setCurrentPage(Integer.parseInt(UXUtility.checkNull(request.getParameter("pageId"))));
					long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();
					
					
					if (tableDataLog != null) {
						ArrayList alObject = tableDataLog.getData() == null ? (new ArrayList()) : tableDataLog.getData();
					}
					modelAndView.addObject("DashboardVO", supportVo);

					return modelAndView;
				} else {
					tableDataLog.setSortData(UXUtility.checkNull(request.getParameter("sortId")));
					tableDataLog.modifySearchData("sort");
				}
			} else {
				tableDataLog.createTableInfo("SwInsurancePricingTable", null);
					tableDataLog.setSearchData(this.populateSearchCriteria((dashboardVO),request));
				
				tableDataLog.modifySearchData("search");
			}
			// userAccessSecurityProfile.getWorkFlowMap();
			long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();
	
			Object[] results=DashboardGeneralService.getSwInsuranceProfileList(tableDataLog.getSearchData());
		
			ArrayList<Object> alSearchData=(ArrayList<Object>)results[0];
			//modelAndView.addObject("pendingApproval",results[1]);
			request.getSession().setAttribute("pendingApproval", results[1]);
			tableDataLog.setData(alSearchData,"search");
			request.getSession().setAttribute("tableDataLog",tableDataLog);
			request.getSession().setAttribute("approvedYN",approvedValue);
			request.getSession().setAttribute("pendingYN", PendingValue);
			request.getSession().setAttribute("rejectYN", RejectValue);
			/*dashboardVO.setApprovedYN(approvedValue);
			dashboardVO.setPendingYN(PendingValue);
			dashboardVO.setRejectYN(RejectValue);*/
			/*model.addAttribute("approvedYN", dashboardVO.getApprovedYN());
			model.addAttribute("pendingYN", dashboardVO.getPendingYN());
			model.addAttribute("rejectYN", dashboardVO.getRejectYN());*/
			return modelAndView;    
		}catch(Throwable throwable){
			return processErrorView(strPricingDashBoard, throwable);

		}

		
	}
	
	  @RequestMapping(value ="grouppricing",  method = RequestMethod.GET)
	    public String doGroupReport(HttpServletRequest request,
	            HttpServletResponse response, HttpSession session, Model model) throws Exception {
		  
		  
		 

//	        JasperReport emptyReport;
	        JasperPrint jasperPrint;
	        int iNoOfCursor = 6;
//	        JasperPrint objJasperPrint[] = new JasperPrint[iNoOfCursor];
//	        ArrayList<Object> alJasperPrintList = new ArrayList<Object>();
//	        String strPath = "";
	    String shortDirectory = UXUtility.getPropertyValue("generalreports");
	        TTKReportDataSource ttkReportDataSource = null;
	        String jrxmlfile = shortDirectory + request.getParameter("fileName");
	    /*    String strPdfFile = TTKPropertiesReader.getPropertyValue("shortfallrptdir")+ request.getParameter("lngprofileseqid") + ".pdf";*/

	        try {
//	            System.out.println("jrxmlfile....."+jrxmlfile);

//	            xmljasperReport = JasperCompileManager.compileReport("" + shortDirectory + "/viewInputPricing.jrxml");
	            HashMap<String, Object> hashMap = new HashMap<String, Object>();
	            ByteArrayOutputStream boas = new ByteArrayOutputStream();
	            ttkReportDataSource = new TTKReportDataSource("groupReport",request.getParameter("parameter"),dataSource,iNoOfCursor);
	            ArrayList resultSetList=ttkReportDataSource.getResultSetList();
	            OracleCachedRowSet[] arrResulSet=new OracleCachedRowSet[6];
	            arrResulSet[0]=(OracleCachedRowSet) resultSetList.get(0);
	            arrResulSet[1]=(OracleCachedRowSet) resultSetList.get(1);
	            arrResulSet[2]=(OracleCachedRowSet) resultSetList.get(2);
	            arrResulSet[3]=(OracleCachedRowSet) resultSetList.get(3);
	            arrResulSet[4]=(OracleCachedRowSet) resultSetList.get(4);
	            arrResulSet[5]=(OracleCachedRowSet) resultSetList.get(5);
	          

	            JasperReport groupReport = null;
	            JasperReport groupReportSubReport1 = null;
	            JasperReport groupReportSubReport2= null;
	            JasperReport groupReportSubReport3 = null;
	            JasperReport groupReportSubReport4 = null;
	            JasperReport groupReportSubReport5= null;

	            //JasperReport premiumJasperReport = null;
	            JasperReport emptyReport=null;
//	            JasperPrint generalJasperPrint = null;

	       //     ResultSet resultSet1 =arrResulSet[1];

	  /*          while(resultSet1.next())
	            {
	                for(int i=1;i<=resultSet1.getMetaData().getColumnCount();i++)
	                {
	                    logger.info("index ::"+i+":: "+resultSet1.getMetaData().getColumnName(i) +":::"+resultSet1.getString(i));

	                }
	logger.info("----------------------------------------------//-----------");
	            }
	            ResultSet resultSet2 =arrResulSet[5];
	            while(resultSet2.next())
	            {
	                for(int i=1;i<=resultSet2.getMetaData().getColumnCount();i++)
	                {
	                    logger.info("index ::"+i+":: "+resultSet2.getMetaData().getColumnName(i) +":::"+resultSet2.getString(i));

	                }
	logger.info("----------------------------------------------//-----------");
	            }*/
	         //   resultSet1.beforeFirst();
	            JRDataSource myResultSetDS0 = new JRResultSetDataSource(arrResulSet[0]);
	            JRDataSource myResultSetDS1 = new JRResultSetDataSource(arrResulSet[1]);
	            JRDataSource myResultSetDS2 = new JRResultSetDataSource(arrResulSet[2]);
	            JRDataSource myResultSetDS3 = new JRResultSetDataSource(arrResulSet[3]);
	            JRDataSource myResultSetDS4 = new JRResultSetDataSource(arrResulSet[4]);
	            JRDataSource myResultSetDS5 = new JRResultSetDataSource(arrResulSet[5]);




	            ttkReportDataSource.setResultData(arrResulSet);
	            if(!arrResulSet[0].next())
	            {
	                System.out.println("m1");
	                emptyReport = JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
	                jasperPrint = JasperFillManager.fillReport(emptyReport,hashMap,new JREmptyDataSource());

	JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
	              // JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
	/*JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);*/
	                request.getSession().setAttribute("boas", boas);
//	                alJasperPrintList.add(jasperPrint);
	            }
	         else
	         {
	        	

	        	 groupReport = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportmax.jrxml");

	        	groupReportSubReport1 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport1max.jrxml");
	        	 groupReportSubReport2 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport2max.jrxml");
	        	groupReportSubReport3 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport3max.jrxml");
	        	   groupReportSubReport4 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport4max.jrxml");
	        	 groupReportSubReport5 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport5max.jrxml");
	        	


	                /*premiumJasperReport= JasperCompileManager.compileReport("");*/
	              hashMap.put("groupsubreportdatasource1", myResultSetDS1);
	                hashMap.put("groupSubReport1", groupReportSubReport1);



	              hashMap.put("groupsubreportdatasource2", myResultSetDS2);
	                hashMap.put("groupSubReport2", groupReportSubReport2);
	                
	               hashMap.put("groupsubreportdatasource3", myResultSetDS3);
	                hashMap.put("groupSubReport3", groupReportSubReport3);



	               hashMap.put("groupsubreportdatasource4", myResultSetDS4);
	                hashMap.put("groupSubReport4", groupReportSubReport4);
	                
	                   hashMap.put("groupsubreportdatasource5", myResultSetDS5);
	                hashMap.put("groupSubReport5", groupReportSubReport5);



	               
	              

	              

	                /*hsashMap.put("premiumDataSource", myResultSetDS3);
	                hashMap.put("premiumReport", premiumJasperReport);*/



	                arrResulSet[0].beforeFirst();
	                System.out.println("tttt..."+hashMap);
	             if (arrResulSet[0].next())
	             {
	                 arrResulSet[0].beforeFirst();
	                 System.out.println("main");
	             jasperPrint = JasperFillManager.fillReport(groupReport,hashMap, myResultSetDS0);

	             } else
	             {
	                 System.out.println("empty");
	                 emptyReport =JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
	                 jasperPrint = JasperFillManager.fillReport( emptyReport, hashMap,new JREmptyDataSource());
	             }

	           JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
	          // JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
	//JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);
	            request.getSession().setAttribute("boas", boas);
	        } // end of try
	        }
	        catch (Exception e) {
	            e.printStackTrace();
	        }


	        return "forward:/" + strReportdisplay + "";
	    
	  }
	  @RequestMapping(value ="grouppricingMax",  method = RequestMethod.GET)
	    public String doGroupReportMax(HttpServletRequest request,
	            HttpServletResponse response, HttpSession session, Model model) throws Exception {
		  
		  
		 

//	        JasperReport emptyReport;
	        JasperPrint jasperPrint;
	        int iNoOfCursor = 6;
//	        JasperPrint objJasperPrint[] = new JasperPrint[iNoOfCursor];
//	        ArrayList<Object> alJasperPrintList = new ArrayList<Object>();
//	        String strPath = "";
	    String shortDirectory = UXUtility.getPropertyValue("generalreports");
	        TTKReportDataSource ttkReportDataSource = null;
	        String jrxmlfile = shortDirectory + request.getParameter("fileName");
	    /*    String strPdfFile = TTKPropertiesReader.getPropertyValue("shortfallrptdir")+ request.getParameter("lngprofileseqid") + ".pdf";*/

	        try {
//	            System.out.println("jrxmlfile....."+jrxmlfile);

//	            xmljasperReport = JasperCompileManager.compileReport("" + shortDirectory + "/viewInputPricing.jrxml");
	            HashMap<String, Object> hashMap = new HashMap<String, Object>();
	            ByteArrayOutputStream boas = new ByteArrayOutputStream();
	            ttkReportDataSource = new TTKReportDataSource("groupReport",request.getParameter("parameter"),dataSource,iNoOfCursor);
	            ArrayList resultSetList=ttkReportDataSource.getResultSetList();
	            OracleCachedRowSet[] arrResulSet=new OracleCachedRowSet[6];
	            arrResulSet[0]=(OracleCachedRowSet) resultSetList.get(0);
	            arrResulSet[1]=(OracleCachedRowSet) resultSetList.get(1);
	            arrResulSet[2]=(OracleCachedRowSet) resultSetList.get(2);
	            arrResulSet[3]=(OracleCachedRowSet) resultSetList.get(3);
	            arrResulSet[4]=(OracleCachedRowSet) resultSetList.get(4);
	            arrResulSet[5]=(OracleCachedRowSet) resultSetList.get(5);
	          

	            JasperReport groupReport = null;
	            JasperReport groupReportSubReport1 = null;
	            JasperReport groupReportSubReport2= null;
	            JasperReport groupReportSubReport3 = null;
	            JasperReport groupReportSubReport4 = null;
	            JasperReport groupReportSubReport5= null;

	            //JasperReport premiumJasperReport = null;
	            JasperReport emptyReport=null;
//	            JasperPrint generalJasperPrint = null;

	       //     ResultSet resultSet1 =arrResulSet[1];

	  /*          while(resultSet1.next())
	            {
	                for(int i=1;i<=resultSet1.getMetaData().getColumnCount();i++)
	                {
	                    logger.info("index ::"+i+":: "+resultSet1.getMetaData().getColumnName(i) +":::"+resultSet1.getString(i));

	                }
	logger.info("----------------------------------------------//-----------");
	            }
	            ResultSet resultSet2 =arrResulSet[5];
	            while(resultSet2.next())
	            {
	                for(int i=1;i<=resultSet2.getMetaData().getColumnCount();i++)
	                {
	                    logger.info("index ::"+i+":: "+resultSet2.getMetaData().getColumnName(i) +":::"+resultSet2.getString(i));

	                }
	logger.info("----------------------------------------------//-----------");
	            }*/
	         //   resultSet1.beforeFirst();
	            JRDataSource myResultSetDS0 = new JRResultSetDataSource(arrResulSet[0]);
	            JRDataSource myResultSetDS1 = new JRResultSetDataSource(arrResulSet[1]);
	            JRDataSource myResultSetDS2 = new JRResultSetDataSource(arrResulSet[2]);
	            JRDataSource myResultSetDS3 = new JRResultSetDataSource(arrResulSet[3]);
	            JRDataSource myResultSetDS4 = new JRResultSetDataSource(arrResulSet[4]);
	            JRDataSource myResultSetDS5 = new JRResultSetDataSource(arrResulSet[5]);




	            ttkReportDataSource.setResultData(arrResulSet);
	            if(!arrResulSet[0].next())
	            {
	                System.out.println("m1");
	                emptyReport = JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
	                jasperPrint = JasperFillManager.fillReport(emptyReport,hashMap,new JREmptyDataSource());

	JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
	              // JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
	/*JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);*/
	                request.getSession().setAttribute("boas", boas);
//	                alJasperPrintList.add(jasperPrint);
	            }
	         else
	         {
	        	

	        	 groupReport = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReport.jrxml");

	        	groupReportSubReport1 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport1.jrxml");
	        	 groupReportSubReport2 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport2.jrxml");
	        	groupReportSubReport3 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport3.jrxml");
	        	   groupReportSubReport4 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport4.jrxml");
	        	 groupReportSubReport5 = JasperCompileManager.compileReport(shortDirectory+"/grouppricing/groupReportSubReport5.jrxml");
	        	


	                /*premiumJasperReport= JasperCompileManager.compileReport("");*/
	              hashMap.put("groupsubreportdatasource1", myResultSetDS1);
	                hashMap.put("groupSubReport1", groupReportSubReport1);



	              hashMap.put("groupsubreportdatasource2", myResultSetDS2);
	                hashMap.put("groupSubReport2", groupReportSubReport2);
	                
	               hashMap.put("groupsubreportdatasource3", myResultSetDS3);
	                hashMap.put("groupSubReport3", groupReportSubReport3);



	               hashMap.put("groupsubreportdatasource4", myResultSetDS4);
	                hashMap.put("groupSubReport4", groupReportSubReport4);
	                
	                   hashMap.put("groupsubreportdatasource5", myResultSetDS5);
	                hashMap.put("groupSubReport5", groupReportSubReport5);



	               
	              

	              

	                /*hsashMap.put("premiumDataSource", myResultSetDS3);
	                hashMap.put("premiumReport", premiumJasperReport);*/



	                arrResulSet[0].beforeFirst();
	               
	             if (arrResulSet[0].next())
	             {
	                 arrResulSet[0].beforeFirst();
	                 System.out.println("main");
	             jasperPrint = JasperFillManager.fillReport(groupReport,hashMap, myResultSetDS0);

	             } else
	             {
	                 System.out.println("empty");
	                 emptyReport =JasperCompileManager.compileReport(""+shortDirectory+"/EmptyReprot.jrxml");
	                 jasperPrint = JasperFillManager.fillReport( emptyReport, hashMap,new JREmptyDataSource());
	             }

	           JasperExportManager.exportReportToPdfStream(jasperPrint, boas);
	          // JasperExportManager.exportReportToPdfFile(jasperPrint,"E:\\reportgenerate\\test.pdf");
	//JasperExportManager.exportReportToPdfFile(jasperPrint, strPdfFile);
	            request.getSession().setAttribute("boas", boas);
	        } // end of try
	        }
	        catch (Exception e) {
	            e.printStackTrace();
	        }


	        return "forward:/" + strReportdisplay + "";
	    
	  }
	  
	  @Autowired
		private DataSource dataSource;



	
	
	@Autowired
	DashboardGeneralService DashboardGeneralService;
}


package com.vidal.controllers.pricing;



import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.regex.Pattern;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.itextpdf.text.log.SysoCounter;
import com.vidal.command.common.CacheObject;
import com.vidal.command.pricing.AdditionalVO;
import com.vidal.command.pricing.Batch;
import com.vidal.command.pricing.DashboardVO;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.MaternityData;
import com.vidal.command.pricing.MaternityDetails;
import com.vidal.command.pricing.MemberData;
import com.vidal.command.pricing.MemberDetails;
import com.vidal.command.pricing.PolicyGroupVO;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.UXUtility;
import com.vidal.common.VidalCommon;
import com.vidal.common.controller.vidalcontroller.VidalController;
import com.vidal.common.exception.GetErrorMessage;
import com.vidal.common.exception.VidalException;
import com.vidal.common.reports.TTKPropertiesReader;
import com.vidal.controllers.table.TableData;
import com.vidal.services.authentication.Additionalservice;
import com.vidal.services.authentication.DashboardGeneralService;
import com.vidal.services.pricing.PricingInputScreenService;

@Controller
@Scope("session")
public class PricingToolInputScreenController extends VidalController{
	private static Logger logger = Logger.getLogger(PricingToolInputScreenController.class);
	@Autowired
	public PricingInputScreenService pricingInputScreenService;
	
	@Autowired
	DashboardGeneralService DashboardGeneralService;
	
	private static final String strInputScreen = "inputscreen";
	private static final String strGroupPricing = "groupPricing";
	private static final String strInputScreenreadonly="readonlyinputscreen";
	
	String statusTest="";
		
	@RequestMapping(value ="/displayTab" , method = RequestMethod.POST)
	public String defaultTab(HttpServletRequest request,@RequestParam("status")String status, Model model) {		
		setErrorPageData("displayTab",model);
		statusTest = status;
		ModelAndView modelAndView = new ModelAndView("displayTab");		
		return "forward:SoftwareInsurancePricing/Inputs-Screen";
	}
	
	@RequestMapping(value ="/SoftwareInsurancePricing/newRefresh" , method = RequestMethod.POST)
	public ModelAndView  newInputRefresh(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,HttpServletRequest request,Model model) throws Exception{	
	   ModelAndView	 modelAndView = new ModelAndView(strInputScreen);
	  
		 setErrorPageData(strInputScreen,model);	
		 
		 InsPricingVO  insPricingVO1 = null;
		 ArrayList alprofileIncomeList=null;
		String[] identfierList = new String[] {"networkList","opticalLimitList","clientCodeList","brokerCodeList",
				"maxBenifitListIp","areaOfCoverList","opCopaypharmacyList","opInvestigationList","opCopyothersList",
				"opticalCopayList","opticalFrameLimitList","dentalLimitList","dentalcopayList","orthodonticsCopay",
				"maternityLimitList","opCopyalahlihospList","opInvestnAlAhliList","opPharmacyAlAhliList","opothersAlAhliList",
				"opConsultAlAhliList","ipCopayList","iPCopayAtAhliList","residencyCountryList","remiumOutputStructureList",
				"maternityPricingList","maternityCopayList","opCopyconsultnList","opCopayList","premiumRefundApproachList",
				"networkListFactor","maternityCopayListWhatif","maxBenifitListOpLimitIp","maxBenifitListOpLimitIpWhatif"};
		
		 insPricingVO1 = new InsPricingVO();
		 insPricingVO1.setInpatientBenefit("Y");
		 insPricingVO1.setOutpatientBenefit("Y");
		 insPricingVO1.setAlAhlihospital("Y");
		 insPricingVO1.setProRATALimitApplicable("N");
	
		
		insPricingVO1.setRenewalYN(insPricingVO.getRenewalYN());
		insPricingVO1.setCensusSavaYn(insPricingVO.getCensusSavaYn());
		
		if(request.getSession().getAttribute("groupPricingSeqId") != null && !request.getSession().getAttribute("groupPricingSeqId").equals("")) {
		 
			 Long groupProfileSeqID= (Long)request.getSession().getAttribute("groupPricingSeqId");
			 insPricingVO1.setGroupProfileSeqID(groupProfileSeqID);			
			 alprofileIncomeList= pricingInputScreenService.getBenefitvalueAfter(insPricingVO.getGroupProfileSeqID());
			 
			 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
			 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));									 		 	 		 
             request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
             request.getSession().setAttribute("sumTotalLivesMale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMale());
			 request.getSession().setAttribute("sumTotalLivesFemale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemale());
			 request.getSession().setAttribute("sumTotalLivesMaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaleUserPer());
			 request.getSession().setAttribute("sumTotalLivesFemaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemaleUserPer());					 
			 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
			 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
			 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
			 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());			 
			 request.getSession().setAttribute("totalNoOfLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalCovedLives());			 
			 request.getSession().setAttribute("TotalMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalLivesMaternity());		
			
		}else {
			
			 alprofileIncomeList= pricingInputScreenService.getBenefitvalueBefore(0l);
			 
			 ArrayList<InsPricingVO> seq_id= (ArrayList<InsPricingVO>) alprofileIncomeList.get(0);
			
			 Iterator<InsPricingVO> it = seq_id.iterator();
			 while(it.hasNext()){
				InsPricingVO insVo = it.next();
				Long seqid= insVo.getBenf_typeseqid1();				
			 }
			 				 
			 
			 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
			 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));		 		 	 		 
			 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());			 
			 request.getSession().setAttribute("sumTotalLivesMale","");
			 request.getSession().setAttribute("sumTotalLivesFemale","");
			 request.getSession().setAttribute("sumTotalLivesMaleUserPer",null);
			 request.getSession().setAttribute("sumTotalLivesFemaleUserPer",null);
			 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
			 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
			 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
			 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
		/*	 request.getSession().removeAttribute("minMaternityLives");
			 request.getSession().removeAttribute("maxMaternityLives");	
			 request.getSession().removeAttribute("profileBenefitList");		*/
			 request.getSession().setAttribute("completeSaveYN","N");
			 request.getSession().setAttribute("renevalFlag","N");
			 request.getSession().setAttribute("editflag","Y");	
			
		}
	
		ArrayList<CacheObject>  opLimitList = pricingInputScreenService.getOpLimitlist("");
		 request.getSession().setAttribute("opLimitList", opLimitList);
		modelAndView.addObject("insPricingVO",insPricingVO1);	
	   
		return modelAndView;
	}
	
	@RequestMapping(value ="/SoftwareInsurancePricing/Inputs-Screen" , method = RequestMethod.POST)
	public ModelAndView inputScreen(HttpServletRequest request,Model model) throws Exception {	
		 setLinks(request);
		 InsPricingVO	 insPricingVO = new InsPricingVO();
		/*ModelAndView modelAndView = new ModelAndView(strInputScreen);*/
		ModelAndView modelAndView = null;
		setErrorPageData(strInputScreen,model);	
		
		 ArrayList alprofileIncomeList=null;
		 
		String[] identfierList = new String[] {"networkList","opticalLimitList","clientCodeList","brokerCodeList",
				"maxBenifitListIp","areaOfCoverList","opCopaypharmacyList","opInvestigationList","opCopyothersList",
				"opticalCopayList","opticalFrameLimitList","dentalLimitList","dentalcopayList","orthodonticsCopay",
				"maternityLimitList","opCopyalahlihospList","opInvestnAlAhliList","opPharmacyAlAhliList","opothersAlAhliList",
				"opConsultAlAhliList","ipCopayList","iPCopayAtAhliList","residencyCountryList","remiumOutputStructureList",
				"maternityPricingList","maternityCopayList","opCopyconsultnList","opCopayList","premiumRefundApproachList",
				"networkListFactor","maternityCopayListWhatif","maxBenifitListOpLimitIp","maxBenifitListOpLimitIpWhatif"};
		
		populateData(identfierList,"inputscreen");
		request.getSession().removeAttribute("noCoverdLives");
		
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");
		userAccessSecurityProfile.getSecurityProfile().setActiveTab("Inputs-Screen");
		
		 long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();		
		 ArrayList<CacheObject> alPricingNetworkList = pricingInputScreenService.getHospitalList("1");		 
		 request.getSession().setAttribute("alPricingNetworkList", alPricingNetworkList);
		 
		 ArrayList<CacheObject> alPricingAdditionalNetworkList = pricingInputScreenService.getAdditionalHospitalList("1");		 
		 request.getSession().setAttribute("alPricingAdditionalNetworkList", alPricingAdditionalNetworkList);
		 
		 ArrayList<CacheObject>  opLimitList = pricingInputScreenService.getOpLimitlist("");
		 request.getSession().setAttribute("opLimitList", opLimitList);
		 
		if(!statusTest.equals("New,")) {
						    			    
			     String flag = (String)request.getSession().getAttribute("editflag");
			     if("N".equals(flag)){
			    	 modelAndView = new ModelAndView(strInputScreenreadonly);
			     }else{
			    	 modelAndView = new ModelAndView(strInputScreen);
			     }
				 request.getSession().setAttribute("editflag", request.getSession().getAttribute("editflag") );

			 
			     Long groupSeqiD=(Long)request.getSession().getAttribute("groupPricingSeqId");	
			  
			   
				insPricingVO= pricingInputScreenService.swSelectPricingList(groupSeqiD);
																			
		    	 request.getSession().setAttribute("noCoverdLives", insPricingVO.getNoCoverdLives());
		    	 insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
                 insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
                 insPricingVO.setOpdeductableserviceYN(insPricingVO.getOpdeductableserviceYN() != "" ?insPricingVO.getOpdeductableserviceYN():"Y");
                 insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
                 insPricingVO.setAlAhlihospOPservices(insPricingVO.getAlAhlihospOPservices() != "" ?insPricingVO.getAlAhlihospOPservices():"Y");
                 insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
				SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
				
				if(insPricingVO.getCoverStartDate() !=null) {
				insPricingVO.setCoverNewStartDate(sd.format(insPricingVO.getCoverStartDate()));
				insPricingVO.setCoverNewEndDate(sd.format(insPricingVO.getCoverEndDate())); 
				}
							
				request.getSession().setAttribute("groupPricingSeqId",insPricingVO.getGroupProfileSeqID());
				request.getSession().setAttribute("pricingRefNo",insPricingVO.getPricingRefno());
								
				
			     InsPricingVO	 insPricingVO1  =  pricingInputScreenService.getfalgPricingvalue(insPricingVO.getGroupProfileSeqID());
				  String bene_covered_FlagYN = insPricingVO1.getBenecoverFlagYN();
				  String calCPM_FlagYN = insPricingVO1.getBenecoverFlagYN();
				  				 
				  request.getSession().setAttribute("completeSaveYN",calCPM_FlagYN);	
				  
				if(bene_covered_FlagYN.equalsIgnoreCase("Y")) {
				
				 alprofileIncomeList= pricingInputScreenService.getBenefitvalueAfter(insPricingVO.getGroupProfileSeqID());				 	 		 
				 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
				 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));
				 		 	 		 
				 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
				 
				 request.getSession().setAttribute("sumTotalLivesMale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMale());
				 request.getSession().setAttribute("sumTotalLivesFemale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemale());
				 request.getSession().setAttribute("sumTotalLivesMaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaleUserPer());
				 request.getSession().setAttribute("sumTotalLivesFemaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemaleUserPer());
				 
				 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
				 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
				 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
				 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());			 
				 request.getSession().setAttribute("totalNoOfLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalCovedLives());			 
				 request.getSession().setAttribute("TotalMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalLivesMaternity());
				   insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
                   insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
                   insPricingVO.setOpdeductableserviceYN(insPricingVO.getOpdeductableserviceYN() != "" ?insPricingVO.getOpdeductableserviceYN():"Y");
                   insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
                   insPricingVO.setAlAhlihospOPservices(insPricingVO.getAlAhlihospOPservices() != "" ?insPricingVO.getAlAhlihospOPservices():"Y");
                   insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
                   insPricingVO.setLoadinghospitalCoverage(insPricingVO.getLoadinghospitalCoverage() != 0 ?insPricingVO.getLoadinghospitalCoverage():null);
   				insPricingVO.setDiscounthospitalExclusions(insPricingVO.getDiscounthospitalExclusions() != 0 ?insPricingVO.getDiscounthospitalExclusions():null);
				}else {
					
					 alprofileIncomeList= pricingInputScreenService.getBenefitvalueBefore(0l);	
					 ArrayList<InsPricingVO> seq_id= (ArrayList<InsPricingVO>) alprofileIncomeList.get(0);
					 Iterator<InsPricingVO> it = seq_id.iterator();
					 while(it.hasNext()){
					InsPricingVO insPricingVO2 = it.next();
						Long seqid= insPricingVO2.getBenf_typeseqid1();
					/*	System.out.println("sqqq.121.."+seqid);*/
					 }
					/* System.out.println("ccheck1122211");*/
					 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
					 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));				 		 	 		 
					 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
					 
					/* request.getSession().setAttribute("sumTotalLivesMale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMale());
					 request.getSession().setAttribute("sumTotalLivesFemale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemale());
					 request.getSession().setAttribute("sumTotalLivesMaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaleUserPer());
					 request.getSession().setAttribute("sumTotalLivesFemaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemaleUserPer());*/
					 
					 
					 request.getSession().setAttribute("sumTotalLivesMale","");
					 request.getSession().setAttribute("sumTotalLivesFemale","");
					 request.getSession().setAttribute("sumTotalLivesMaleUserPer","");
					 request.getSession().setAttribute("sumTotalLivesFemaleUserPer","");
					 
					 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
					 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
					 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
					 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
					 
                     insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
                     insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
                     insPricingVO.setOpdeductableserviceYN(insPricingVO.getOpdeductableserviceYN() != "" ?insPricingVO.getOpdeductableserviceYN():"Y");
                     insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
                     insPricingVO.setAlAhlihospOPservices(insPricingVO.getAlAhlihospOPservices() != "" ?insPricingVO.getAlAhlihospOPservices():"Y");
                     insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
                     insPricingVO.setLoadinghospitalCoverage(insPricingVO.getLoadinghospitalCoverage() != 0 ?insPricingVO.getLoadinghospitalCoverage():null);
     				insPricingVO.setDiscounthospitalExclusions(insPricingVO.getDiscounthospitalExclusions() != 0 ?insPricingVO.getDiscounthospitalExclusions():null);
                  
					
				}
			   			 			 			   
		 }else {
			
			 modelAndView = new ModelAndView(strInputScreen);
			 request.getSession().removeAttribute("profileBenefitList");
			 request.getSession().removeAttribute("minMaternityLives");
			 request.getSession().removeAttribute("maxMaternityLives");
			 request.getSession().removeAttribute("coppyBenefitsFlag");
			/* request.getSession().removeAttribute("noCoverdLives");*/
			 
			 request.getSession().setAttribute("completeSaveYN","N");
			 request.getSession().setAttribute("renevalFlag","N");
			 request.getSession().setAttribute("editflag","Y");			 		 			 			
			 insPricingVO = new InsPricingVO();
			 			 			
			 
			/*request.getSession().setAttribute("groupPricingSeqId","");
			request.getSession().setAttribute("pricingRefNo","");*/
		      	request.getSession().setAttribute("clientName","");
																			
				 request.getSession().setAttribute("groupPricingSeqId","");
				 request.getSession().setAttribute("pricingRefNo","");
				 alprofileIncomeList= pricingInputScreenService.getBenefitvalueBefore(0l);
				 
				 ArrayList<InsPricingVO> seq_id= (ArrayList<InsPricingVO>) alprofileIncomeList.get(0);
				
				 Iterator<InsPricingVO> it = seq_id.iterator();
				 while(it.hasNext()){
					InsPricingVO insVo = it.next();
					Long seqid= insVo.getBenf_typeseqid1();				
				 }
				 				 
				 
				 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
				 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));		 		 	 		 
				 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());			 
				 request.getSession().setAttribute("sumTotalLivesMale","");
				 request.getSession().setAttribute("sumTotalLivesFemale","");
				 request.getSession().setAttribute("sumTotalLivesMaleUserPer",null);
				 request.getSession().setAttribute("sumTotalLivesFemaleUserPer",null);
				 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
				 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
				 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
				 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
			/*}*/
			insPricingVO.setInpatientBenefit("Y");
			insPricingVO.setOutpatientBenefit("Y");
//			insPricingVO.setOpdeductableserviceYN("Y");
			insPricingVO.setAlAhlihospital("Y");
//			insPricingVO.setAlAhlihospOPservices("Y");
			insPricingVO.setProRATALimitApplicable("N");
			insPricingVO.setCensusSavaYn("N");
			 request.getSession().removeAttribute("fileName1");
			 request.getSession().removeAttribute("fileStream1");
			 request.getSession().removeAttribute("fileName2");
			 request.getSession().removeAttribute("fileStream2");
			 request.getSession().removeAttribute("fileNam3");
			 request.getSession().removeAttribute("fileStream3");
			 request.getSession().removeAttribute("fileName4");
			 request.getSession().removeAttribute("fileStream4");
			 request.getSession().removeAttribute("fileName5");
			 request.getSession().removeAttribute("fileStream5");
						
		
		}
	 
	               								 
			 //request.getSession().getAttribute("editflag");
		modelAndView.addObject("insPricingVO",insPricingVO);			
		return modelAndView;
	}// close inputScreen controller
	
	
	
	
	@RequestMapping(value ="/SoftwareInsurancePricing/EditInputs-Screen" , method = RequestMethod.POST)
	public ModelAndView editinputScreen(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,@RequestParam("edit") String editYn,HttpServletRequest request,Model model) throws Exception {	
		setLinks(request);
		ModelAndView modelAndView =null;
		
          
		TableData tableDataLog = (TableData)request.getSession().getAttribute("tableDataLog");
		if(!(request.getParameter("rownum")).equals("")) {
			     DashboardVO dashboardVO = (DashboardVO) tableDataLog.getRowInfo(Integer.parseInt(request.getParameter("rownum")));
			     
			
			
			if(dashboardVO.getPricingRefno().contains("GRP")) {
				if(!"".equals(editYn)){
					if("N".equalsIgnoreCase(editYn)){						
						 request.getSession().setAttribute("editflag",editYn);
					}else{											
						 request.getSession().setAttribute("editflag","Y");
					}
				}
				  modelAndView =  new ModelAndView(strGroupPricing);	
					/*modelAndView.addObject("groupPricingSeqId",dashboardVO.getGroupProfileSeqID());
					modelAndView.addObject("groupPricingRefNo",dashboardVO.getPricingRefno());*/
					request.getSession().setAttribute("groupPricingSeqId",insPricingVO.getGroupProfilePricingSeqid());
					request.getSession().setAttribute("groupPricingRefNo",insPricingVO.getPricingRefno());
			    	ArrayList groupPricingList = DashboardGeneralService.getGroupPricingDisplayList(dashboardVO.getGroupProfileSeqID(),"");	
			    						
			    	
					request.setAttribute("groupPricingList",(ArrayList<InsPricingVO>)groupPricingList.get(0));
					request.setAttribute("groupPricingList1",(ArrayList<InsPricingVO>)groupPricingList.get(1));
					request.setAttribute("groupPricingList2",(ArrayList<InsPricingVO>)groupPricingList.get(2));
					request.setAttribute("groupPricingList3",(ArrayList<InsPricingVO>)groupPricingList.get(3));
					request.setAttribute("groupPricingList4",(ArrayList<InsPricingVO>)groupPricingList.get(4));
					request.setAttribute("groupPricingList5",(ArrayList<InsPricingVO>)groupPricingList.get(5));
					request.setAttribute("groupPricingList6",(ArrayList<InsPricingVO>)groupPricingList.get(6));
					request.setAttribute("groupPricingList7",(ArrayList<InsPricingVO>)groupPricingList.get(7));
					request.setAttribute("groupPricingList8",(ArrayList<InsPricingVO>)groupPricingList.get(8));
					request.setAttribute("groupPricingList9",(ArrayList<InsPricingVO>)groupPricingList.get(9));
					request.setAttribute("groupPricingList10",(ArrayList<InsPricingVO>)groupPricingList.get(10));		
					
					
					/*request.setAttribute("groupPricingProviderList1",(ArrayList<InsPricingVO>)groupPricingList.get(11));
					request.setAttribute("groupPricingProviderList2",(ArrayList<InsPricingVO>)groupPricingList.get(12));
					request.setAttribute("groupPricingProviderList3",(ArrayList<InsPricingVO>)groupPricingList.get(13));
					request.setAttribute("groupPricingProviderList4",(ArrayList<InsPricingVO>)groupPricingList.get(14));
					request.setAttribute("groupPricingProviderList5",(ArrayList<InsPricingVO>)groupPricingList.get(15));
					request.setAttribute("groupPricingProviderList6",(ArrayList<InsPricingVO>)groupPricingList.get(16));
					request.setAttribute("groupPricingProviderList7",(ArrayList<InsPricingVO>)groupPricingList.get(17));
					request.setAttribute("groupPricingProviderList8",(ArrayList<InsPricingVO>)groupPricingList.get(18));
					request.setAttribute("groupPricingProviderList9",(ArrayList<InsPricingVO>)groupPricingList.get(19));
					request.setAttribute("groupPricingProviderList10",(ArrayList<InsPricingVO>)groupPricingList.get(20));*/
				
					
				/*	request.setAttribute("groupPricingOpticalList1",(ArrayList<InsPricingVO>)groupPricingList.get(21));
					request.setAttribute("groupPricingOpticalList2",(ArrayList<InsPricingVO>)groupPricingList.get(22));
					request.setAttribute("groupPricingOpticalList3",(ArrayList<InsPricingVO>)groupPricingList.get(23));
					request.setAttribute("groupPricingOpticalList4",(ArrayList<InsPricingVO>)groupPricingList.get(24));
					request.setAttribute("groupPricingOpticalList5",(ArrayList<InsPricingVO>)groupPricingList.get(25));
					request.setAttribute("groupPricingOpticalList6",(ArrayList<InsPricingVO>)groupPricingList.get(26));
					request.setAttribute("groupPricingOpticalList7",(ArrayList<InsPricingVO>)groupPricingList.get(27));
					request.setAttribute("groupPricingOpticalList8",(ArrayList<InsPricingVO>)groupPricingList.get(28));
					request.setAttribute("groupPricingOpticalList9",(ArrayList<InsPricingVO>)groupPricingList.get(29));
					request.setAttribute("groupPricingOpticalList10",(ArrayList<InsPricingVO>)groupPricingList.get(30));*/
					
					
				/*	request.setAttribute("groupPricingOtherList1",(ArrayList<InsPricingVO>)groupPricingList.get(31));
					request.setAttribute("groupPricingOtherList2",(ArrayList<InsPricingVO>)groupPricingList.get(32));
					request.setAttribute("groupPricingOtherList3",(ArrayList<InsPricingVO>)groupPricingList.get(33));
					request.setAttribute("groupPricingOtherList4",(ArrayList<InsPricingVO>)groupPricingList.get(34));
					request.setAttribute("groupPricingOtherList5",(ArrayList<InsPricingVO>)groupPricingList.get(35));
					request.setAttribute("groupPricingOtherList6",(ArrayList<InsPricingVO>)groupPricingList.get(36));
					request.setAttribute("groupPricingOtherList7",(ArrayList<InsPricingVO>)groupPricingList.get(37));
					request.setAttribute("groupPricingOtherList8",(ArrayList<InsPricingVO>)groupPricingList.get(38));
					request.setAttribute("groupPricingOtherList9",(ArrayList<InsPricingVO>)groupPricingList.get(39));
					request.setAttribute("groupPricingOtherList10",(ArrayList<InsPricingVO>)groupPricingList.get(40));*/
					
					
					request.setAttribute("grossPremiumMemberGroupLevel",(InsPricingVO)groupPricingList.get(11));
					
					request.setAttribute("policyDuration",(InsPricingVO)groupPricingList.get(12));
					request.setAttribute("exprienceSummery",(ArrayList<InsPricingVO>)groupPricingList.get(13));	
					
					InsPricingVO ins = (InsPricingVO)groupPricingList.get(12);
				
                    request.getSession().setAttribute("groupPricingProducName",ins.getClientCodeDesc());
					modelAndView.addObject("groupPricingSeqId",dashboardVO.getGroupProfileSeqID());
					modelAndView.addObject("groupPricingRefNo",dashboardVO.getPricingRefno());
				
			}else {
				if(!"".equals(editYn)){
					if("N".equalsIgnoreCase(editYn)){
						 modelAndView =   new ModelAndView(strInputScreenreadonly);	
						 request.getSession().setAttribute("editflag",editYn);
					}else{						
						 modelAndView =   new ModelAndView(strInputScreen);	
						 request.getSession().setAttribute("editflag","Y");
					}
				}
				
				
			// modelAndView =   new ModelAndView(strInputScreen);	
				setErrorPageData(strInputScreen,model);	
				String cencorDataFlag="";
				
				 ArrayList alprofileIncomeList=null;
				String[] identfierList = new String[] {"networkList","opticalLimitList","clientCodeList","brokerCodeList",
						"maxBenifitListIp","areaOfCoverList","opCopaypharmacyList","opInvestigationList","opCopyothersList",
						"opticalCopayList","opticalFrameLimitList","dentalLimitList","dentalcopayList","orthodonticsCopay",
						"maternityLimitList","opCopyalahlihospList","opInvestnAlAhliList","opPharmacyAlAhliList","opothersAlAhliList",
						"opConsultAlAhliList","ipCopayList","iPCopayAtAhliList","residencyCountryList","remiumOutputStructureList",
						"maternityPricingList","maternityCopayList","opCopyconsultnList","opCopayList","premiumRefundApproachList",
						"networkListFactor","maternityCopayListWhatif","maxBenifitListOpLimitIp","maxBenifitListOpLimitIpWhatif"};	
				populateData(identfierList,"inputscreen");
				
				ArrayList<CacheObject> alPricingNetworkList = pricingInputScreenService.getHospitalList("1");		 
				request.getSession().setAttribute("alPricingNetworkList", alPricingNetworkList);						 					
				 ArrayList<CacheObject> alPricingAdditionalNetworkList = pricingInputScreenService.getAdditionalHospitalList("1");		 
				 request.getSession().setAttribute("alPricingAdditionalNetworkList", alPricingAdditionalNetworkList);
				 
													
					insPricingVO= pricingInputScreenService.swSelectPricingList(dashboardVO.getGroupProfileSeqID());
					
					
				
					if(insPricingVO !=null) {
						
						 ArrayList<CacheObject>  opLimitList = pricingInputScreenService.getOpLimitlist(insPricingVO.getMaximumBenefitsLimitsDesc());
						 request.getSession().setAttribute("opLimitList", opLimitList);
										    					    						    		 				    		 				    				                
						 request.getSession().setAttribute("fileName1",insPricingVO.getAttachmentname1());
						 request.getSession().setAttribute("fileStream1",insPricingVO.getInputstreamdoc1());
						 request.getSession().setAttribute("fileName2",insPricingVO.getAttachmentname2());
						 request.getSession().setAttribute("fileStream2",insPricingVO.getInputstreamdoc2());
						 request.getSession().setAttribute("fileNam3",insPricingVO.getAttachmentname3());
						 request.getSession().setAttribute("fileStream3",insPricingVO.getInputstreamdoc3());
						 request.getSession().setAttribute("fileName4",insPricingVO.getAttachmentname4());
						 request.getSession().setAttribute("fileStream4",insPricingVO.getInputstreamdoc4());
						 request.getSession().setAttribute("fileName5",insPricingVO.getAttachmentname5());
						 request.getSession().setAttribute("fileStream5",insPricingVO.getInputstreamdoc5());
						 
						 
						 
					}
					
					
			    	request.getSession().setAttribute("noCoverdLives", insPricingVO.getNoCoverdLives());
			    	request.getSession().setAttribute("renevalFlag",insPricingVO.getRenewalYN());
			    	
			    	
			    	 ArrayList<CacheObject> alPricingUnderWrittingList= null;
			    	 alPricingUnderWrittingList = pricingInputScreenService.getUnderWrittingYear(insPricingVO.getClientName());		
			    		    		    	 	    	
			    	 
			    	 request.getSession().setAttribute("alPricingUnderWrittingList", alPricingUnderWrittingList);
			    	 
			    	 
			    	 ArrayList<CacheObject> alPricingPoliciNoList= pricingInputScreenService.getPolicyNo(insPricingVO.getClientName(),insPricingVO.getUnderWritingYear());
					 request.getSession().setAttribute("alPricingPoliciNoList", alPricingPoliciNoList);
					
					if(!insPricingVO.getClientName().equals("")) {
						request.getSession().setAttribute("clientName",insPricingVO.getClientName());
					}
					

					
					
					SimpleDateFormat sd=new SimpleDateFormat("dd/MM/yyyy");
					
					if(insPricingVO.getCoverStartDate() !=null) {
					insPricingVO.setCoverNewStartDate(sd.format(insPricingVO.getCoverStartDate()));
					insPricingVO.setCoverNewEndDate(sd.format(insPricingVO.getCoverEndDate())); 
					}
					
								
					request.getSession().setAttribute("groupPricingSeqId",insPricingVO.getGroupProfileSeqID());
					request.getSession().setAttribute("pricingRefNo",insPricingVO.getPricingRefno());														
					
				    InsPricingVO	 insPricingVO1  =  pricingInputScreenService.getfalgPricingvalue(insPricingVO.getGroupProfileSeqID());
					  String bene_covered_FlagYN = insPricingVO1.getBenecoverFlagYN();
					  String calCPM_FlagYN = insPricingVO1.getBenecoverFlagYN();
					  					
					  request.getSession().setAttribute("completeSaveYN",calCPM_FlagYN);	
					  
					if(bene_covered_FlagYN.equalsIgnoreCase("Y")) {
					
					 alprofileIncomeList= pricingInputScreenService.getBenefitvalueAfter(insPricingVO.getGroupProfileSeqID());
					 ArrayList<InsPricingVO> seq_id= (ArrayList<InsPricingVO>) alprofileIncomeList.get(0);
					
					 Iterator<InsPricingVO> it = seq_id.iterator();
					 while(it.hasNext()){
						 InsPricingVO insVo = it.next();
						Long seqid= insVo.getBenf_typeseqid1();
						
					 }
					
					 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
					 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));
					 		 	 		 
					 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
					 
					 request.getSession().setAttribute("sumTotalLivesMale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMale());
					 request.getSession().setAttribute("sumTotalLivesFemale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemale());
					 request.getSession().setAttribute("sumTotalLivesMaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaleUserPer());
					 request.getSession().setAttribute("sumTotalLivesFemaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemaleUserPer());
					 
					 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
					 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
					 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
					 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());			 
					 request.getSession().setAttribute("totalNoOfLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalCovedLives());			 
					 request.getSession().setAttribute("TotalMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalLivesMaternity());
					 
					 if(((InsPricingVO)alprofileIncomeList.get(3)).getMinMaternity() != null){
						 request.getSession().setAttribute("minMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getMinMaternity());
						 }else{
							 request.getSession().setAttribute("minMaternityLives","");
						 }
						 if(((InsPricingVO)alprofileIncomeList.get(3)).getMaxMaternity()!= null){
						 request.getSession().setAttribute("maxMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getMaxMaternity());
						 }else{
							 request.getSession().setAttribute("maxMaternityLives","");
						 }
					}else {
						
						 alprofileIncomeList= pricingInputScreenService.getBenefitvalueBefore(0l);
						 ArrayList<InsPricingVO> seq_id= (ArrayList<InsPricingVO>) alprofileIncomeList.get(0);
						
						 Iterator<InsPricingVO> it = seq_id.iterator();
						 while(it.hasNext()){
							 InsPricingVO insVo = it.next();
							Long seqid= insVo.getBenf_typeseqid1();
							
						 }
						
						 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
						 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));				 		 	 		 
						 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
						 
						/* request.getSession().setAttribute("sumTotalLivesMale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMale());
						 request.getSession().setAttribute("sumTotalLivesFemale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemale());
						 request.getSession().setAttribute("sumTotalLivesMaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaleUserPer());
						 request.getSession().setAttribute("sumTotalLivesFemaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemaleUserPer());*/
						 
						 
						 request.getSession().setAttribute("sumTotalLivesMale","");
						 request.getSession().setAttribute("sumTotalLivesFemale","");
						 request.getSession().setAttribute("sumTotalLivesMaleUserPer","");
						 request.getSession().setAttribute("sumTotalLivesFemaleUserPer","");
						 
						 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
						 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
						 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
						 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
						
					}
					
			
				
				insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
				insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
			/*	insPricingVO.setOpdeductableserviceYN(insPricingVO.getOpdeductableserviceYN() != "" ?insPricingVO.getOpdeductableserviceYN():"Y");*/
				insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
			/*	insPricingVO.setAlAhlihospOPservices(insPricingVO.getAlAhlihospOPservices() != "" ?insPricingVO.getAlAhlihospOPservices():"Y");*/
				insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
				insPricingVO.setLoadinghospitalCoverage(insPricingVO.getLoadinghospitalCoverage() != 0 ?insPricingVO.getLoadinghospitalCoverage():null);
				insPricingVO.setDiscounthospitalExclusions(insPricingVO.getDiscounthospitalExclusions() != 0 ?insPricingVO.getDiscounthospitalExclusions():null);
				/*insPricingVO.setMaxBeneLimitOth((insPricingVO.getMaternityLimitOth() != null && insPricingVO.getMaternityLimitOth().equals("0")) ?insPricingVO.getMaxBeneLimitOth():null);*/
			
				
				
				statusTest ="";
				
				modelAndView.addObject("insPricingVO",insPricingVO);
				
				//modelAndView.addObject("editYN", editYn);
				
			}
			
		}
					
		return modelAndView;
	}// close inputScreen controller
	

	
	@RequestMapping(value ="/SoftwareInsurancePricing/saveInputScreen" , method = RequestMethod.POST)
	public ModelAndView doSaveInputScreen(@Valid @ModelAttribute("insPricingVO") InsPricingVO insPricingVO,BindingResult result, HttpServletRequest request,Model model) throws Exception{
		
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		setLinks(request);
		 setErrorPageData(strInputScreen, model);		
           if(result.hasErrors()){				
			return modelAndView;
		}		
   
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();	
		
		 String flag=request.getSession().getAttribute("coppyBenefitsFlag") !=null ? (String) request.getSession().getAttribute("coppyBenefitsFlag"):"N";
		
		insPricingVO.setAddedBy(userseqid);		
		if(insPricingVO != null) {	
			
		    Date startD=new SimpleDateFormat("dd/MM/yyyy").parse(insPricingVO.getCoverNewStartDate());
		    Date endD=new SimpleDateFormat("dd/MM/yyyy").parse(insPricingVO.getCoverNewEndDate());
		    insPricingVO.setCoverStartDate(startD);
		    insPricingVO.setCoverEndDate(endD);	
		   
		    if(startD.compareTo(endD) == 0) {
		    	throw new VidalException("error.date.msg");		   
		    }else if(startD.compareTo(endD) > 0) {
		    	throw new VidalException("error.date.msg");		  
		    }
		    
		    insPricingVO.setAttachmentname1((String)request.getSession().getAttribute("fileName1"));
		    insPricingVO.setInputstreamdoc1((InputStream)request.getSession().getAttribute("fileStream1"));
		    insPricingVO.setAttachmentname2((String)request.getSession().getAttribute("fileName2"));
		    insPricingVO.setInputstreamdoc2((InputStream)request.getSession().getAttribute("fileStream2"));
		
		    insPricingVO.setAttachmentname3((String)request.getSession().getAttribute("fileName3"));
		    insPricingVO.setInputstreamdoc3((InputStream)request.getSession().getAttribute("fileStream3"));
		    insPricingVO.setAttachmentname4((String)request.getSession().getAttribute("fileName4"));
		    insPricingVO.setInputstreamdoc4((InputStream)request.getSession().getAttribute("fileStream4"));
		    insPricingVO.setAttachmentname5((String)request.getSession().getAttribute("fileName5"));
		    insPricingVO.setInputstreamdoc5((InputStream)request.getSession().getAttribute("fileStream5"));
		    request.getSession().setAttribute("renevalFlag",insPricingVO.getRenewalYN());
		    
		    insPricingVO.setNetworkListip(insPricingVO.getNetworkList().equals("5")?insPricingVO.getNetworkListip():insPricingVO.getNetworkList());
		    insPricingVO.setNetworkListop(insPricingVO.getNetworkList().equals("5")?insPricingVO.getNetworkListop():insPricingVO.getNetworkList());
		    insPricingVO.setNetworkListopt(insPricingVO.getNetworkList().equals("5")?insPricingVO.getNetworkListopt():insPricingVO.getNetworkList());
		    insPricingVO.setNetworkListdent(insPricingVO.getNetworkList().equals("5")?insPricingVO.getNetworkListdent():insPricingVO.getNetworkList());
		    insPricingVO.setNetworkListmat(insPricingVO.getNetworkList().equals("5")?insPricingVO.getNetworkListmat():insPricingVO.getNetworkList());
		    
	        Long lpricingSeqId=pricingInputScreenService.swSavePricingList(insPricingVO);		        		   
		   
		    if(flag.equals("Y")) {		    	
		    	AdditionalVO additionalVO =(AdditionalVO) request.getSession().getAttribute("additionalVO");
		    	additionalVO.setPricingno(lpricingSeqId);		    			    	
		    	int saveStatus=additionalservice.getsave(additionalVO);		    			    	
		    }
	        				    
		    if(lpricingSeqId > 0) {
		    	modelAndView.addObject("msg", "Details added successfully");
		    	insPricingVO= pricingInputScreenService.swSelectPricingList(lpricingSeqId);		    			    			    		    	
		    	
		    	 request.getSession().setAttribute("noCoverdLives", insPricingVO.getTotalCovedLives());
		    	 
		    	 int fileCou=0;
		    	 if(insPricingVO !=null) {
		    		
		    		
					 request.getSession().setAttribute("fileName1",insPricingVO.getAttachmentname1());
					 request.getSession().setAttribute("fileStream1",insPricingVO.getInputstreamdoc1());
					 request.getSession().setAttribute("fileName2",insPricingVO.getAttachmentname2());
					 request.getSession().setAttribute("fileStream2",insPricingVO.getInputstreamdoc2());
					 request.getSession().setAttribute("fileNam3",insPricingVO.getAttachmentname3());
					 request.getSession().setAttribute("fileStream3",insPricingVO.getInputstreamdoc3());
					 request.getSession().setAttribute("fileName4",insPricingVO.getAttachmentname4());
					 request.getSession().setAttribute("fileStream4",insPricingVO.getInputstreamdoc4());
					 request.getSession().setAttribute("fileName5",insPricingVO.getAttachmentname5());
					 request.getSession().setAttribute("fileStream5",insPricingVO.getInputstreamdoc5());
					 insPricingVO.setLoadinghospitalCoverage(insPricingVO.getLoadinghospitalCoverage() != 0 ?insPricingVO.getLoadinghospitalCoverage():null);
					 insPricingVO.setDiscounthospitalExclusions(insPricingVO.getDiscounthospitalExclusions() != 0 ?insPricingVO.getDiscounthospitalExclusions():null);
					 ArrayList<CacheObject>  opLimitList = pricingInputScreenService.getOpLimitlist(insPricingVO.getMaximumBenefitsLimitsDesc());
					 request.getSession().setAttribute("opLimitList", opLimitList);
				}
		    	
		    	 
		    	 SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		    	 insPricingVO.setCoverNewStartDate(formatter.format(insPricingVO.getCoverStartDate()));
		    	 insPricingVO.setCoverNewEndDate(formatter.format(insPricingVO.getCoverEndDate()));	
		    	 request.getSession().setAttribute("groupPricingSeqId",insPricingVO.getGroupProfileSeqID());
				 request.getSession().setAttribute("pricingRefNo",insPricingVO.getPricingRefno());
				 request.getSession().setAttribute("completeSaveYN","Y");
				
				 request.getSession().setAttribute("editflag","Y");
				 statusTest ="";
				 
		    }	
		  
		    modelAndView.addObject("insPricingVO", insPricingVO);		    	         		
		}
			
		
		return modelAndView;
	}
	
	@RequestMapping(value ="/SoftwareInsurancePricing/proceedInputScreen" , method = RequestMethod.POST)
	public ModelAndView doProceedInputScreen(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,BindingResult result, HttpServletRequest request,Model model) throws Exception{
		
		ModelAndView modelAndView = new ModelAndView("riskprimimumscreen");	
		setLinks(request);
		 setErrorPageData("riskprimimumscreen", model);
		 
		    if(result.hasErrors()){				
				return modelAndView;
			}		
	   
   
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");
		
		if(insPricingVO.getGroupProfileSeqID() !=null) {		
			statusTest ="";
		}else {					
			statusTest ="New,";
		}
				 
		 userAccessSecurityProfile.getSecurityProfile().setActiveTab("Risk Premium-Working");
		
		return new ModelAndView("forward:/SoftwareInsurancePricing/RiskPremium-Working");
		
	}
	
	

	
	@RequestMapping(value ="SoftwareInsurancePricing/copyInputData" , method = RequestMethod.POST)
	public ModelAndView copyInputData(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,HttpServletRequest request,Model model) throws Exception{
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		setErrorPageData(strInputScreen,model);	
		 ArrayList alprofileIncomeList=null;
		String[] identfierList = new String[] {"networkList","opticalLimitList","clientCodeList","brokerCodeList",
				"maxBenifitListIp","areaOfCoverList","opCopaypharmacyList","opInvestigationList","opCopyothersList",
				"opticalCopayList","opticalFrameLimitList","dentalLimitList","dentalcopayList","orthodonticsCopay",
				"maternityLimitList","opCopyalahlihospList","opInvestnAlAhliList","opPharmacyAlAhliList","opothersAlAhliList",
				"opConsultAlAhliList","ipCopayList","iPCopayAtAhliList","residencyCountryList","remiumOutputStructureList",
				"maternityPricingList","maternityCopayList","opCopyconsultnList","opCopayList","premiumRefundApproachList",
				"networkListFactor","maxBenifitListOpLimitIp","maxBenifitListOpLimitIpWhatif"};					
		populateData(identfierList,"inputscreen");
		
		
		if(insPricingVO != null) {
			
			AdditionalVO additionalVO = new AdditionalVO();
			additionalVO.setPricingno(insPricingVO.getGroupProfileSeqID());
			additionalVO=additionalservice.getdetails(additionalVO); 
			request.getSession().setAttribute("additionalVO",additionalVO);
			request.getSession().setAttribute("coppyBenefitsFlag","Y");
			 
			request.setAttribute("pricingTempNo",insPricingVO.getPricingRefno());
			request.setAttribute("copyType","I");
			
			 insPricingVO.setGroupProfileSeqID(null);
			 insPricingVO.setPricingRefno("");
			/* insPricingVO.setRenewalYN("N");*/
			 insPricingVO.setRenewalYN(insPricingVO.getRenewalYN());
			 insPricingVO.setClientCode(null);
			 insPricingVO.setGroupRegSeqId(null);
			 insPricingVO.setClientName("");
			 insPricingVO.setUnderWritingYear("");
			 insPricingVO.setPreviousPolicyNo("");
			 insPricingVO.setPolicycategory("");
			 insPricingVO.setPricingRefno("");
			 insPricingVO.setBrokerCode("");
			 insPricingVO.setBrokername("");
			 insPricingVO.setCoverNewStartDate("");
			 insPricingVO.setCoverNewEndDate("");
		     insPricingVO.setComments("");
		     insPricingVO.setTotalCovedLives("");
		  /*   request.getSession().removeAttribute("groupPricingSeqId");
		     request.getSession().removeAttribute("pricingRefNo");*/
			 request.getSession().setAttribute("groupPricingSeqId","");
			 request.getSession().setAttribute("pricingRefNo","");
			 request.getSession().removeAttribute("noCoverdLives");
			 
				insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
				insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
				insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
				insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
			 modelAndView.addObject("insPricingVO",insPricingVO);
			 alprofileIncomeList= pricingInputScreenService.getBenefitvalueBefore(0l);	
			 ArrayList<InsPricingVO> seq_id=(ArrayList<InsPricingVO>) alprofileIncomeList.get(0);
			 Iterator<InsPricingVO> it = seq_id.iterator();
			 while(it.hasNext()){
				 InsPricingVO insVo = it.next();
				Long seqid= insVo.getBenf_typeseqid1();
				
			 }
			
			 
			 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
			 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));			 		 	 		 
			 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
			 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
			 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
			 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
			 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
			 modelAndView.addObject("successMsg","Copy benefits & Additional Benefits successfully");
			 
		}else {
              
			insPricingVO = new InsPricingVO();
			
			insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
			insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
			insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
			insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
		 	 modelAndView.addObject("insPricingVO",insPricingVO);		
		
		 	 
			 alprofileIncomeList= pricingInputScreenService.getBenefitvalueBefore(0l);	
			 ArrayList<InsPricingVO> seq_id=(ArrayList<InsPricingVO>) alprofileIncomeList.get(0);
			 Iterator<InsPricingVO> it = seq_id.iterator();
			 while(it.hasNext()){
				 InsPricingVO insVo = it.next();
				Long seqid= insVo.getBenf_typeseqid1();
			
			 }
			
			 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
			 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));			 		 	 		 
			 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
			 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
			 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
			 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
			 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
		}
		 statusTest ="New,";
		 request.getSession().removeAttribute("noCoverdLives");
		return modelAndView;
	}
	
	
	@RequestMapping(value ="SoftwareInsurancePricing/copyInputDataCensus" , method = RequestMethod.POST)
	public ModelAndView copyInputDataCensus(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,HttpServletRequest request,Model model) throws Exception{
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		setErrorPageData(strInputScreen,model);	
		 ArrayList alprofileIncomeList=null;
		String[] identfierList = new String[] {"networkList","opticalLimitList","clientCodeList","brokerCodeList",
				"maxBenifitListIp","areaOfCoverList","opCopaypharmacyList","opInvestigationList","opCopyothersList",
				"opticalCopayList","opticalFrameLimitList","dentalLimitList","dentalcopayList","orthodonticsCopay",
				"maternityLimitList","opCopyalahlihospList","opInvestnAlAhliList","opPharmacyAlAhliList","opothersAlAhliList",
				"opConsultAlAhliList","ipCopayList","iPCopayAtAhliList","residencyCountryList","remiumOutputStructureList",
				"maternityPricingList","maternityCopayList","opCopyconsultnList","opCopayList","premiumRefundApproachList","networkListFactor","maxBenifitListOpLimitIp"};					
		populateData(identfierList,"inputscreen");		
		
		if(insPricingVO != null) { 
			
		    	AdditionalVO additionalVO = new AdditionalVO();
		       	additionalVO.setPricingno(insPricingVO.getGroupProfileSeqID());
		   	additionalVO=additionalservice.getdetails(additionalVO); 
		 	request.getSession().setAttribute("additionalVO",additionalVO);
			request.getSession().setAttribute("coppyBenefitsFlag","Y");
			request.setAttribute("pricingTempNo",insPricingVO.getPricingRefno());  
			      InsPricingVO insPricingVO1  =  pricingInputScreenService.getfalgPricingvalue(insPricingVO.getGroupProfileSeqID());
				  String bene_covered_FlagYN = insPricingVO1.getBenecoverFlagYN();
				  String calCPM_FlagYN = insPricingVO1.getBenecoverFlagYN();
				  request.getSession().setAttribute("completeSaveYN","N");
					if(bene_covered_FlagYN.equalsIgnoreCase("Y")) {
						
					 alprofileIncomeList= pricingInputScreenService.getBenefitvalueAfter(insPricingVO.getGroupProfileSeqID());	
					 
					 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
					 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));
					 		 	 		 
					/* request.getSession().setAttribute("sumTotalLives","0");*/
					 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
					 
					 request.getSession().setAttribute("sumTotalLivesMale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMale());
					 request.getSession().setAttribute("sumTotalLivesFemale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemale());
					 request.getSession().setAttribute("sumTotalLivesMaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaleUserPer());
					 request.getSession().setAttribute("sumTotalLivesFemaleUserPer",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemaleUserPer());
					 
					 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
					 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
					 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
					 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());			 
					 request.getSession().setAttribute("totalNoOfLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalCovedLives());			 
					 request.getSession().setAttribute("TotalMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalLivesMaternity());
					}else {
						
						 alprofileIncomeList= pricingInputScreenService.getBenefitvalueBefore(0l);	
						 ArrayList<InsPricingVO> seq_id= (ArrayList<InsPricingVO>) alprofileIncomeList.get(0);
						 Iterator<InsPricingVO> it = seq_id.iterator();
						 while(it.hasNext()){
							 insPricingVO = it.next();
							Long seqid= insPricingVO.getBenf_typeseqid1();
						 }


						 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
						 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));				 		 	 		 
						 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());									 
						 
						 request.getSession().setAttribute("sumTotalLivesMale","");
						 request.getSession().setAttribute("sumTotalLivesFemale","");
						 request.getSession().setAttribute("sumTotalLivesMaleUserPer","");
						 request.getSession().setAttribute("sumTotalLivesFemaleUserPer","");
						 
						 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
						 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
						 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
						 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
						
					}
				  
					 insPricingVO.setGroupProfileSeqID(null);
					 insPricingVO.setPricingRefno("");
					
				/*																		
					 insPricingVO.setCoverNewStartDate("");
					 insPricingVO.setCoverNewEndDate("");*/
				     insPricingVO.setComments("");
				  
			        request.getSession().setAttribute("groupPricingSeqId","");
				    request.getSession().setAttribute("pricingRefNo","");
				  /*  request.getSession().removeAttribute("noCoverdLives");*/
				    
				    insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
					insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
					insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
					insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
			        modelAndView.addObject("insPricingVO",insPricingVO);
			        modelAndView.addObject("successMsg","Copy benefits and census & Additional Benefits successfully");
		
			 
		}else {
			insPricingVO = new InsPricingVO();
			insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
			insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
			insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
			insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
			 modelAndView.addObject("insPricingVO",insPricingVO);		
			 alprofileIncomeList= pricingInputScreenService.getBenefitvalueBefore(0l);	
			 ArrayList<InsPricingVO> seq_id=(ArrayList<InsPricingVO>) alprofileIncomeList.get(0);
			 Iterator<InsPricingVO> it = seq_id.iterator();
			 while(it.hasNext()){
				 InsPricingVO insVo = it.next();
				Long seqid= insVo.getBenf_typeseqid1();
				
			 }
			
			 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
			 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));			 		 	 		 
			 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
			 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
			 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
			 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
			 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
		}
			
		return modelAndView;
	}
	
	@RequestMapping(value ="SoftwareInsurancePricing/getPolicyStatusInfo" , method = RequestMethod.POST)
	public ModelAndView getPolicyStatusInfo(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,HttpServletRequest request,Model model) throws Exception{
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strInputScreen);
		setErrorPageData(strInputScreen,model);	
		String[] identfierList = new String[] {"networkList","opticalLimitList","clientCodeList","brokerCodeList",
				"maxBenifitListIp","areaOfCoverList","opCopaypharmacyList","opInvestigationList","opCopyothersList",
				"opticalCopayList","opticalFrameLimitList","dentalLimitList","dentalcopayList","orthodonticsCopay",
				"maternityLimitList","opCopyalahlihospList","opInvestnAlAhliList","opPharmacyAlAhliList","opothersAlAhliList",
				"opConsultAlAhliList","ipCopayList","iPCopayAtAhliList","residencyCountryList","remiumOutputStructureList",
				"maternityPricingList","maternityCopayList","opCopyconsultnList","opCopayList","premiumRefundApproachList","networkListFactor"};					
		populateData(identfierList,"inputscreen");
		ArrayList dataList=new ArrayList<>();
		String clientCode=insPricingVO.getClientCode();
		String policyNumber=insPricingVO.getPreviousPolicyNo();
		String clientName=insPricingVO.getClientName();
		String brokertype=insPricingVO.getBrokerCode();
		String brokername=insPricingVO.getBrokername();
		String renewalYN=insPricingVO.getRenewalYN();
		String planName=insPricingVO.getProductCategory();
		
		
		
		InsPricingVO insPricingVOPrev  =new InsPricingVO();
		
		   dataList.add(policyNumber);
           dataList.add(clientName);
           dataList.add(clientCode);
           
           if(policyNumber!=null&&clientName!=null&&clientCode!=null)
           	insPricingVOPrev= pricingInputScreenService.getPolicyStatusInfo(dataList); 
		
          
          insPricingVOPrev.setPolicycategory(insPricingVOPrev.getPolicycategory());
          insPricingVOPrev.setGroupProfileSeqID(insPricingVO.getGroupProfileSeqID());
          insPricingVOPrev.setPricingRefno(insPricingVO.getPricingRefno());
          insPricingVOPrev.setClientCode(insPricingVO.getClientCode());
          insPricingVOPrev.setGroupRegSeqId(insPricingVO.getGroupRegSeqId());
          insPricingVOPrev.setClientName(insPricingVO.getClientName());
          insPricingVOPrev.setUnderWritingYear(insPricingVO.getUnderWritingYear());
          insPricingVOPrev.setPreviousPolicyNo(insPricingVO.getPreviousPolicyNo());                   
          insPricingVOPrev.setPolicycategory(insPricingVOPrev.getPolicycategory());
          insPricingVOPrev.setBrokerCode(brokertype);
          insPricingVOPrev.setBrokername(brokername);
          insPricingVOPrev.setRenewalYN(renewalYN);
          insPricingVOPrev.setProductCategory(planName);
          
        
          insPricingVOPrev.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
          insPricingVOPrev.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
        /*  insPricingVOPrev.setOpdeductableserviceYN(insPricingVO.getOpdeductableserviceYN() != "" ?insPricingVO.getOpdeductableserviceYN():"Y");*/
          insPricingVOPrev.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
       /*   insPricingVOPrev.setAlAhlihospOPservices(insPricingVO.getAlAhlihospOPservices() != "" ?insPricingVO.getAlAhlihospOPservices():"Y");*/
          insPricingVOPrev.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");

          request.setAttribute("saveChangeYn","T");
       	  modelAndView.addObject("insPricingVO",insPricingVOPrev);		
		  return modelAndView;
	}
	
	
	@RequestMapping(value ="/SoftwareInsurancePricing/downloadSample" , method = RequestMethod.POST)
	public void downloadSample(HttpServletRequest request,HttpServletResponse response,Model model) throws Exception{		
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		ByteArrayOutputStream baos=null;
		OutputStream sos = null;
		FileInputStream fis= null; 
		File file = null;
		BufferedInputStream bis =null;
		
				response.setContentType("application/txt");
				/*response.setHeader("Content-Disposition", "attachment;filename=Qatar StandardTemplateForCensusAutoUpload.xls");*/
				response.setHeader("Content-Disposition", "attachment;filename=CensusStandardTemplateForAutoUpload V1 March2020.xls");
				 String path=UXUtility.checkNull(TTKPropertiesReader.getPropertyValue("filePathPath")); 
		/*	String fileName = "D:\\pricingSampleForm\\"+"PricingMemTemplate.xls";*/
			String fileName = path+"Qatar StandardTemplateForCensusAutoUpload.xls";
			file = new File(fileName);
			
			fis = new FileInputStream(file);
			bis = new BufferedInputStream(fis);
			baos=new ByteArrayOutputStream();
			int ch;
			while ((ch = bis.read()) != -1) baos.write(ch);
			sos = response.getOutputStream();
			baos.writeTo(sos);  
			baos.flush();      
			sos.flush(); 
		
		
	
	}
	@RequestMapping(value ="/SoftwareInsurancePricing/downloadCensusFile" , method = RequestMethod.POST)
	public void downloadSampleCensus(@RequestParam("fileName") String fileName, HttpServletRequest request,HttpServletResponse response,Model model) throws Exception{		
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		ByteArrayOutputStream baos=null;
		OutputStream sos = null;
		FileInputStream fis= null; 
		File file = null;
		BufferedInputStream bis =null;
		
				response.setContentType("application/txt");
				response.setHeader("Content-Disposition", "attachment;filename="+fileName+"");
				 String path=UXUtility.checkNull(TTKPropertiesReader.getPropertyValue("QatarXmlPricingDir")); 
		/*	String fileName = "D:\\pricingSampleForm\\"+"PricingMemTemplate.xls";*/
			String downloadFilename = path+fileName;
			file = new File(downloadFilename);
			
			fis = new FileInputStream(file);
			bis = new BufferedInputStream(fis);
			baos=new ByteArrayOutputStream();
			int ch;
			while ((ch = bis.read()) != -1) baos.write(ch);
			sos = response.getOutputStream();
			baos.writeTo(sos);  
			baos.flush();      
			sos.flush(); 
		
		
	
	}
	
	
	
	@RequestMapping(value = {"/SoftwareInsurancePricing/getClientName"},method={RequestMethod.POST})
	public ModelAndView  probmaicMailId(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,@RequestParam("clientCode") String clientCode, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		String clientName="";
		  ArrayList<CacheObject> alPricingUnderWrittingList= null;
		  StringBuilder sb= new StringBuilder();
		
		  
		try {
			clientName =pricingInputScreenService.getClientName(clientCode);
			request.getSession().setAttribute("clientName",clientName);
			insPricingVO.setClientName(clientName);
            insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
            insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
            insPricingVO.setOpdeductableserviceYN(insPricingVO.getOpdeductableserviceYN() != "" ?insPricingVO.getOpdeductableserviceYN():"Y");
            insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
            insPricingVO.setAlAhlihospOPservices(insPricingVO.getAlAhlihospOPservices() != "" ?insPricingVO.getAlAhlihospOPservices():"Y");
            insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
            
			if(!clientName.equals("")) {
				
				
				alPricingUnderWrittingList = pricingInputScreenService.getUnderWrittingYear(clientName);							
				request.getSession().setAttribute("alPricingUnderWrittingList", alPricingUnderWrittingList);
				request.getSession().setAttribute("alPricingPoliciNoList","");
				
				/*if(alPricingUnderWrittingList !=null) {
				sb.append("<option value=\"\">Select</option>");		
					for(CacheObject it:alPricingUnderWrittingList) {
						sb.append("<option value=\""+it.getCacheId()+"\">"+it.getCacheDesc()+"</option>");												
					}					
				}*/
				
										
			}
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		     
		request.setAttribute("saveChangeYn","T");
		modelAndView.addObject("insPricingVO",insPricingVO);		
		  return modelAndView;
		 
	}
	
/*	@RequestMapping(value = {"/SoftwareInsurancePricing/getHospitalDetails"},method={RequestMethod.POST})
	public ModelAndView  getHospitalDetails(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,@RequestParam("networkCode") String networkCode,@RequestParam("focusId") String focusId, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		
		  System.out.println("focusId..."+focusId);
		  ArrayList<CacheObject> alPricingNetworkList= null;
		
		  alPricingNetworkList = pricingInputScreenService.getHospitalList(networkCode);							
		  request.getSession().setAttribute("alPricingNetworkList", alPricingNetworkList);
	
	      request.setAttribute("focusId",focusId);	   
		  modelAndView.addObject("insPricingVO",insPricingVO);		
		  return modelAndView;
		 
	}*/
	
	@RequestMapping(value = {"/SoftwareInsurancePricing/getHospitalDetails"},method={RequestMethod.GET})
	public @ResponseBody String  getHospitalDetails(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,@RequestParam("networkCode") String networkCode,@RequestParam("focusId") String focusId, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		
		 StringBuilder sb1 = new StringBuilder();
		 sb1.append("<option value=\"\">Not applicable</option>");	
		 try {
		  ArrayList<CacheObject> alPricingNetworkList= null;
		
		  alPricingNetworkList = pricingInputScreenService.getHospitalList(networkCode);
		  
		  if(alPricingNetworkList != null) {			  
			  for(CacheObject item:alPricingNetworkList) {
				  sb1.append("<option value=\""+item.getCacheId()+"\">"+item.getCacheDesc()+"</option>");				  
			  }
		  }
		  
		  request.getSession().setAttribute("alPricingNetworkList", alPricingNetworkList);
		 }catch(Exception e) {
			 sb1.append("<option value=\"\">Not applicable</option>");	
		 }
	    
		 StringBuilder sb2 = new StringBuilder();
		 sb2.append("<option value=\"\">Not applicable</option>");	
		 try {
		  ArrayList<CacheObject> alPricingAdditionalNetworkList= null;
		
		  alPricingAdditionalNetworkList = pricingInputScreenService.getAdditionalHospitalList(networkCode);
		  
		  if(alPricingAdditionalNetworkList != null) {			  
			  for(CacheObject item:alPricingAdditionalNetworkList) {
				  sb2.append("<option value=\""+item.getCacheId()+"\">"+item.getCacheDesc()+"</option>");				  
			  }
		  }
		  
		  request.getSession().setAttribute("alPricingAdditionalNetworkList", alPricingAdditionalNetworkList);
		 }catch(Exception e) {
			 sb2.append("<option value=\"\">Not applicable</option>");	
		 }
	    
		 
		
		  return sb1.toString()+"~"+sb2.toString();
		 
	}
	
	@RequestMapping(value = {"/SoftwareInsurancePricing/serachGroupName"},method={RequestMethod.GET})
	public ModelAndView  getGroupName(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,HttpServletRequest request,HttpServletResponse response) throws Exception{
		ModelAndView modelAndView = new ModelAndView("pricingTableGrid");	
	
		
		
		TableData politableData = null;
		String strPageID = UXUtility.checkNull(request.getParameter("pageId"));
		String strSortID = UXUtility.checkNull(request.getParameter("sortId"));
		if((request.getSession()).getAttribute("politableData") == null)
		{
			politableData = new TableData();
		}
		else
		{
			politableData = (TableData)(request.getSession()).getAttribute("politableData");
		}
		
		
		 ArrayList alGroupList= null;
		if (!strPageID.equals("") || !strSortID.equals("")) {
			if (!strPageID.equals("")) {
			
				
				politableData.setCurrentPage(Integer.parseInt(UXUtility.checkNull(request.getParameter("pageId"))));
				
				return modelAndView;
			} else {
			
				politableData.setSortData(UXUtility.checkNull(request.getParameter("sortId")));
				politableData.modifySearchData("sort");
				
			}
		} else {
			// preAuth Number : COM-0207-PA-0000118
			politableData.createTableInfo("PolicyGroupTable", null);
			politableData.setSearchData(this.polpulateSearchCriteriaForPolicy(request));
			politableData.modifySearchData("search");
								
		}
		alGroupList = pricingInputScreenService.getGroupList(politableData.getSearchData());
		
	
		
		politableData.setData(alGroupList, "search");
		request.getSession().setAttribute("politableData",politableData);
		
		return modelAndView;
		 
	}
	
	
	private ArrayList<Object> polpulateSearchCriteriaForPolicy(HttpServletRequest request) {
		ArrayList<Object> alSearchParam = new ArrayList<Object>();
		alSearchParam.add(request.getParameter("serachGroupId"));
		alSearchParam.add(request.getParameter("serachGroupName"));				
		return alSearchParam;
	}
	
	@RequestMapping(value ="/SoftwareInsurancePricing/selectGroupName" , method = RequestMethod.POST)
	public ModelAndView selectGroupName(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,HttpServletRequest request,Model model) throws Exception{		
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		 ArrayList<CacheObject> alPricingUnderWrittingList= null;
		 TableData politableData = null;
		
		if ((request.getSession()).getAttribute("politableData") != null) {
			politableData = (TableData) (request.getSession()).getAttribute("politableData");
		
			if (!(UXUtility.checkNull(request.getParameter("rownum")).equals(""))) {
				
				PolicyGroupVO  policiGroupVo = (PolicyGroupVO) politableData.getRowInfo(Integer.parseInt(request.getParameter("rownum")));
				
				
				insPricingVO.setClientCode(policiGroupVo.getGroupRegnSeqID().toString());
				insPricingVO.setClientName(policiGroupVo.getGroupName());
				insPricingVO.setGroupRegSeqId(policiGroupVo.getGroupID());
				insPricingVO.setUnderWritingYear("");
				insPricingVO.setPreviousPolicyNo("");
				insPricingVO.setPolicycategory("");
				insPricingVO.setPricingRefno(insPricingVO.getPricingRefno());
				
				request.getSession().setAttribute("clientName",policiGroupVo.getGroupName());
			
				
				
				
				alPricingUnderWrittingList = pricingInputScreenService.getUnderWrittingYear(policiGroupVo.getGroupName());							
				request.getSession().setAttribute("alPricingUnderWrittingList", alPricingUnderWrittingList);
				request.getSession().setAttribute("alPricingPoliciNoList","");
				/*if(alPricingUnderWrittingList != null) {
				 ArrayList<CacheObject> alPricingPoliciNoList= pricingInputScreenService.getPolicyNo(policiGroupVo.getGroupName(),alPricingUnderWrittingList.get(0).getCacheId());
				 request.getSession().setAttribute("alPricingPoliciNoList",alPricingPoliciNoList);
				}else {
					 request.getSession().setAttribute("alPricingPoliciNoList","");
				}*/
				
			}
		}	

	
		return modelAndView;
	}
	
	
	@RequestMapping(value = {"/SoftwareInsurancePricing/SwInsPricingAction"},method={RequestMethod.POST})
	 public ModelAndView fetchKeyCoverage(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,@RequestParam("clientText") String clientText,@RequestParam("previousPolicyNo") String previousPolicyNo,@RequestParam("renewalYN") String renewalYN,@RequestParam("clientCode") String clientCode, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		
		
		  String prievousCatogry=insPricingVO.getPolicycategory();
		  InsPricingVO dbinsPricingVO=null;
		  
		  dbinsPricingVO= pricingInputScreenService.swFetchScreen1(insPricingVO);
		  
		 
		  
		  ArrayList dataList=new ArrayList();
		  
		 
		  dataList.add(insPricingVO.getPreviousPolicyNo());        
          dataList.add(insPricingVO.getClientName());
          dataList.add(clientText);
          
          InsPricingVO insPricingVOPrev = pricingInputScreenService.getPolicyStatusInfo(dataList);
          
		    if(dbinsPricingVO.getNotifyerror()!=null&&!dbinsPricingVO.getNotifyerror().equals("")){
		    
		    	if("N".equals(renewalYN)){
		    		
		    	}else{
//		    	request.setAttribute("fetchErrorData", dbinsPricingVO.getNotifyerror());			    	
		    	request.setAttribute("errorMsg",dbinsPricingVO.getNotifyerror()); 
		    	}
		    }else{
		        	
		    	 SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		    	 if(insPricingVOPrev.getCoverStartDate() !=null) {
		    		 dbinsPricingVO.setCoverNewStartDate(formatter.format(insPricingVOPrev.getCoverStartDate()));
		    	 }else {
		    		 insPricingVO.setCoverNewStartDate("");
		    	 }
		    	
		    	 if(insPricingVOPrev.getCoverEndDate() !=null) {
		    		 dbinsPricingVO.setCoverNewEndDate(formatter.format(insPricingVOPrev.getCoverEndDate()));	
		    	 }else {
		    		 insPricingVO.setCoverNewEndDate("");
		    	 }
		    	    dbinsPricingVO.setRenewalYN(renewalYN);
				   /* dbinsPricingVO.setPricingRefno();//BK
*/				    dbinsPricingVO.setClientCode(clientCode);
		/*		    dbinsPricingVO.setClientName(clientName);*/
				    dbinsPricingVO.setPreviousPolicyNo(previousPolicyNo);
				    dbinsPricingVO.setPolicycategory(prievousCatogry);
					  
				    dbinsPricingVO.setInpatientBenefit(dbinsPricingVO.getInpatientBenefit() != "" ?dbinsPricingVO.getInpatientBenefit():"Y");
				    dbinsPricingVO.setOutpatientBenefit(dbinsPricingVO.getOutpatientBenefit() != "" ?dbinsPricingVO.getOutpatientBenefit():"Y");
				/*    dbinsPricingVO.setOpdeductableserviceYN(dbinsPricingVO.getOpdeductableserviceYN() != "" ?dbinsPricingVO.getOpdeductableserviceYN():"Y");*/
				    dbinsPricingVO.setAlAhlihospital(dbinsPricingVO.getAlAhlihospital() != "" ?dbinsPricingVO.getAlAhlihospital():"Y");
				   /* dbinsPricingVO.setAlAhlihospOPservices(dbinsPricingVO.getAlAhlihospOPservices() != "" ?dbinsPricingVO.getAlAhlihospOPservices():"Y");*/
				    dbinsPricingVO.setProRATALimitApplicable(dbinsPricingVO.getProRATALimitApplicable() != "" ?dbinsPricingVO.getProRATALimitApplicable():"N");
				    dbinsPricingVO.setAreaOfCoverVariations("");
					
				    request.setAttribute("fetchFlag","Y");
					modelAndView.addObject("insPricingVO", dbinsPricingVO);
		    }
		 
		  return modelAndView;		 
	}
	
	@RequestMapping(value ="/SoftwareInsurancePricing/getPolicyNo" , method = RequestMethod.POST)
	public ModelAndView getPolicyNo(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,HttpServletRequest request,Model model) throws Exception{		
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		
		  ArrayList<CacheObject> alPricingPoliciNoList= pricingInputScreenService.getPolicyNo(insPricingVO.getClientName(),insPricingVO.getUnderWritingYear());
		  request.getSession().setAttribute("alPricingPoliciNoList", alPricingPoliciNoList);
		
		  insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
          insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
         /* insPricingVO.setOpdeductableserviceYN(insPricingVO.getOpdeductableserviceYN() != "" ?insPricingVO.getOpdeductableserviceYN():"Y");*/
          insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
         /* insPricingVO.setAlAhlihospOPservices(insPricingVO.getAlAhlihospOPservices() != "" ?insPricingVO.getAlAhlihospOPservices():"Y");*/
          insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
          insPricingVO.setPolicycategory("");
          request.setAttribute("saveChangeYn","T");
		modelAndView.addObject("insPricingVO",insPricingVO);			
		return modelAndView;
	}
	
	
	
	@RequestMapping(value ="/SoftwareInsurancePricing/saveIncome" , method = RequestMethod.POST)
	public ModelAndView saveIncome(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,HttpServletRequest request,Model model) throws Exception{
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strInputScreen);
		 setErrorPageData(strInputScreen, model);
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();
		insPricingVO.setAddedBy(userseqid);
		
		

		
		
		if(insPricingVO.getGroupProfileSeqID() == null) {			
			
			InsPricingVO insPricingVOCensus= pricingInputScreenService.beforeSeveCensusData(0l, userseqid) ;
			
			
			
			request.getSession().setAttribute("groupPricingSeqId",insPricingVOCensus.getGroupProfileSeqID());
			request.getSession().setAttribute("pricingRefNo",insPricingVOCensus.getPricingRefno());
			insPricingVO.setGroupProfileSeqID(insPricingVOCensus.getGroupProfileSeqID());			
		}
		
		int strTransactionseqId= pricingInputScreenService.swSaveIncomeProfile(insPricingVO);
		
		if(request.getParameter("maxMaternity") != null){
		String maxval= request.getParameter("maxMaternity");
		
		insPricingVO.setMaxMaternity(maxval);
		}
		if(request.getParameter("minMaternity") != null){
		String minval=request.getParameter("minMaternity");
		
		insPricingVO.setMinMaternity(minval);
		}
		
	
		int strmatAgeBand= pricingInputScreenService.swsaveCensusMatAgeband(insPricingVO);
		
	
		
		int nationalitysave = pricingInputScreenService.swSaveIncomeNatProfile(insPricingVO);
		
		
		
		 ArrayList alprofileIncomeList= pricingInputScreenService.getBenefitvalueAfter(insPricingVO.getGroupProfileSeqID());
	 
		 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
		 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));
			request.getSession().setAttribute("noCoverdLives", ((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
		 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
		 request.getSession().setAttribute("sumTotalLivesMale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMale());
		 request.getSession().setAttribute("sumTotalLivesFemale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemale());
		 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
		 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
		 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
		 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
		 		 
		 request.getSession().setAttribute("totalNoOfLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalCovedLives());
		 
		 request.getSession().setAttribute("TotalMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalLivesMaternity());
		 
		 if(((InsPricingVO)alprofileIncomeList.get(3)).getMinMaternity() != null){
		 request.getSession().setAttribute("minMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getMinMaternity());
		 }else{
			 request.getSession().setAttribute("minMaternityLives","");
		 }
		 if(((InsPricingVO)alprofileIncomeList.get(3)).getMaxMaternity()!= null){
		 request.getSession().setAttribute("maxMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getMaxMaternity());
		 }else{
			 request.getSession().setAttribute("maxMaternityLives","");
		 }

		 insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
         insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
     /*    insPricingVO.setOpdeductableserviceYN(insPricingVO.getOpdeductableserviceYN() != "" ?insPricingVO.getOpdeductableserviceYN():"Y");*/
         insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
       /*  insPricingVO.setAlAhlihospOPservices(insPricingVO.getAlAhlihospOPservices() != "" ?insPricingVO.getAlAhlihospOPservices():"Y");*/
         insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
		 
		 modelAndView.addObject("insPricingVO",insPricingVO);
		
		return modelAndView;
	}
	
	
	
	
	@RequestMapping(value ="/SoftwareInsurancePricing/doUploadMemDetails" , method = RequestMethod.POST)
	public ModelAndView uploadMemDetails(@ModelAttribute("insPricingVO")InsPricingVO insPricingVO,HttpServletRequest request,Model model) throws Exception{
		setLinks(request);
		ModelAndView modelAndView = new ModelAndView(strInputScreen);
		setErrorPageData(strInputScreen,model);	
		 Object[] excelData=null;
		 FileOutputStream outputStream = null;
							
		
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession()
				.getAttribute("userAccessSecurityProfile");
		long userseqid = userAccessSecurityProfile.getUSER_SEQ_ID();
		boolean flagcheckSave=false;
		
		if(insPricingVO.getGroupProfileSeqID() == null) {			
		
			InsPricingVO insPricingVOCensus= pricingInputScreenService.beforeSeveCensusData(0l, userseqid) ;					
			request.getSession().setAttribute("groupPricingSeqId",insPricingVOCensus.getGroupProfileSeqID());
			request.getSession().setAttribute("pricingRefNo",insPricingVOCensus.getPricingRefno());
			insPricingVO.setGroupProfileSeqID(insPricingVOCensus.getGroupProfileSeqID());	
			insPricingVO.setPricingRefno(insPricingVOCensus.getPricingRefno());
			flagcheckSave=true;
		}
		
		insPricingVO.setAddedBy(userseqid);		
		
		String[] arr=insPricingVO.getExcelFile().getOriginalFilename().split("[.]");
		String fileType=arr[arr.length-1];
	
	
		excelData=this.getExcelData(request,insPricingVO.getExcelFile(),fileType,8);
		String asOndate= this.getExcelData1(request,insPricingVO.getExcelFile(),fileType,8);
		System.out.println("asOndate.."+asOndate);
		String settlementNo=(String) excelData[0];
		System.out.println("excelData..."+excelData);
		String msg = (String) excelData[2];
		System.out.println("msg...."+msg);
		
		if("0".equals(settlementNo)){
		   	  
			// request.getSession().setAttribute("notifyerror", strNotify);
		 request.setAttribute("errorMsg","Please check the file, we are reading data from sheet-2");
		}else {
		
		String batchNo=convertExcelDataIntoXml(request,excelData,insPricingVO.getExcelFile(),fileType,insPricingVO.getGroupProfileSeqID().toString(),userseqid);	
		
		 
		String fileName=batchNo+"."+fileType;
		
		  String backupPath=UXUtility.checkNull(UXUtility.getPropertyValue("QatarXmlPricingDir"))+fileName;
		  outputStream = new FileOutputStream(new File(backupPath));
		  outputStream.write(insPricingVO.getExcelFile().getBytes());//Excel file Upload backUp
		  outputStream.close();
		  String xmlFilePath=UXUtility.getPropertyValue("QatarXmlPricingDir")+batchNo+".xml";
		  
    	  File file2=new File(xmlFilePath);
    	  FileReader fileReader=new FileReader(file2);
    	  
    	
    		ArrayList inputData=new ArrayList();
  	    	inputData.add(batchNo);
  	    	inputData.add(fileReader);
  	    	inputData.add((int)file2.length());
  	    	inputData.add(insPricingVO.getGroupProfileSeqID());
  	    	inputData.add(userseqid);
  	    	inputData.add(fileName);
  	    	inputData.add(insPricingVO.getPricingRefno());
  	    	inputData.add(insPricingVO.getGroupRegSeqId());
  	    	inputData.add(asOndate);
  	   
  	    	
  	    	
    	  String pricingmemUpload= pricingInputScreenService.PricingUploadExcel(inputData);
    	  
    	
    	  
   	   if(pricingmemUpload == null){
   		   
       
   	    ArrayList alprofileIncomeList= pricingInputScreenService.getBenefitvalueAfter(insPricingVO.getGroupProfileSeqID());
   	  
   		
   		 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
   		 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));
   		 request.getSession().setAttribute("noCoverdLives", ((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
   		 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
   		 request.getSession().setAttribute("sumTotalLivesMale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMale());
   		 request.getSession().setAttribute("sumTotalLivesFemale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemale());
   		 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
   		 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
   		 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
   		 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
   		 		 
   		 request.getSession().setAttribute("totalNoOfLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalCovedLives());
   		 
   		 request.getSession().setAttribute("TotalMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalLivesMaternity());
   		 
   		 if(((InsPricingVO)alprofileIncomeList.get(3)).getMinMaternity() != null){
   		 request.getSession().setAttribute("minMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getMinMaternity());
   		 }else{
   			 request.getSession().setAttribute("minMaternityLives","");
   		 }
   		 if(((InsPricingVO)alprofileIncomeList.get(3)).getMaxMaternity()!= null){
   		 request.getSession().setAttribute("maxMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getMaxMaternity());
   		 }else{
   			 request.getSession().setAttribute("maxMaternityLives","");
   		 }
   		 
   		 InsPricingVO	 insPricingVO1  =  pricingInputScreenService.getfalgPricingvalue(insPricingVO.getGroupProfileSeqID());
		  String bene_covered_FlagYN = insPricingVO1.getBenecoverFlagYN();
		  String calCPM_FlagYN = insPricingVO1.getBenecoverFlagYN();
		  
		 
		  request.getSession().setAttribute("completeSaveYN",calCPM_FlagYN);	
     	      /*  modelAndView.addObject("successMsg", "File uploaded successfully");*/
     	        
		  modelAndView.addObject("uploadType", "Y");
     	        
     	    }else{
     	    	
     	    	 modelAndView.addObject("errorMsg",pricingmemUpload);   	
     	    	 
     	    	 if(flagcheckSave) {
     	    		request.getSession().setAttribute("groupPricingSeqId","");
     				request.getSession().setAttribute("pricingRefNo","");
     	    		insPricingVO = new InsPricingVO();
     	    	 }else {
     	    		ArrayList alprofileIncomeList= pricingInputScreenService.getBenefitvalueAfter(insPricingVO.getGroupProfileSeqID());
     	    	   	  
     	      		
     	     		 request.getSession().setAttribute("profileBenefitList", alprofileIncomeList.get(0));
     	     		 request.getSession().setAttribute("profileNationalityList", alprofileIncomeList.get(1));
     	     		 request.getSession().setAttribute("noCoverdLives", ((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
     	     		 request.getSession().setAttribute("sumTotalLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLives());
     	     		 request.getSession().setAttribute("sumTotalLivesMale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMale());
     	     		 request.getSession().setAttribute("sumTotalLivesFemale",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesFemale());
     	     		 request.getSession().setAttribute("sumTotalLivesMaternity",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesMaternity());
     	     		 request.getSession().setAttribute("sumTotalLivesOptical",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesOptical());
     	     		 request.getSession().setAttribute("sumTotalLivesDental",((InsPricingVO)(alprofileIncomeList.get(2))).getSumTotalLivesDental());
     	     		 request.getSession().setAttribute("sumNationalityLives",((InsPricingVO)(alprofileIncomeList.get(2))).getSumNationalityLives());
     	     		 		 
     	     		 request.getSession().setAttribute("totalNoOfLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalCovedLives());
     	     		 
     	     		 request.getSession().setAttribute("TotalMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getTotalLivesMaternity());
     	     		 
     	     		 if(((InsPricingVO)alprofileIncomeList.get(3)).getMinMaternity() != null){
     	     		 request.getSession().setAttribute("minMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getMinMaternity());
     	     		 }else{
     	     			 request.getSession().setAttribute("minMaternityLives","");
     	     		 }
     	     		 if(((InsPricingVO)alprofileIncomeList.get(3)).getMaxMaternity()!= null){
     	     		 request.getSession().setAttribute("maxMaternityLives",((InsPricingVO)alprofileIncomeList.get(3)).getMaxMaternity());
     	     		 }else{
     	     			 request.getSession().setAttribute("maxMaternityLives","");
     	     		 }
     	    		 
     	    	 }
     	    }
   
    	  
    		 insPricingVO.setInpatientBenefit(insPricingVO.getInpatientBenefit() != "" ?insPricingVO.getInpatientBenefit():"Y");
             insPricingVO.setOutpatientBenefit(insPricingVO.getOutpatientBenefit() != "" ?insPricingVO.getOutpatientBenefit():"Y");
        /*     insPricingVO.setOpdeductableserviceYN(insPricingVO.getOpdeductableserviceYN() != "" ?insPricingVO.getOpdeductableserviceYN():"Y");*/
             insPricingVO.setAlAhlihospital(insPricingVO.getAlAhlihospital() != "" ?insPricingVO.getAlAhlihospital():"Y");
         /*    insPricingVO.setAlAhlihospOPservices(insPricingVO.getAlAhlihospOPservices() != "" ?insPricingVO.getAlAhlihospOPservices():"Y");*/
             insPricingVO.setProRATALimitApplicable(insPricingVO.getProRATALimitApplicable() != "" ?insPricingVO.getProRATALimitApplicable():"N");
    		 
    	  
		}
    	 // System.out.println("xmlFilePath--"+xmlFilePath);
		   request.setAttribute("fetchFlag","Y");	 		 		
		return modelAndView;
	}
	
	@RequestMapping(value = {"/SoftwareInsurancePricing/deleteFile"},method={RequestMethod.GET})
	public @ResponseBody String  deletInputFile(@RequestParam("fileNo") String fileNo,@RequestParam("groupProfileSeq") String groupProfileSeq, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		
		 String status="";					  
		try {
			
			
		Long num=pricingInputScreenService.deleteFile(Long.parseLong(fileNo),Long.parseLong(groupProfileSeq));
		
		if(num > 0) {
			
			if(fileNo.equals("1")) {
				request.getSession().removeAttribute("fileName1");
				request.getSession().removeAttribute("fileStream1");
			}
			if(fileNo.equals("2")) {
				request.getSession().removeAttribute("fileName2");
				request.getSession().removeAttribute("fileStream2");
			}
			if(fileNo.equals("3")) {
				request.getSession().removeAttribute("fileName3");
				request.getSession().removeAttribute("fileStream3");
			}
			if(fileNo.equals("4")) {
				request.getSession().removeAttribute("fileName4");
				request.getSession().removeAttribute("fileStream4");
			}
			if(fileNo.equals("5")) {
				request.getSession().removeAttribute("fileName5");
				request.getSession().removeAttribute("fileStream5");
			}
			
			
			status="suceess";
		}else {
			status="fails";
		}
		
		}catch(Exception e) {
			status="fails";
			e.printStackTrace();			
		}		     				
		  return status;		 
	}
	
	@RequestMapping(value = {"/SoftwareInsurancePricing/doViewUploadDocs"},method={RequestMethod.GET})
	
	public @ResponseBody void viewInpuscrenFile(@RequestParam("fileNo") String fileNo,@RequestParam("groupProfileSeq") String groupProfileSeq, HttpServletRequest  request,HttpServletResponse response) throws Exception{
		
		 
	    ByteArrayOutputStream baos=null;
	    OutputStream sos = null;
	    FileInputStream fis = null; 
	    BufferedInputStream bis =null;
	    InputStream  iStream = null;
	    String fileExtn = "";
	    
	InsPricingVO insPricingVOdoc=	pricingInputScreenService.doViewUploadDocs(Long.parseLong(groupProfileSeq), fileNo);
	  iStream= insPricingVOdoc.getInputstreamdoc1();
	  fileExtn = insPricingVOdoc.getAttachmentname1();
	  
	  
	  if((iStream!=null) && (!iStream.equals("")))
	  {
       
    	 bis = new BufferedInputStream(iStream);
         baos=new ByteArrayOutputStream();
         String lowercaseFileExtn = fileExtn.toLowerCase();
         
         if ((lowercaseFileExtn.endsWith("jpeg")|| (lowercaseFileExtn.endsWith("jpg"))|| (lowercaseFileExtn.endsWith("gif")) ||(lowercaseFileExtn.endsWith("png")))){
    	          
        	    InputStream in=iStream;
        	    ServletOutputStream out = response.getOutputStream();
        	    byte[] buf = new byte[10*1024];
        	    int len;
        	    while ((len = in.read(buf)) > 0) {
        	    out.write(buf, 0, len);
        	    }
        	    in.close();
        	    out.flush();
        	    out.close();
        	    }//end image format
         else{
           
         
         if(lowercaseFileExtn.endsWith("doc") || lowercaseFileExtn.endsWith("docx"))
    		{
    			response.setContentType("application/msword");
    			response.addHeader("Content-Disposition","attachment; filename="+fileExtn);
    		}//end of if(fileExtn.endsWith("doc"))
    		else if(lowercaseFileExtn.endsWith("pdf"))
    		{
    			response.setContentType("application/pdf");
    			/*response.addHeader("Content-Disposition","attachment; filename="+fileExtn);*/
    		}//end of else if(fileExtn.endsWith("pdf"))
    		else if(lowercaseFileExtn.endsWith("xls") || lowercaseFileExtn.endsWith("xlsx"))
    		{
    			response.setContentType("application/vnd.ms-excel");
    			response.addHeader("Content-Disposition","attachment; filename="+fileExtn);
    		}//end of else if(fileExtn.endsWith("xls"))
    		else if(lowercaseFileExtn.endsWith("txt")){
		    		response.setContentType("text/plain");
		    		/*response.setHeader("Content-Disposition","attachment;filename"+fileExtn);*/
    		}
         
     
       int ch;
       while ((ch = bis.read()) != -1) baos.write(ch);
       sos = response.getOutputStream();
       baos.writeTo(sos);  
       baos.flush();      
       sos.flush(); 
         }//end document format
	  }//end   istream null
	  else{
		/*File f = new File(strFileNoRecords);
  		if(f.isFile() && f.exists()){
  			fis = new FileInputStream(f);
  		}//end of if(strFile !="")
  		BufferedInputStream bist = new BufferedInputStream(fis);
  		baos=new ByteArrayOutputStream();
  		int ch;
  		while ((ch = bist.read()) != -1)
  		{
  			baos.write(ch);
  		}//end of while ((ch = bis.read()) != -1)
  		sos = response.getOutputStream();
  		baos.writeTo(sos);*/
	  }
	  
		
	}
	
	
	
	@RequestMapping(value = {"/SoftwareInsurancePricing/getOpLimitList"},method={RequestMethod.GET})
	public @ResponseBody String  getOpLimtList(@ModelAttribute("insPricingVO") InsPricingVO insPricingVO,@RequestParam("maximumLimitList") String maximumLimitList,HttpServletRequest  request,HttpServletResponse response) throws Exception{
		ModelAndView modelAndView = new ModelAndView(strInputScreen);	
		
		 StringBuilder sb1 = new StringBuilder();
		 sb1.append("<option value=\"\">Select</option>");	
		 try {
		 
		System.out.println("mamimum benefit Limit List ...."+maximumLimitList);
		  ArrayList<CacheObject>  opLimitList = pricingInputScreenService.getOpLimitlist(maximumLimitList);
		  request.getSession().setAttribute("opLimitList", opLimitList);
		  
		  if(opLimitList != null) {			  
			  for(CacheObject item:opLimitList) {
				  sb1.append("<option value=\""+item.getCacheId()+"\">"+item.getCacheDesc()+"</option>");				  
			  }
		  }		  
		
		 }catch(Exception e) {
			 sb1.append("<option value=\"\">Select</option>");	
		 }
	    	    		 		
		  return sb1.toString();
		 
	}
	
	protected void setLinks(HttpServletRequest request) throws VidalException{
		
	 	String strMenuLink = UXUtility.checkNull(request.getParameter("menulink"));
        String strSubLink = UXUtility.checkNull(request.getParameter("sublink"));
        String strSubMenuLink = UXUtility.checkNull(request.getParameter("submenulink"));
        if(request.getSession().getAttribute("userAccessSecurityProfile")!=null)
        {
        	UserSecurityProfile userSecurityProfile=(UserSecurityProfile)request.getSession().getAttribute("userAccessSecurityProfile");
        	if(userSecurityProfile.getSecurityProfile().getActiveLink().equals(""))
            {
                userSecurityProfile.getSecurityProfile().setDefaultActiveLink();
            }//end of if(userSecurityProfile.getSecurityProfile().getActiveLink().equals(""))
            else
            {
                userSecurityProfile.getSecurityProfile().setLinks(strMenuLink,strSubLink,strSubMenuLink);
            }
        }
        else
        {
            //vidalException.setMessage("error.session");
            throw new VidalException("error.session.setlinks");
        }
}
	
	
	private String getExcelData1(HttpServletRequest request,MultipartFile  formFile, String fileType, int column) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		InputStream fis=null;
    	HSSFSheet sheet = null;// i; // sheet can be used as common for XSSF and HSSF WorkBook
    	
    	Reader reader		=	null;
    	Object object[]=new Object[4];
    	int numclaimsettlementnumber=0;
    	int numclaimsettlementnumber1=0;
 	   
    	String date="";
		FileWriter fileWriter=	null;
		HSSFWorkbook workbook = null;
		String errorMessage=null;
		
		fis = formFile.getInputStream(); 
		workbook =  (HSSFWorkbook) new HSSFWorkbook(fis);
		int shettCount=workbook.getNumberOfSheets();
					
    	  //log("xls="+wb_hssf.getSheetName(0));
	
		if(shettCount>=2){
			
			sheet = workbook.getSheetAt(1);			
			if(sheet==null){
 	        	errorMessage="Please upload proper File";
 	        	request.getSession().setAttribute("notify", "Please upload proper File");
 	        }else{
				//Initializing the XML document
 	        	
	 	    	final Pattern REGEX_PATTERN = Pattern.compile("[^\\p{ASCII}]+");
	 	        	Iterator<?> rows     = sheet.rowIterator ();
	      	        while (rows.hasNext ()) 
	      	        {
	      	        HSSFRow row =  (HSSFRow) rows.next(); 
	      	      /*  int columnCount=sheet.getRow(0).getLastCellNum();*/
	      	      int columnCount=sheet.getRow(3).getLastCellNum();
	      	   
		 	    	if(columnCount!=8){
		 	    		errorMessage="Please upload proper File";
		 	        	request.getSession().setAttribute("notify", "Please upload proper File");
					}else{						
																			      	            		      	          
	      	            Iterator<?> cells = row.cellIterator (); 
	      	            ArrayList<String> rowData = new ArrayList<String>();	      	            
	      	            for(short i=0;i<10;i++)
	      	            {	      	            	
	      	            	HSSFCell cell	=	row.getCell(i);	      	           	      	            	
	      	            	if(cell==null)
	      	            		rowData.add("");
	      	            	else
	      	            		{ 
	      	            		switch (cell.getCellType ())
	  	     	                {
	      	            			      	            		       	      	            		
	  		     	                case HSSFCell.CELL_TYPE_NUMERIC :
	  		     	                {
	  		     	                    // Date CELL TYPE	  		     	            	  		     	                
	  		     	             if (HSSFDateUtil.isCellDateFormatted(cell)) {	  		     	             
	  		     	            	 date  = new SimpleDateFormat("dd/MM/YYYY").format(cell.getDateCellValue());
	  		     	                	  		     	               	  		     	                
	  		     	                 return date;
	  		     	               }
	  		     	              }	  		     	                	  		     	            
	  		     	              
	  		     	                default:
	  		     	                {
	  		     	                 break;
	  		     	                }
	  	     	                } // end switch
	  	            		}//else
	      	            	
	      	            }//for
	      	          
	      	         
	      	        numclaimsettlementnumber++; 
	      	        } //end while
	      	     
	 	        }
					}
		}else{
			request.getSession().setAttribute("notify", "Please check the file, we are reading data from sheet-2");
		}
											       
		    return date;
	}
	
	  
	private Object[] getExcelData(HttpServletRequest request,MultipartFile  formFile, String fileType, int column) throws FileNotFoundException, IOException {
		// TODO Auto-generated method stub
		InputStream fis=null;
    	HSSFSheet sheet = null;// i; // sheet can be used as common for XSSF and HSSF WorkBook
    	HSSFSheet sheet1 = null;// i; // sheet can be used as common for XSSF and HSSF WorkBook
    	Reader reader		=	null;
    	Object object[]=new Object[4];
    	int numclaimsettlementnumber=0;
    	int numclaimsettlementnumber1=0;
 	     ArrayList<ArrayList<String>> excelDatar=new ArrayList<>();
 	    ArrayList<ArrayList<String>> excelDatar1=new ArrayList<>();
		FileWriter fileWriter=	null;
		HSSFWorkbook workbook = null;
		String errorMessage=null;
		
		fis = formFile.getInputStream(); 
		workbook =  (HSSFWorkbook) new HSSFWorkbook(fis);
		int shettCount=workbook.getNumberOfSheets();
		
		
	System.out.println("shettCount.."+shettCount);
		
    	  //log("xls="+wb_hssf.getSheetName(0));
		
		if(shettCount>=2){
			
			sheet = workbook.getSheetAt(1);
			if(sheet==null){
 	        	errorMessage="Please upload proper File";
 	        	request.getSession().setAttribute("notify", "Please upload proper File");
 	        }else{
				//Initializing the XML document
 	        	
 	       	try {
	 	    	final Pattern REGEX_PATTERN = Pattern.compile("[^\\p{ASCII}]+");
	 	        	Iterator<?> rows     = sheet.rowIterator ();
	 	        	
	      	        while (rows.hasNext ()) 
	      	        {
	      	        HSSFRow row =  (HSSFRow) rows.next(); 
	      	        System.out.println("sheet.."+sheet.getTopRow());
	      	        
	      	        System.out.println("sheet....."+sheet.getRow(0).getFirstCellNum());
	      	    /*    int columnCount=sheet.getRow(0).getLastCellNum();*/
	      	      int columnCount=sheet.getRow(3).getLastCellNum();
	      	     

	      	   
	      	        System.out.println("columnCount.."+columnCount);
	      	     
	      	    
		 	    	/*if(columnCount !=9){*/
		 	    		if(columnCount !=8){
		 	    		errorMessage="Please upload proper File";
		 	        	request.getSession().setAttribute("notify", "Please upload proper File");
					}else{
						
						
						if(row.getRowNum()==0)							
	      	            	continue;
	      	          
	      	            Iterator<?> cells = row.cellIterator (); 
	      	            ArrayList<String> rowData = new ArrayList<String>();
	      	            for(short i=0;i<10;i++)
	      	            {
	      	            	
	      	            	HSSFCell cell	=	row.getCell(i);
	      	           
	      	            	
	      	            	if(cell==null)
	      	            		rowData.add("");
	      	            	else
	      	            		{ 
	      	            		System.out.println("cell type.."+cell.getCellType ());
	      	            		switch (cell.getCellType ())
	  	     	                {
	  		     	                case HSSFCell.CELL_TYPE_NUMERIC :
	  		     	                {
	  		     	                    // Date CELL TYPE
	  		     	                    if(HSSFDateUtil.isCellDateFormatted((HSSFCell) cell) && i==3)
	  		     	                     {
	  		     	                    	
	  		     	                  
	  		     	                    
	  		     	                    	rowData.add(new SimpleDateFormat("dd/MM/YYYY").format(cell.getDateCellValue()));
	  		     	           
	  		     	                    }
	  		     	                    else 
	  		     	                    {
	  		     	                    	double numData=cell.getNumericCellValue();
	  		     	                    
	  		     	                    	if(i==3){
	  		     	                    		String dateDate="";
	  		     	                    		try{
	  		     	                    			dateDate=getFormattedDateData(numData);	
	  		     	                    		}catch(Exception exception){
	  		     	                    			dateDate="";
	  		     	                    		}
	  		     	                    		rowData.add(dateDate);
	  		     	                    	}
	  		     	                    	else {
	  		     	                    		rowData.add(numData+"");	
	  		     	                    	}
	  		     	                    }
	  		     	                    break;
	  		     	                }
	  		     	                case HSSFCell.CELL_TYPE_STRING :
	  		     	                {
	  		     	                	String richTextString = cell.getStringCellValue().trim();	  		     	        
	  		     	                	richTextString	=	REGEX_PATTERN.matcher(richTextString).replaceAll("").trim();
	  		     	                	
	  		     	                    rowData.add(richTextString);
	  		     	                    break;
	  		     	                }
	  		     	             case HSSFCell.CELL_TYPE_FORMULA :
	  		     	             {
	  		     	            	
	  		     	            	 if(i==4){
	  		     	            		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	  		     	            		
	  		     	            		rowData.add(cell.getNumericCellValue()+"");
	  		     	            	 }else{
	  		     	            		rowData.add(cell.getCellFormula());
	  		     	            	 }
	  		     	            	break;
	  		     	             }
	  		     	                case HSSFCell.CELL_TYPE_BLANK :
	  		     	                {	//HSSFRichTextString blankCell	=	cell.get.getRichStringCellValue();
	  		     	                	String blankCell	=	cell.getStringCellValue().trim().replaceAll("[^\\x00-\\x7F]", "");
	  		     	             	
	  		     	                	rowData.add(blankCell);
	  		     	                	break;
	  		     	                }
	  		     	                default:
	  		     	                {
	  		     	                    // types other than String and Numeric.
	  		     	                
	  		     	                    rowData.add("");
	  		     	                    break;
	  		     	                }
	  	     	                } // end switch
	  	            		}//else
	      	            	
	      	            }//for
	      	          
	      	          excelDatar.add(rowData);//adding Excel data to ArrayList
	      	        numclaimsettlementnumber++; 
	      	        } //end while
	      	     
	 	        }
 	       	}catch(Exception e) {
 	       		e.printStackTrace();
 	       	}
					}
		}else{
			request.getSession().setAttribute("notify", "Please check the file, we are reading data from sheet-2");
		}
		
		
		
		if(shettCount>=4){
			
			sheet1 = workbook.getSheetAt(2);
			if(sheet1==null){
 	        	errorMessage="Please upload proper File";
 	        	request.getSession().setAttribute("notify", "Please upload proper File");
 	        }else{
				//Initializing the XML document
 	        	
 	        
 	        	try {
 	        	
	 	    	final Pattern REGEX_PATTERN = Pattern.compile("[^\\p{ASCII}]+");
	 	        	Iterator<?> rows     = sheet1.rowIterator ();
	 	          int j=0;
	 	        
	      	        while (rows.hasNext ()) 
	      	        {
	      	        HSSFRow row =  (HSSFRow) rows.next(); 
	      	       /* int columnCount=sheet1.getRow(0).getLastCellNum();*/
	      	      int columnCount=sheet1.getRow(0).getLastCellNum();
	      	      
		 	    	if(columnCount!=8){
		 	    		errorMessage="Please upload proper File";
		 	        	request.getSession().setAttribute("notify", "Please upload proper File");
					}else{
						
						if(row.getRowNum()==0)
	      	            	continue;
	      	          
						if(j == 6)
							break;
							
	      	            Iterator<?> cells = row.cellIterator (); 
	      	           
	      	            
	      	            ArrayList<String> rowData = new ArrayList<String>();
	      	            for(short i=0;i<9;i++)
	      	            {
	      	            	
	      	            	
	      	            	HSSFCell cell	=	row.getCell(i);
	      	           
	      	            	
	      	            	if(cell==null)
	      	            		rowData.add("");
	      	            	else
	      	            		{ 
	      	            		
	      	            		switch (cell.getCellType ())
	  	     	                {
	  		     	                case HSSFCell.CELL_TYPE_NUMERIC :
	  		     	                {
	  		     	                    // Date CELL TYPE
	  		     	                    if(HSSFDateUtil.isCellDateFormatted((HSSFCell) cell) && i==3)
	  		     	                     {
	  		     	                    	
	  		     	                    	
	  		     	               
	  		     	                    	rowData.add(new SimpleDateFormat("dd/MM/YYYY").format(cell.getDateCellValue()));
	  		     	           
	  		     	                    }
	  		     	                    else 
	  		     	                    {
	  		     	                    	double numData=cell.getNumericCellValue();
	  		     	                    	
	  		     	                    	if(i==3){
	  		     	                    		String dateDate="";
	  		     	                    		try{
	  		     	                    			
	  		     	                    			dateDate=getFormattedDateData(numData);	
	  		     	                    		}catch(Exception exception){
	  		     	                    			dateDate="";
	  		     	                    		}
	  		     	                    		rowData.add(dateDate);
	  		     	                    	}
	  		     	                    	else {
	  		     	                    		rowData.add(numData+"");	
	  		     	                    	}
	  		     	                    }
	  		     	                    break;
	  		     	                }
	  		     	                case HSSFCell.CELL_TYPE_STRING :
	  		     	                {
	  		     	                	String richTextString = cell.getStringCellValue().trim();
	  		     	                	
	  		     	                	richTextString	=	REGEX_PATTERN.matcher(richTextString).replaceAll("").trim();
	  		     	                	
	  		     	                    rowData.add(richTextString);
	  		     	                    break;
	  		     	                }
	  		     	             case HSSFCell.CELL_TYPE_FORMULA :
	  		     	             {
	  		     	            	
	  		     	            	 if(i==4){
	  		     	            		cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
	  		     	            	   
	  		     	            		rowData.add(cell.getNumericCellValue()+"");
	  		     	            	 }else{
	  		     	            		rowData.add(cell.getCellFormula());
	  		     	            	 }
	  		     	            	break;
	  		     	             }
	  		     	                case HSSFCell.CELL_TYPE_BLANK :
	  		     	                {	//HSSFRichTextString blankCell	=	cell.get.getRichStringCellValue();
	  		     	                	String blankCell	=	cell.getStringCellValue().trim().replaceAll("[^\\x00-\\x7F]", "");
	  		     	                
	  		     	                	rowData.add(blankCell);
	  		     	                	break;
	  		     	                }
	  		     	                default:
	  		     	                {
	  		     	                    // types other than String and Numeric.
	  		     	                 
	  		     	                    rowData.add("");
	  		     	                    break;
	  		     	                }
	  	     	                } // end switch
	  	            		}//else
	      	            	
	      	            	
	      	            }//for
	      	          
	      	          excelDatar1.add(rowData);//adding Excel data to ArrayList
	      	        numclaimsettlementnumber1++; 
	      	        j++;
	      	        } //end while
	      	      
		 	    	
		 	    
	 	        }
 	        	}catch(Exception e) {
 	        		e.printStackTrace();
 	        	}
					}
		}else{
			request.getSession().setAttribute("notify", "Please check the file, we are reading data from sheet-2");
		}
		
		
 	        object[0]=numclaimsettlementnumber+"";//adding no. of policies
			object[1]=excelDatar;//adding all rows dataO
			
			object[2]=errorMessage;
			object[3]=excelDatar1;
		    return object;
	}
	
	
    private String getFormattedDateData(double numericCellValue) {
		int myDouble = (int) numericCellValue;
		GregorianCalendar gc = new GregorianCalendar(1900, Calendar.JANUARY, 1);
        gc.add(Calendar.DATE, myDouble-2);
        Date result = gc.getTime();
        DateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
		String outputString = outputFormat.format(result);
		return outputString;
	}
    
    
    
	private String convertExcelDataIntoXml(HttpServletRequest request,Object[] objects,MultipartFile formFile,String fileType,String pricingSeqid,Long uploadedBy1) throws Exception {
		
		 
    	String noOfPolicies=(String)objects[0];
    	
		ArrayList<ArrayList<String>> excelDataRows=(ArrayList<ArrayList<String>>)objects[1];
		
		ArrayList<ArrayList<String>> excelDataRows1=(ArrayList<ArrayList<String>>)objects[3];
		
		
    	String uploadType="PRI";
       
        String uploadedBy = uploadedBy1.toString();
    	
        String batchNo=uploadType+"-"+pricingSeqid+"-"+ new SimpleDateFormat("yyyyMMddHHmmSSS").format(new Date());//policyType+"-"+ new SimpleDateFormat("dd-MM-yyyy-hh-mm-SSS").format(new Date())+"-"+vidalOfficeName+"-"+abrCode+"-"+uploadType+"-"+groupId;
       
       String policyFileName =batchNo+"."+fileType;  
        
      
       
        //prepare the marshaling
    
        Batch batch=new Batch();
       JAXBContext contextObj = JAXBContext.newInstance(Batch.class); 
		Marshaller marshallerObj = contextObj.createMarshaller(); 
		marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
	  //  FileDetail fileDetail=new FileDetail(member_Name,gender,dob,age,matCovered,salary,country_code,policy_number,member_id,relationship) 
	 //  batch.setFileDetail(fileDetail);
       
	 //write the data into xml file		
		
		
		
		Iterator<ArrayList<String>>rit=excelDataRows.iterator();
	
		
		ArrayList<MemberDetails> memberAl=new ArrayList<>();
		int i = 0;
		int constan = 0;
    		while(rit.hasNext()){
    			
    			 ArrayList<String> rlist=rit.next();
    			
    			 MemberDetails memberDetails=new MemberDetails();
    			 memberDetails.setUploadstatus("Y");
    				      
    			    
                      
                      
                      if(rlist.get(0).equals("Al Koot ID")){                    	 
                    	  constan = i;
                      }                      
                  
                      if(i > constan && constan != 0) {
                    	  MemberData memberData=new MemberData();	    		
                    	 
    			 memberData.setAlkootId(rlist.get(0));
    			 memberData.setMember_Name(rlist.get(1)); 
    			 memberData.setGender(rlist.get(2)); 
    			 memberData.setDob(rlist.get(3)); 
    			 memberData.setAge(rlist.get(4)); 
    			 memberData.setMatCovered(rlist.get(5)); 
    			 memberData.setRelationship(rlist.get(6));
    			 memberData.setIsMaternityEligible(""); 
    			 memberData.setCountry_code(rlist.get(7));
//    			 memberData.setSalary("");  
    			// memberData.setPolicy_number(rlist.get(7));  
    			// memberData.setMember_id(rlist.get(8));
    			
    			 
    			 memberDetails.setMemberData(memberData);
    			 
    			 memberAl.add(memberDetails);	
                      }
    			 i++;
    			
    			}//while		    		
    	
    		
    		
    		
    		
    		Iterator<ArrayList<String>>rit1=excelDataRows1.iterator();
    		ArrayList<MaternityDetails> maternityAl=new ArrayList<>(); 
    		 MaternityDetails maternityDetails = new MaternityDetails();
   			 MaternityData maternityData = new MaternityData();
    		 String setMaatgender="";
   			 String setMatminage="";
   			 String setMatmaxage="";
   			 String setMatrelation="";
   			 String setMaritalstat="";
   			 String setMaternityData="";  	
   			 
    		  int j = 0;   		    		  
    	 		while(rit1.hasNext()){
       			 ArrayList<String> rlist=rit1.next();       			        		

       			 if(j == 3) {
       				setMaatgender += rlist.get(0);
       				setMatminage  += rlist.get(1);
       				setMatmaxage  = rlist.get(2);
       				setMatrelation += rlist.get(3);
       				setMaritalstat = rlist.get(4);
       			 }else if( j == 4) {
       				setMatrelation  += "," +rlist.get(3);
       			 }     			        			       			 
       			 j++;
       			}//while		    		
       	
    	 		 maternityData.setMaatgender(setMaatgender);
       			 maternityData.setMatminage(setMatminage);
       			 maternityData.setMatmaxage(setMatmaxage);       			
       			 maternityData.setMatrelation(setMatrelation);
       			 maternityData.setMaritalstat(setMaritalstat);
       			 maternityDetails.setMaternityData(maternityData);        			 
       			 maternityAl.add(maternityDetails);
    		  
       /* 		while(rit1.hasNext()){
        			 ArrayList<String> rlist=rit1.next();
        			 
        			 MaternityDetails maternityDetails = new MaternityDetails();
        			 MaternityData maternityData = new MaternityData();
        			 
        			 System.out.println("00....."+rlist.get(0)); 
        			 System.out.println("01....."+rlist.get(1));
        			 System.out.println("02....."+rlist.get(2));
        			 System.out.println("03....."+rlist.get(3));
        			 System.out.println("04....."+rlist.get(4));
        			 System.out.println("05....."+rlist.get(5));
        			 
        			 
        			 String setMaatgender="";
        			 String setMatminage="";
        			 String setMatmaxage="";
        			 String setMatrelation="";
        			 String setMaritalstat="";
        			 String setMaternityData="";
        			 
        			 
        			 if(j == 3 ) {
        			 maternityData.setMaatgender(rlist.get(0));
        			 maternityData.setMatminage(rlist.get(1));
        			 maternityData.setMatmaxage(rlist.get(2));       			
        			 maternityData.setMatrelation(rlist.get(3));
        			 maternityData.setMaritalstat(rlist.get(4));
        			 maternityDetails.setMaternityData(maternityData);        			 
        			 maternityAl.add(maternityDetails);
        			 }           			 
      			        			       			 
        			 j++;
        			}//while		    		
        	*/
    		
    		
    		 batch.setMaternityDetails(maternityAl);
    		 batch.setMemberDetails(memberAl); 	
    		 
			  
			  File xmlPath=new File(UXUtility.getPropertyValue("QatarXmlPricingDir"));
			  if(!xmlPath.exists())xmlPath.mkdirs();
			  String xmlFilePath=UXUtility.getPropertyValue("QatarXmlPricingDir")+batchNo+".xml";  
			  marshallerObj.marshal(batch,new File(xmlFilePath));		    			  
		
              return batchNo; 
                    
}    
	

	@Autowired
	Additionalservice additionalservice;


} // end class

package com.vidal.controllers.table.Pricing;

import com.vidal.controllers.table.Column;
import com.vidal.controllers.table.Table;



 

public class SwInsurancePricingTable extends Table {
	
	private static final long serialVersionUID = 1L;

	/**
	 * This creates the columnproperties objects for each and 
	 * every column and adds the column object to the table
	 */
	public void setTableProperties() {
		setRowCount(6);
		setCurrentPage(1);
		setPageLinkCount(10);
		
	

		

	        Column colPreAuth = new Column("Individual/Group pricing reference no.");
	        colPreAuth.setMethodName("getPricingRefno");
	        colPreAuth.setIsHeaderLink(true);
	        colPreAuth.setIsLink(true);
	        colPreAuth.setImageName("getPricingStatusImage");
	        colPreAuth.setImageTitle("getPricingStatusTittle");
	     /*   colPreAuth.setImageHeight("10");
	  	    colPreAuth.setImageWidth("20");*/
	        colPreAuth.setHeaderLinkTitle("Sort by:Pricing Reference No");
	        colPreAuth.setColumnWidth("20%");
	        colPreAuth.setDBColumnName("REF_NO");
	        addColumn(colPreAuth);
		
	        Column colStatus = new Column("New client/Renewal");
	        colStatus.setMethodName("getClientType");
	        colStatus.setColumnWidth("10%");
	        colStatus.setIsHeaderLink(true);
	        colStatus.setHeaderLinkTitle("Sort By : Status");
	        //status.setIsHeaderLink(true);
	        colStatus.setImageName("getsStatusImageName");
	        colStatus.setImageTitle("getStatusImageTitle");
	        colStatus.setImageHeight("25");
	        colStatus.setImageWidth("80");
	        colStatus.setDBColumnName("NEW_RENW");
	        addColumn(colStatus);
	        
	        Column Corporate = new Column("Corporate name");
			Corporate.setMethodName("getGroupName");
			Corporate.setColumnWidth("10%");
			Corporate.setIsHeaderLink(true);
			Corporate.setHeaderLinkTitle("Sort by:group name");
			Corporate.setDBColumnName("GROUP_NAME");
			addColumn(Corporate);
			
			
			Column colplantype = new Column("Plan name");
			colplantype.setMethodName("getPlantype");
			colplantype.setColumnWidth("12%");
			colplantype.setIsHeaderLink(true);
			colplantype.setHeaderLinkTitle("Sort by Plan Type ");
			colplantype.setDBColumnName("PLAN_TYPE");
			addColumn(colplantype);
		
		
		
		   	     	        	        

	    	/*Column colCompanyName = new Column("Client code");
			colCompanyName.setMethodName("getClientCode");
			colCompanyName.setColumnWidth("10%");
			colCompanyName.setIsHeaderLink(true);
			colCompanyName.setHeaderLinkTitle("Sort by Client ");
			colCompanyName.setDBColumnName("CLIENT_CODE");
			addColumn(colCompanyName);*/
			
									           	

		
		Column colCoveragestartdate = new Column("Coverage start date");
		colCoveragestartdate.setMethodName("getCoveragestartdate");
		colCoveragestartdate.setColumnWidth("8%");
		colCoveragestartdate.setIsHeaderLink(true);
		colCoveragestartdate.setHeaderLinkTitle("Sort by Client ");
		colCoveragestartdate.setDBColumnName("covrg_start_date");
		addColumn(colCoveragestartdate);
		
		
		Column colcoverageenddate = new Column("Coverage end date");
		colcoverageenddate.setMethodName("getCoverageenddate");
		colcoverageenddate.setColumnWidth("8%");
		colcoverageenddate.setIsHeaderLink(true);
		colcoverageenddate.setHeaderLinkTitle("Sort by Client ");
		colcoverageenddate.setDBColumnName("covrg_end_date");
		addColumn(colcoverageenddate);
		
		
		
		
		
		Column Broker = new Column("Broker name");
		Broker.setMethodName("getBrokername");
		Broker.setColumnWidth("12%");
		Broker.setIsHeaderLink(true);
		Broker.setHeaderLinkTitle("Sort by Client ");
		Broker.setDBColumnName("client_code");
		addColumn(Broker);
		
		
		Column colinitiateddate = new Column("Pricing initiated date");
		colinitiateddate.setMethodName("getPricinginitiateddate");
		colinitiateddate.setColumnWidth("10%");
		colinitiateddate.setIsHeaderLink(true);
		colinitiateddate.setHeaderLinkTitle("Sort by:Initated date");
		colinitiateddate.setDBColumnName("INITIATED_DATE");
		addColumn(colinitiateddate);
		

    	Column colCompanyName = new Column("Last modified by");
		colCompanyName.setMethodName("getLastModifiedBy");
		colCompanyName.setColumnWidth("8%");
		colCompanyName.setIsHeaderLink(true);
		colCompanyName.setHeaderLinkTitle("Last modified");
		colCompanyName.setDBColumnName("last_modified_Date");
		addColumn(colCompanyName);
	
		   Column colImage3 = new Column("");
		   colImage3.setIsImage(true);
		   colImage3.setIsImageLink(true);
		   colImage3.setColumnWidth("6%");
		   colImage3.setImageName("getStrImageName");
		   colImage3.setImageTitle("getStrImagetitle");
		   colImage3.setImageHeight("15");
		   colImage3.setImageWidth("5");
		  /* colImage3.setColumnStyle("getStrStyle");*/
		 
		   colImage3.setVisibility(true);
		   
	        addColumn(colImage3);
	      
		
	        
	        
	    
		
		
	}//end of public void setTableProperties()
}//end of class InsuranceCompanyTable



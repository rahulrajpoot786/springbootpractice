package com.vidal.controllers.pricing;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.itextpdf.text.log.SysoCounter;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPricingSummaryVO;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.common.VidalCommon;
import com.vidal.common.controller.vidalcontroller.VidalController;
import com.vidal.common.exception.GetErrorMessage;
import com.vidal.services.authentication.GrossService;
import com.vidal.services.pricing.PricingRiskPreimiumService;


@Controller
@RequestMapping("SoftwareInsurancePricing")
/*@SessionAttributes({"SwPricingSummaryVO","alLoadingGrosspremium"})*/
@SessionAttributes({"SwPricingSummaryVO"})
public class Grosspreiumcontroller extends VidalController{
	private static Logger logger = Logger.getLogger( Grosspreiumcontroller.class );
	private static final String strPricingGross="pricing.Gross";
	@Autowired
	public PricingRiskPreimiumService pricingRiskPreimiumService;
	
	@RequestMapping(value ="GrossPremium-Working", method = RequestMethod.POST)
	public ModelAndView doGrosspricing(SwPricingSummaryVO swPricingSummaryVO, HttpServletRequest request,BindingResult result,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		request.getSession().removeAttribute("table1data");
		request.removeAttribute("alLoadingGrosspremiumList");
		request.getSession().removeAttribute("alLoadingGrosspremium");
		
		ModelAndView modelAndView = new ModelAndView(strPricingGross);
		setErrorPageData(strPricingGross, model);
		UserSecurityProfile userAccessSecurityProfile = (UserSecurityProfile) request.getSession().getAttribute("userAccessSecurityProfile");
		userAccessSecurityProfile.getSecurityProfile().setActiveTab("Gross Premium-Working");
		try{
			
		//long GroupProfileSeqID = (long)request.getSession().getAttribute("GroupProfileSeqID");
		String completeSaveYN = (String)request.getSession().getAttribute("completeSaveYN");
		System.out.println("completeSaveYN...."+completeSaveYN);
		if(completeSaveYN.equals("N"))
			 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));	
		

		
			/*String completeSaveYN ="Y";*/
		InsPricingVO insPricingVO = new InsPricingVO();
		long GroupProfileSeqID=(long) request.getSession().getAttribute("groupPricingSeqId");
		swPricingSummaryVO.setLngGroupProfileSeqID((Long) request.getSession().getAttribute("groupPricingSeqId"));
		
            insPricingVO  =  pricingRiskPreimiumService.getfalgPricingvalue(GroupProfileSeqID);
		  
		  System.out.println("insPricingVO.getCompleteSaveYNInSc2()..."+insPricingVO.getCompleteSaveYNInSc2());
		  
		  if(insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("N") || insPricingVO.getCompleteSaveYNInSc2().equalsIgnoreCase("")) {
			  System.out.println("risk....");
				 return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen"));			
			}
		 
		ArrayList  alLoadingGrosspremiumList = new ArrayList();
		ArrayList table1data[] = null;
	/*	insPricingVO.setGroupProfileSeqID((Long) request.getSession().getAttribute("groupPricingSeqId"));*/
		insPricingVO.setGroupProfileSeqID(GroupProfileSeqID);
		
		insPricingVO.setAddedBy(VidalCommon.getUserSeqID(request));
		
		
	/*	insPricingVO.setGroupProfileSeqID(GroupProfileSeqID);
	 * 
		insPricingVO.setAddedBy((VidalCommon.getUserSeqId(request)));*/
		InsPricingVO insPricingVO2  =  grossService.getfalgPricingvalue(GroupProfileSeqID);
		String loadingFlagYN = insPricingVO2.getLoadingFlagYN();
	/*	String flagrisk=insPricingVO2.getLoadingFlagYN();*/
		 String calCPM_FlagYN = insPricingVO2.getCalCPMFlagYN();
		 String modify_flag=insPricingVO2.getPricingmodifyYN();
		 String gross_calualtion=insPricingVO2.getGrossclaulation().trim();
		 String Calculation=insPricingVO2.getCalCPMFlagYN();
		 if(calCPM_FlagYN.equals("N") || calCPM_FlagYN.equals("")){
				return new ModelAndView("failure","GLOBAL_ERROR",GetErrorMessage.getValue("error.pricing.complete.screen.riskpremium"));
			}
		 
		 if(loadingFlagYN.equalsIgnoreCase("Y"))
			{
			
				alLoadingGrosspremiumList= grossService.getAfterLoadingData(insPricingVO);	
			}else{
				
				alLoadingGrosspremiumList= grossService.getBeforeLoadingData(insPricingVO);//to get Loading data	
			}
			String remarkvalue="";
			
			for(int i=0; i< alLoadingGrosspremiumList.size();i++){
				SwPricingSummaryVO swPricingSummaryVO1 =	(SwPricingSummaryVO) alLoadingGrosspremiumList.get(i);
				
				remarkvalue=swPricingSummaryVO1.getLoadComments();
			
				
			}
			
			swPricingSummaryVO.setLoadComments(remarkvalue);
			/*for (Object object : alLoadingGrosspremiumList) {
				SwPricingSummaryVO swPricingSummaryVO=(SwPricingSummaryVO) object;
				System.out.println("seq Id::"+swPricingSummaryVO.getLoad_DeductTypeSeqId()+"----Type::"+swPricingSummaryVO.getLoad_DeductType());
			}*/
			
			if(GroupProfileSeqID > 0  && completeSaveYN.equalsIgnoreCase("Y") && calCPM_FlagYN.equalsIgnoreCase("Y"))
			{
				table1data= grossService.getcpmAfterLoadingPricing(insPricingVO);// FINAL CPM  Data so no Flag condition required
			}
		
			
			if("Y".equals(gross_calualtion)){
			
				
			 request.getSession().setAttribute("table1data", table1data);
			  if(request.getSession().getAttribute("table1data")!=null){
                  ArrayList arr[] =(ArrayList[]) request.getSession().getAttribute("table1data");
                    if(arr.length>0){
                    ArrayList<HashMap<String, String>> al = arr[0];
                    ArrayList<HashMap<String, String>> maternity = arr[1];
                    ArrayList<HashMap<String, String>> Overall = arr[2];
                    ArrayList<String> tabledetals = arr[3];
                    ArrayList tabletotalvalues = arr[4];
                   String value1= tabledetals.get(0);
                   String value2= tabledetals.get(1);
                  
                 
			/*modelAndView.set("loadComments", (((SwPricingSummaryVO)alLoadingGrosspremiumList.get(0)).getLoadComments()));*/
			
		 
		/* modelAndView.addObject("SwPricingSummaryVO", swPricingSummaryVO);
			request.setAttribute("lngGroupProfileSeqID", insPricingVO.getGroupProfileSeqID());
		 modelAndView.addObject("alLoadingGrosspremium", alLoadingGrosspremiumList);*/
		
			
                    }	}}
			 if(loadingFlagYN.equalsIgnoreCase("Y"))
				{
			ArrayList<HashMap<String, String>> allist = table1data[2];
			if(allist !=null){
			HashMap<String, String> cpmseq =null;

			 cpmseq =allist.get(0);
			String cpmseqid =cpmseq.get("cpmseqid");
			String mainoverall =cpmseq.get("mainoverall");
		
			request.getSession().setAttribute("strmainoverall", mainoverall);
			
			String maxageband=cpmseq.get("maxageband");
			request.setAttribute("maxage",maxageband);
			//swPricingSummaryVO.setCpmSeqID(cpmseqid);
			 modelAndView.addObject("cpmseqid",cpmseqid);}}
			
			  modelAndView.addObject("SwPricingSummaryVO",   swPricingSummaryVO);
				swPricingSummaryVO.setPricingRefno((String) request.getSession().getAttribute("pricingRefNo"));
				request.setAttribute("alLoadingGrosspremium", alLoadingGrosspremiumList);
			//modelAndView.addObject("alLoadingGrosspremium", alLoadingGrosspremiumList);
			request.setAttribute("lngGroupProfileSeqID", insPricingVO.getGroupProfileSeqID());
			
			
		
		return modelAndView;
		}catch(Throwable throwable){
			return processErrorView(strPricingGross, throwable);
		}
    	
	}
	
	@RequestMapping(value ="GrossPremium-Working-calculate", method = RequestMethod.POST)
	public ModelAndView doGrosspricingcalculate(@Valid @ModelAttribute("SwPricingSummaryVO") SwPricingSummaryVO swPricingSummaryVO,BindingResult result, HttpServletRequest request,
			HttpServletResponse response, HttpSession session, Model model) throws Exception {
		try{
		ModelAndView modelAndView = new ModelAndView(strPricingGross);
		setLinks(request);
		setErrorPageData(strPricingGross, model);
	    String completeSaveYN =(String)request.getSession().getAttribute("completeSaveYN");

		ArrayList alLoadDesignList = new ArrayList();
		InsPricingVO insPricingVO  = new InsPricingVO();
		ArrayList table1data[] = null;

		
		swPricingSummaryVO.setAddedBy(VidalCommon.getUserSeqID(request));
		// swPricingSummaryVO).setGroupProfileSeqID((Long) request.getSession().getAttribute("groupPricingSeqId"));
		insPricingVO.setGroupProfileSeqID((Long) request.getSession().getAttribute("groupPricingSeqId"));
		insPricingVO.setAddedBy(VidalCommon.getUserSeqID(request));
		swPricingSummaryVO.setPremiumvalue(insPricingVO.getPremiumvalue());
		swPricingSummaryVO.setMaternityvalue(insPricingVO.getMaternityvalue());
		

		/*insPricingVO.setAddedBy(294262l);*/
		long GroupProfileSeqID=(long) request.getSession().getAttribute("groupPricingSeqId");;

		int  calculateload = 0;
		grossService.saveLoading(swPricingSummaryVO);
			
		  calculateload = grossService.calculateLoading(swPricingSummaryVO);
		
		alLoadDesignList= grossService.getAfterLoadingData(insPricingVO);
	
		/*InsPricingVO insPricingVO2  =  grossService.getfalgPricingvaluetable(GroupProfileSeqID);
		insPricingVO.setAttachmentname2(insPricingVO2.getPrmiumtablevalue());*/
		String remarkvalue="";
		
		for(int i=0; i< alLoadDesignList.size();i++){
			SwPricingSummaryVO swPricingSummaryVO1 =	(SwPricingSummaryVO) alLoadDesignList.get(i);
			
			remarkvalue=swPricingSummaryVO1.getLoadComments();
			
			
		}
		
		swPricingSummaryVO.setLoadComments(remarkvalue);
	if(GroupProfileSeqID > 0  && completeSaveYN.equalsIgnoreCase("Y") )
		{
		 table1data= grossService.getcpmAfterLoadingPricing(insPricingVO);
		}
	
	ArrayList<HashMap<String, String>> allist = table1data[2];
	HashMap<String, String> cpmseq =null;

	 cpmseq =allist.get(0);
	String cpmseqid =cpmseq.get("cpmseqid");
	String mainoverall =cpmseq.get("mainoverall");
	request.getSession().setAttribute("strmainoverall", mainoverall);
	String maxageband=cpmseq.get("maxageband");
	request.setAttribute("maxage",maxageband);
	
	//swPricingSummaryVO.setCpmSeqID(cpmseqid);
	 modelAndView.addObject("cpmseqid",cpmseqid);
	/*swPricingSummaryVO.setPremiumvalue(strmainoverall);*/
	  request.getSession().setAttribute("table1data", table1data);
	 
	  modelAndView.addObject("SwPricingSummaryVO",swPricingSummaryVO);
	modelAndView.addObject("alLoadingGrosspremium", alLoadDesignList);
	request.setAttribute(""+ "", insPricingVO.getGroupProfileSeqID());
	
		return modelAndView;
		}catch(Throwable throwable){
			return processErrorView(strPricingGross, throwable);
		}
	}

	@Autowired
	GrossService grossService;
	

}


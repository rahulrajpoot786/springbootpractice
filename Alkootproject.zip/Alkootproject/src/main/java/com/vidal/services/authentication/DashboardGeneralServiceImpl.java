package com.vidal.services.authentication;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vidal.command.pricing.InsPricingVO;
import com.vidal.dao.pricing.DashboardDAOimpl;
@Service
public class DashboardGeneralServiceImpl implements DashboardGeneralService {

	@Override
	public Object[] getSwInsuranceProfileList(ArrayList alSearchObjects) 
			throws Exception {
		// TODO Auto-generated method stub
		return DashboardDAO.getSwInsuranceProfileList(alSearchObjects);
	}
	

	
	public int getDelete(ArrayList Delet) throws Exception {
		// TODO Auto-generated method stub
		return DashboardDAO.getDelete(Delet);
	}


	@Override
	public String getClientName(String clientCode) throws Exception {
		// TODO Auto-generated method stub
		return DashboardDAO.getClientName(clientCode);
	}

	@Override
	public ArrayList<InsPricingVO> groupList(ArrayList al) throws Exception{
		// TODO Auto-generated method stub
		return DashboardDAO.groupList(al);
	}
	
	@Override
	public ArrayList getGroupPricingDisplayList(Long grouppricingSeqid,String groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		return DashboardDAO.getGroupPricingDisplayList(grouppricingSeqid,groupSeqId);
	}
	
	@Override
	public Long saveGroupPricingDetails(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return DashboardDAO.saveGroupPricingDetails(insPricingVO);
	}
	
	@Override
	public InsPricingVO generateGroupSeqId(Long groupProfileSeqId, Long UserSeqid,String pricingList)
			throws Exception {
		// TODO Auto-generated method stub
		return DashboardDAO.generateGroupSeqId(groupProfileSeqId, UserSeqid,pricingList);
	}
	
	

	@Override
	public String getFetchFlag(String clientCode) throws Exception {
		// TODO Auto-generated method stub
		return DashboardDAO.getFetchFlag(clientCode);
	}

	@Autowired
	DashboardDAOimpl DashboardDAO;
	

	
}

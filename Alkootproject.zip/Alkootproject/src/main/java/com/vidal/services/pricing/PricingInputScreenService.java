package com.vidal.services.pricing;

import java.sql.SQLException;
import java.util.ArrayList;

import com.vidal.command.pricing.InsPricingVO;

public interface PricingInputScreenService {
	
	public Long swSavePricingList(InsPricingVO insPricingVO) throws Exception;
	
	public String getClientName(String clientCode) throws Exception;
	
	public ArrayList getUnderWrittingYear(String groupName)throws Exception;
	
	public ArrayList getPolicyNo(String groupName,String underWrittingYear)throws Exception;
	
	public ArrayList getHospitalList(String networkCode)throws Exception;
	
	public ArrayList getAdditionalHospitalList(String networkCode)throws Exception;
	
	public InsPricingVO getPolicyStatusInfo(ArrayList dataList) throws Exception;
	
	public InsPricingVO swSelectPricingList(Long lpricingSeqId) throws Exception;
	
	public ArrayList getBenefitvalueAfter(Long lpricingSeqId) throws Exception;
	 
	public int swSaveIncomeProfile(InsPricingVO insPricingVO) throws Exception; 
	
	public int swSaveIncomeNatProfile(InsPricingVO insPricingVO) throws Exception;
	
	public String PricingUploadExcel(ArrayList inputData) throws Exception;
	
	public InsPricingVO generatePricingNo(Long addedBy) throws Exception;
	
	public ArrayList getBenefitvalueBefore(Long lpricingSeqId) throws Exception;
	
	public InsPricingVO swFetchScreen1(InsPricingVO insPricingVO) throws Exception;
	
	public Long deleteFile(Long FileNo,Long groupProSeqId) throws Exception;
	
	public InsPricingVO getfalgPricingvalue(long lpricingSeqId) throws Exception;
	
	public int swsaveCensusMatAgeband(InsPricingVO insPricingVO) throws Exception;
	  	 			
	public InsPricingVO beforeSeveCensusData(Long groupProSeqId,Long addedBy) throws Exception ;
	
	public InsPricingVO doViewUploadDocs (Long groupProSeqId,String fileType) throws Exception;
	
	public ArrayList getGroupList(ArrayList alSearchCriteria) throws Exception;
	
	public ArrayList getOpLimitlist(String maximumLimitdesc)throws Exception;

}

package com.vidal.services.authentication;

import java.util.ArrayList;

import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.command.usermanagement.UserVO;
import com.vidal.common.VidalCommon;

public interface AuthenticationService {
	public UserSecurityProfile doAuthentication(UserVO userVO) throws Exception;
	public int doLogout(String UserID) throws Exception;
		//public String doUserStatus(ArrayList al) throws Exception;
}

package com.vidal.services.authentication;

import java.util.ArrayList;

import com.vidal.command.pricing.AdditionalVO;
import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwFinalQuoteVO;
import com.vidal.command.pricing.SwPricingSummaryVO;

public interface PropsalTOBervice {
	public String getClientName(String countyval) throws Exception;
	public SwFinalQuoteVO getfalgPricingvalue(Long group_seq_id) throws Exception;
	public int getsave(ArrayList formvalues) throws Exception;
	public SwFinalQuoteVO getdetails(SwFinalQuoteVO swFinalQuoteVO)throws Exception;
	 public int getsavepolicynumber(ArrayList formvalues) throws Exception;

}

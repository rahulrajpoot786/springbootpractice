/**
 * @ (#) Cache.java MAY 22, 2018
 * Project      : VINGS
 * File         : Cache.java
 * Author       : RISHABH KESHARI
 * Company      : VIDAL HEALTH
 * Date Created : MAY 22, 2018
 *
 * @author       :  RISHABH KESHARI
 * Modified by   :
 * Modified date :
 * Reason        : 
 */

package com.vidal.services.business.common;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vidal.dao.business.common.CacheDAOImpl;

@Service
public class CacheServiceImpl implements CacheService{

	public void populateData(String[] identfierList,String jspIdentifier)throws Exception{	
		cacheDAOImpl.populateData(identfierList,jspIdentifier);
	}
	@Override
	public void refreshPopulateData(String Identifier)throws Exception {
		cacheDAOImpl.refreshPopulateData(Identifier);

	}

	public ArrayList loadObjects(String strIdentifier) throws Exception
	{
		return (ArrayList)new CacheDAOImpl().loadObjects(strIdentifier);
	}//end of loadObjects(String strIdentifier)

	/**
	 * This method returns an arraylist loaded with CacheObjects for the appropriate identifier   
	 * @param strIdentifier String identifier for the CacheObject's to be loaded
	 * @return ArrayList of CacheObject's
	 * @exception throws Exception
	 */
	public ArrayList loadObjects1(String strIdentifier,Long strClaimSeqId) throws Exception
	{
		return (ArrayList)new CacheDAOImpl().loadObjects1(strIdentifier,strClaimSeqId);
	}//end of loadObjects(String strIdentifier)


	@Autowired
	CacheDAOImpl cacheDAOImpl;
}

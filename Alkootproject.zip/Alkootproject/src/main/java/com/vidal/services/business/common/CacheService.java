/**
 * @ (#) CacheService.java MAY 22, 2018
 * Project      : VINGS
 * File         : CacheService.java
 * Author       : RISHABH KESHARI
 * Company      : VIDAL HEALTH
 * Date Created : MAY 22, 2018
 *
 * @author       :  RISHABH KESHARI
 * Modified by   :
 * Modified date :
 * Reason        : 
 */

package com.vidal.services.business.common;

import java.util.ArrayList;

import org.springframework.stereotype.Component;


public interface CacheService {
	//public Map loadObjects(String strIdentifier) throws Exception;
	
	public void populateData(String[] identfierList,String jspIdentifier)throws Exception;
	public void refreshPopulateData(String Identifier) throws Exception;
	public ArrayList loadObjects(String strIdentifier) throws Exception;
	
	public ArrayList loadObjects1(String strIdentifier,Long strClaimSeqId) throws Exception;
}

package com.vidal.services.authentication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vidal.command.pricing.AdditionalVO;
import com.vidal.dao.pricing.AdditionalDAO;
import com.vidal.dao.pricing.AdditionalDAOimpl;

@Service

public class Additionalserviceimpl implements Additionalservice {
	@Override
	public int getsave(AdditionalVO additionalVO) throws Exception {
		
		return additionalDAO.getsave(additionalVO);
	}	
	
	
	
	
	
	@Autowired
	AdditionalDAO additionalDAO;





	@Override
	public AdditionalVO getdetails(AdditionalVO additionalVO) throws Exception {
		// TODO Auto-generated method stub
		return additionalDAO.getdetails(additionalVO);
	}
	
	@Override
	public AdditionalVO getdetailsfetch(AdditionalVO additionalVO) throws Exception {
		// TODO Auto-generated method stub
		return additionalDAO.getdetailsfetch(additionalVO);
	}





	@Override
	public AdditionalVO getfalgPricingvalue(AdditionalVO additionalVO)
			throws Exception {
	
		return additionalDAO.getfalgPricingvalue(additionalVO);
	}

	

}

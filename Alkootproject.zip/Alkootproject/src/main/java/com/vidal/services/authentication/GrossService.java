package com.vidal.services.authentication;
import java.util.ArrayList;

import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPolicyConfigVO;
import com.vidal.command.pricing.SwPricingSummaryVO;
import com.vidal.command.pricing.WhatifScreenVO;
import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.command.usermanagement.UserVO;
import com.vidal.common.VidalCommon;

public interface GrossService {
	
	public int calculateLoading(SwPricingSummaryVO swPricingSummaryVO)  throws Exception;
	public ArrayList[] getcpmAfterLoadingPricing(InsPricingVO insPricingVO) throws Exception;
	public InsPricingVO getfalgPricingvalue(Long group_seq_id) throws Exception;
	public InsPricingVO getfalgPricingvaluetable(Long group_seq_id) throws Exception;
	public ArrayList getAfterLoadingData(InsPricingVO insPricingVO) throws Exception;
	public ArrayList getBeforeLoadingData(InsPricingVO insPricingVO) throws Exception;
	//public ArrayList calculatePlanDesignConfig(SwPolicyConfigVO swpolicyConfigVO)throws Exception;
	//public ArrayList getcpmAfterCalcultion(InsPricingVO insPricingVO) throws Exception;
	//public SwPolicyConfigVO getcpmAfterLoading(InsPricingVO insPricingVO) throws Exception;
	public void saveLoading(SwPricingSummaryVO swPricingSummaryVO) throws Exception;
	
	public  WhatifScreenVO getWhatifDetails(Long groupSeqId,Long varSeqId,Long verNo,String vrsionFlag) throws Exception;
	
	public WhatifScreenVO saveEstimateChange(WhatifScreenVO whatifScreenVO) throws Exception;
	
	public Long saveWhatifDetails(Long groupSeqId,Long varSeqId,Long verNo) throws Exception;
	
	public Long saveWhatIfDetailsChange(Long groupSeqId,Long varSeqId,Long verNo) throws Exception;
	
	public WhatifScreenVO getVersionSeqId(Long groupSeqId,Long verNo) throws Exception;
	
	

}

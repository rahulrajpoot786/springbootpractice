package com.vidal.services.pricing;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vidal.command.pricing.InsPricingVO;
import com.vidal.dao.pricing.PricingInputScreenDAO;

@Service
public class PricingInputScreenServiceImpl implements PricingInputScreenService{

	@Autowired
	public PricingInputScreenDAO pricinInputScreenDao;
	@Override
	public Long swSavePricingList(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.swSavePricingList(insPricingVO);
	}
	@Override
	public String getClientName(String clientCode) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getClientName(clientCode);
	}
	@Override
	public ArrayList getUnderWrittingYear(String groupName) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getUnderWrittingYear(groupName);
	}
	@Override
	public ArrayList getPolicyNo(String groupName, String underWrittingYear) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getPolicyNo(groupName, underWrittingYear);
	}
	@Override
	public ArrayList getHospitalList(String networkCode) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getHospitalList(networkCode);
	}
	@Override
	public InsPricingVO getPolicyStatusInfo(ArrayList dataList) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getPolicyStatusInfo(dataList);
	}
	@Override
	public InsPricingVO swSelectPricingList(Long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.swSelectPricingList(lpricingSeqId);
	}
	@Override
	/*public ArrayList<InsPricingVO> getBenefitvalueAfter(Long lpricingSeqId) throws Exception {*/
		
		public ArrayList getBenefitvalueAfter(Long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getBenefitvalueAfter(lpricingSeqId);
	}
	@Override
	public int swSaveIncomeProfile(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.swSaveIncomeProfile(insPricingVO);
	}
	@Override
	public int swSaveIncomeNatProfile(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.swSaveIncomeNatProfile(insPricingVO);
	}
	@Override
	public String PricingUploadExcel(ArrayList inputData) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.PricingUploadExcel(inputData);
	}
	@Override
	public InsPricingVO generatePricingNo(Long addedBy) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.generatePricingNo(addedBy);
	}
	@Override
	public ArrayList getBenefitvalueBefore(Long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getBenefitvalueBefore(lpricingSeqId);
	}
	@Override
	public InsPricingVO swFetchScreen1(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.swFetchScreen1(insPricingVO);
	}
	@Override
	public Long deleteFile(Long FileNo,Long groupProSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.deleteFile(FileNo,groupProSeqId);
	}
	@Override
	public InsPricingVO getfalgPricingvalue(long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getfalgPricingvalue(lpricingSeqId);
	}
	@Override
	public int swsaveCensusMatAgeband(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.swsaveCensusMatAgeband(insPricingVO);
	}
	@Override
	public InsPricingVO beforeSeveCensusData(Long groupProSeqId, Long addedBy)throws Exception{
		// TODO Auto-generated method stub
		return pricinInputScreenDao.beforeSeveCensusData(groupProSeqId,addedBy);
	}
	@Override
	public InsPricingVO doViewUploadDocs(Long groupProSeqId, String fileType) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.doViewUploadDocs(groupProSeqId, fileType);
	}
	@Override
	public ArrayList getGroupList(ArrayList alSearchCriteria) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getGroupList(alSearchCriteria);
	}
	@Override
	public ArrayList getAdditionalHospitalList(String networkCode) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getAdditionalHospitalList(networkCode);
	}
	@Override
	public ArrayList getOpLimitlist(String maximumLimitdesc) throws Exception {
		// TODO Auto-generated method stub
		return pricinInputScreenDao.getOpLimitlist(maximumLimitdesc);
	}

}

package com.vidal.services.authentication;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPolicyConfigVO;
import com.vidal.command.pricing.SwPricingSummaryVO;
import com.vidal.command.pricing.WhatifScreenVO;
import com.vidal.dao.pricing.DashboardDAOimpl;
import com.vidal.dao.pricing.GrossDAO;
import com.vidal.dao.pricing.GrossDAOimpl;

@Service

public class GrossServiceImpl implements GrossService{

	@Override
	/*public int getSave(ArrayList Grosscalculate, SwPolicyConfigVO swpolicyConfigVO,SwPricingSummaryVO swPricingSummaryVO) throws Exception{
		// TODO Auto-generated method stub
		return GrossDAO.getSave(Grosscalculate,swpolicyConfigVO,swPricingSummaryVO);

	}*/
	 public InsPricingVO getfalgPricingvalue(Long lpricingSeqId) throws Exception {
		 return grossDAO.getfalgPricingvalue(lpricingSeqId);
		}
	 public InsPricingVO getfalgPricingvaluetable(Long lpricingSeqId) throws Exception {
		 return grossDAO.getfalgPricingvaluetable(lpricingSeqId);
		}
		public ArrayList[] getcpmAfterLoadingPricing(InsPricingVO insPricingVO) throws Exception{
			 return grossDAO.getcpmAfterLoadingPricing(insPricingVO);
		}
		public int calculateLoading(SwPricingSummaryVO swPricingSummaryVO)throws Exception{
			 return grossDAO.calculateLoading(swPricingSummaryVO);
		}
		
		public ArrayList getAfterLoadingData(InsPricingVO insPricingVO)throws Exception{
			
		   	 return grossDAO.getAfterLoadingData(insPricingVO);
		    }
		
		public ArrayList getBeforeLoadingData(InsPricingVO insPricingVO)throws Exception{
			
		   	 return grossDAO.getBeforeLoadingData(insPricingVO);
		    }
/*		public ArrayList calculatePlanDesignConfig(SwPolicyConfigVO swpolicyConfigVO)throws Exception{
			
		   	 return grossDAO.calculatePlanDesignConfig(swpolicyConfigVO);
		    }
		public ArrayList getcpmAfterCalcultion(InsPricingVO insPricingVO)throws Exception{
			
		   	 return grossDAO.getcpmAfterCalcultion(insPricingVO);
		    }*/
		/*public SwPolicyConfigVO getcpmAfterLoading(InsPricingVO insPricingVO)throws Exception{
			
		   	 return grossDAO.getcpmAfterLoading(insPricingVO);
		    }*/
		public void saveLoading(SwPricingSummaryVO swPricingSummaryVO)throws Exception{
			
		   	 grossDAO.saveLoading(swPricingSummaryVO);
		    }
		
	
	
	

		@Override
		public WhatifScreenVO saveEstimateChange(WhatifScreenVO whatifScreenVO) throws Exception {
			// TODO Auto-generated method stub
			return grossDAO.saveEstimateChange(whatifScreenVO);
		}


	@Override
	public WhatifScreenVO getWhatifDetails(Long groupSeqId,Long varSeqId,Long verNo,String vrsionFlag) throws Exception {
		// TODO Auto-generated method stub
		return grossDAO.getWhatifDetails(groupSeqId,varSeqId,verNo,vrsionFlag);
	}
	
	@Override
	public Long saveWhatifDetails(Long groupSeqId, Long varSeqId, Long verNo)
			throws Exception {
		// TODO Auto-generated method stub
		return grossDAO.saveWhatifDetails(groupSeqId, varSeqId, verNo);
	}
	@Override
	public Long saveWhatIfDetailsChange(Long groupSeqId, Long varSeqId, Long verNo) throws Exception {
		// TODO Auto-generated method stub
		return grossDAO.saveWhatIfDetailsChange(groupSeqId, varSeqId, verNo);
	}

	@Override
	public WhatifScreenVO getVersionSeqId(Long groupSeqId,Long verNo) throws Exception {
		// TODO Auto-generated method stub
		return grossDAO.getVersionSeqId(groupSeqId,verNo);
	}
	
	@Autowired
	GrossDAOimpl grossDAO;


	


	

}

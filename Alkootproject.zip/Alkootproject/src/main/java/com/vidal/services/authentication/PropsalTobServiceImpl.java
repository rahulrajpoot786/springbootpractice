package com.vidal.services.authentication;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwFinalQuoteVO;
import com.vidal.dao.pricing.PropsalTOBDAOImpl;

@Service
public class PropsalTobServiceImpl  implements PropsalTOBervice{

	@Override
	public String getClientName(String countyval) throws Exception {
		// TODO Auto-generated method stub
		return PropsalTobDao.getClientName(countyval);
	}
	 public SwFinalQuoteVO getfalgPricingvaluetable(Long lpricingSeqId) throws Exception {
		return null;
		}
	@Autowired
	PropsalTOBDAOImpl PropsalTobDao;
	@Override
	public SwFinalQuoteVO getfalgPricingvalue(Long group_seq_id)
			throws Exception {
		// TODO Auto-generated method stub
		 return PropsalTobDao.getfalgPricingvalue(group_seq_id);
	}
	@Override
	public int getsave(ArrayList formvalues) throws Exception {
		// TODO Auto-generated method stub
		 return PropsalTobDao.getsave(formvalues);
	}
	@Override
	public SwFinalQuoteVO getdetails(SwFinalQuoteVO swFinalQuoteVO)
			throws Exception {
		
		 return PropsalTobDao.getdetails(swFinalQuoteVO);
	}
	public int getsavepolicynumber(ArrayList formvalues) throws Exception {
		// TODO Auto-generated method stub
		return PropsalTobDao.getsavepolicynumber(formvalues);
	}


}

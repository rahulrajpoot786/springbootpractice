package com.vidal.services.pricing;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vidal.command.pricing.InsPricingVO;
import com.vidal.command.pricing.SwPolicyConfigVO;
import com.vidal.dao.pricing.PricingRiskPreimiumDAO;

@Service
public class PricingRiskPreimiumServiceImpl implements PricingRiskPreimiumService{

	@Autowired
	public PricingRiskPreimiumDAO pricingRiskPreimiumDAO;
	
	@Override
	public InsPricingVO getfalgPricingvalue(long lpricingSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.getfalgPricingvalue(lpricingSeqId);
	}

	@Override
	public ArrayList getdemographicData(InsPricingVO insPricingVO, String demographicDataFlag) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.getdemographicData(insPricingVO, demographicDataFlag);
	}

	@Override
	public ArrayList getcpmAfterCalcultion(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.getcpmAfterCalcultion(insPricingVO);
	}

	@Override
	public ArrayList getcpmBeforeCalcultion(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.getcpmBeforeCalcultion(insPricingVO);
	}

	@Override
	public ArrayList getAfterLoadingData(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.getAfterLoadingData(insPricingVO);
	}

	@Override
	public ArrayList getBeforeLoadingData(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.getBeforeLoadingData(insPricingVO);
	}

	@Override
	public SwPolicyConfigVO getcpmAfterLoading(InsPricingVO insPricingVO) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.getcpmAfterLoading(insPricingVO);
	}

	@Override
	public ArrayList calculatePlanDesignConfig(SwPolicyConfigVO swpolicyConfigVO,Long userSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.calculatePlanDesignConfig(swpolicyConfigVO,userSeqId);
	}

	@Override
	public ArrayList saveDemographicData(SwPolicyConfigVO swpolicyConfigVO,Long userSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.saveDemographicData(swpolicyConfigVO,userSeqId);
	}

	@Override
	public ArrayList calRateCalculationFnl(SwPolicyConfigVO swpolicyConfigVO, Long userSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.calRateCalculationFnl(swpolicyConfigVO,userSeqId);
	}

	@Override
	public void rateCalcProjClm(Long groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		pricingRiskPreimiumDAO.rateCalcProjClm(groupSeqId);
	}

	@Override
	public int saveRiskClaimCostComment(String comment, Long groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.saveRiskClaimCostComment(comment, groupSeqId);
	}

	@Override
	public SwPolicyConfigVO getComment(Long groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.getComment(groupSeqId);
	}

	@Override
	public String getGetProposed(Long groupSeqId) throws Exception {
		// TODO Auto-generated method stub
		return pricingRiskPreimiumDAO.getGetProposed(groupSeqId);
	}


}

package com.vidal.services.authentication;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vidal.command.usermanagement.UserSecurityProfile;
import com.vidal.command.usermanagement.UserVO;
import com.vidal.common.helper.SecurityManagerHelper;
import com.vidal.dao.authentication.AuthenticationDAOImpl;

@Service
public class AuthenticationServiceImpl implements AuthenticationService{
	@Override
	public UserSecurityProfile doAuthentication(UserVO userVO) throws Exception {
		
		return SecurityManagerHelper.getUserSecurityProfile(authenticationDAOImpl.doAuthentication(userVO));
	}
	@Override
	public int doLogout(String UserID) throws Exception {
		return authenticationDAOImpl.doLogout(UserID);
	}

	@Autowired
	AuthenticationDAOImpl authenticationDAOImpl;
}

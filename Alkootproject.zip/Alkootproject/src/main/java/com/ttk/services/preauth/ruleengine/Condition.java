/**
 * @ (#) Condition.java Jul 09, 2006
 * Project      : TTK HealthCare Services
 * File         : Condition.java
 * Author       : Unni V M
 * Company      : Span Systems Corporation
 * Date Created : Jul 09, 2006
 *
 * @author       : Unni V M
 * Modified by   :
 * Modified date :
 * Reason        :
 */

package com.ttk.services.preauth.ruleengine;

import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.dom4j.Element;
import org.dom4j.Node;

import com.vidal.common.VidalCommon;


/**
 * This Class evaluates the condtion node based on the Operator type and the Operator.
 * Updates the result attribute of the condition node based on the result of operation
 * performed. returns the updated condtion node
 *
 */
public class Condition {
	private static Logger log = Logger.getLogger( Condition.class );
    //declartion of Operator Types as constants used in the Rule
    private static final String strNUMERIC_OPERATOR="numeric";
    private static final String strNUMERIC_OPERATOR10="numeric10";
    private static final String strTWONUMERIC_OPERATOR="twonumeric";
    private static final String strNUMERIC_OPERATOR1="numeric1";
    private static final String strNUMERIC_OPERATOR3="numeric3";
    private static final String strNUMERIC_OPERATOR5="numeric5";
    private static final String strDATE_OPERATOR="date";
    private static final String strTEXT_OPERATOR="text";
    private static final String strTEXT_OPERATOR1="text1";
 //added as per regionBased 1284
    private static final String strNOTTEXT_OPERATOR="notText";//1284
    private static final String strCONTAINS ="contains";//system of medicine
    private static final String strTWOTEXT ="twotext";//system of medicine
    
    //declarations of operators as Constants used in the Rule
    private static final String strEQUAL="EQ";
    private static final String strNOT_EQUAL="NE";
    private static final String strIN="IN";
    private static final String strNOT_IN="NOTIN";
    private static final String strNOT_IN1="NOTIN1";
    private static final String strLESS_THAN="LT";
    private static final String strLESS_THAN_OR_EQUAL="LE";
    private static final String strGREATER_THAN="GT";
    private static final String strGREATER_THAN_OR_EQUAL="GE";
    private static final String strCONTAINS1 ="contains1";//Restoration of sumInsured added by vamsi
    private static final String strCONTAINS2 ="contains2";//Restoration of sumInsured added by vamsi
    private static final String strNUMERIC_OPERATOR2="numeric2";//Restoration of sumInsured added by vamsi
    private static final String strCONTAINS3 ="contains3"; //Restoration of sumInsured added by vamsi
    private static final String strCONTAINS4 ="contains4";  //Restoration of sumInsured added by vamsi
    private static final String strMULTICONTAINS ="multicontains";//Restoration of sumInsured added by vamsi
    private static final String strMULTICONTAINS1 ="multicontains1";//Restoration of sumInsured added by vamsi
    Node conditionNode = null;

    /**
     * Construtctor for initializing the condtion node
     * @param conditionNode
     */
    public Condition(Node conditionNode)
    {
        this.conditionNode = conditionNode;
    }//end of Condition(Node conditionNode)

    /**
     * This method evaluates the condtion node based on the Operator type and the Operator.
     * Updates the result attribute of the condition node based on the result of operation
     * performed. returns the updated condtion node
     *
     * @return conditionNode updated Condition node
     */
    public Node evaluate()
    {
        if(conditionNode !=null)
        {
       		String strCus =conditionNode.valueOf("@custom");
        	if(strCus.equalsIgnoreCase("CUS"))
        	{ 
            
        	((Element)(conditionNode)).addAttribute("result",conditionNode.valueOf("@output"));
             String strFieldData =conditionNode.valueOf("@fieldData");
        	
        	return conditionNode; 
        	}
            String strValue =conditionNode.valueOf("@value");
            String strOpValue =conditionNode.valueOf("@op");
            String strFieldData =conditionNode.valueOf("@fieldData");

            String strOperator=conditionNode.valueOf("@opType");

            if(strValue.equals("")||strValue.equals("~")||strValue.equals("null"))
            {
                ((Element)(conditionNode)).addAttribute("result","Rule undefined");
                return conditionNode;
            }//end of if(strValue.equals("")||strValue.equals("~")||strValue.equals("null"))

            if(strFieldData.equals("")||strFieldData.equals("~")||strFieldData.equals("null"))
            {
                ((Element)(conditionNode)).addAttribute("result","Data unavailable");
                return conditionNode;
            }//end of if(strFieldData.equals("")||strFieldData.equals("~")||strFieldData.equals("null"))

            try
            {
                boolean blnResult = false;
                if(strOperator.equals(strNUMERIC_OPERATOR))
                {
                    blnResult=doNumericOperation(strFieldData,strValue,strOpValue);
                }//end of if(strOperator.equals(strNUMERIC_OPERATOR))
                if(strOperator.equals(strNUMERIC_OPERATOR1))
                {
                    blnResult=doNumericOperation(strFieldData,strValue,strOpValue);
                }//end of if(strOperator.equals(strNUMERIC_OPERATOR))
                if(strOperator.equals(strNUMERIC_OPERATOR2))
                {
                    blnResult=doNumericOperation(strFieldData,strValue,strOpValue);
                }//end of if(strOperator.equals(strNUMERIC_OPERATOR2))
                if(strOperator.equals(strNUMERIC_OPERATOR5))
                {
                    blnResult=doNumericOperation(strFieldData,strValue,strOpValue);
                }//end of if(strOperator.equals(strNUMERIC_OPERATOR5))
                if(strOperator.equals(strNUMERIC_OPERATOR10))
                {
                    blnResult=doNumericOperation(strFieldData,strValue,strOpValue);
                }//end of if(strOperator.equals(strNUMERIC_OPERATOR10))
                if(strOperator.equals(strNUMERIC_OPERATOR3))
                {
                    blnResult=doNumericOperation(strFieldData,strValue,strOpValue);
                }//end of if(strOperator.equals(strNUMERIC_OPERATOR))
                
                if(strOperator.equals(strTWONUMERIC_OPERATOR))
                {
                    blnResult=doNumericOperation(strFieldData,strValue,strOpValue);
                }//end of if(strOperator.equals(strTWONUMERIC_OPERATOR))
                
                else if(strOperator.equals(strDATE_OPERATOR))
                {
                    blnResult=doDateOpertaion(strFieldData,strValue,strOpValue);
                }//end of else if(strOperator.equals(strDATE_OPERATOR))

                else if(strOperator.equals(strTEXT_OPERATOR))
                {
                    blnResult=doTextOperation(strFieldData,strValue,strOpValue);
                }//end of else if(strOperator.equals(strTEXT_OPERATOR))
                else if(strOperator.equals(strTEXT_OPERATOR1))
                {
                    blnResult=doTextOperation(strFieldData,strValue,strOpValue);
                }//end of else if(strOperator.equals(strTEXT_OPERATOR))
              else if(strOperator.equals(strNOTTEXT_OPERATOR))//1284 change
                {
                    blnResult=true;
                }//end of else if(strOperator.equals(strTEXT_OPERATOR))
              else if(strOperator.equals(strCONTAINS))//system of medicine
              {
            	  blnResult=doTextOperation(strFieldData,strValue,strOpValue);
              }//end of else if(strOperator.equals(strTEXT_OPERATOR))
              else if(strOperator.equals(strCONTAINS1))//system of medicine
              {
            	  blnResult=doContainsTextOperation(strFieldData,strValue,strOpValue);
              }//end of else if(strOperator.equals(strCONTAINS1))
              else if(strOperator.equals(strCONTAINS2))//system of medicine
              {
            	  blnResult=doTextOperation(strFieldData,strValue,strOpValue);
              }//end of else if(strOperator.equals(strCONTAINS2))
              else if(strOperator.equals(strCONTAINS3))//system of medicine
              {
            	  blnResult=doContainsTextOperation(strFieldData,strValue,strOpValue);
              }//end of else if(strOperator.equals(strCONTAINS3))
              else if(strOperator.equals(strCONTAINS4))//system of medicine
              {
            	  blnResult=doContainsTextOperation(strFieldData,strValue,strOpValue);
              }//end of else if(strOperator.equals(strCONTAINS4))
              else if(strOperator.equals(strTWOTEXT))//system of medicine
              {
            	  blnResult=doTextOperation(strFieldData,strValue,strOpValue);
              }//end of else if(strOperator.equals(strTEXT_OPERATOR))
              else if(strOperator.equals(strMULTICONTAINS))//system of medicine
              {
            	  blnResult=doMultiTextOperation(strFieldData,strValue,strOpValue);
              }//end of else if(strOperator.equals(strMULTICONTAINS))
              else if(strOperator.equals(strMULTICONTAINS1))//system of medicine
              {
            	  blnResult=doMultiTextOperation(strFieldData,strValue,strOpValue);
              }//end of else if(strOperator.equals(strMULTICONTAINS1))
                        
                if(blnResult)
                    ((Element)(conditionNode)).addAttribute("result","pass");
                else
                    ((Element)(conditionNode)).addAttribute("result","fail"); 
             }//try
            catch(NumberFormatException nfe)
            {
                log.error("One of the field is not numeric evaluating condition :"+conditionNode.valueOf("@id"));
                ((Element)(conditionNode)).addAttribute("result","One of the field is not numeric");
            }//end of catch(NumberFormatException nfe)
            catch(Exception Exception)
            {
                log.error("Error in Data while evaluating condition :"+conditionNode.valueOf("@id"));
                ((Element)(conditionNode)).addAttribute("result","Error in Data");
            }//end of catch(Exception Exception)
            
        }//end of if(conditionNode !=null)
       return conditionNode;
    }//end of evaluate()


    /**
     * This method will perform the Numerical comparisions on the Operands
     * based on the Operator and returns the Result
     *
     * @param strFieldData String First Operand
     * @param strValue  String Second Operand
     * @param strOpValue String Operator
     * @return blnResult boolean result of the operation performed
     */
    private boolean doNumericOperation(String strFieldData,String strValue
            ,String strOpValue) throws NumberFormatException
    {
        boolean blnResult=false;
        if(strOpValue.equals(strLESS_THAN_OR_EQUAL))
        {
            blnResult=Double.parseDouble(strFieldData) <= Double.parseDouble(strValue);
        }//end of if(strOpValue.equals(strLESS_THAN_OR_EQUAL))

        else if(strOpValue.equals(strEQUAL))
        {
            blnResult=Double.parseDouble(strFieldData) == Double.parseDouble(strValue);
        }//end of else if(strOpValue.equals(strEQUAL))

        else if(strOpValue.equals(strLESS_THAN))
        {
            blnResult=Double.parseDouble(strFieldData) < Double.parseDouble(strValue);
        }//end of else if(strOpValue.equals(strLESS_THAN))

        else if(strOpValue.equals(strGREATER_THAN_OR_EQUAL))
        {
            blnResult=Double.parseDouble(strFieldData) >= Double.parseDouble(strValue);
        }//end of else if(strOpValue.equals(strLESS_THAN))

        //added for koc 1278
        else if(strOpValue.equals(strGREATER_THAN))
        {
        	String[] FieldData = strFieldData.split(" ");
        	String[] Value = strValue.split(" ");
        	strFieldData=FieldData[0];
        	strValue=Value[0];
        	blnResult=Double.parseDouble(strFieldData) > Double.parseDouble(strValue);
        }//end of else if(strOpValue.equals(strGREATER_THAN))
        //added for koc 1278

        else if(strOpValue.equals(strNOT_EQUAL))
        {
            blnResult=Double.parseDouble(strFieldData) != Double.parseDouble(strValue);
        }//end of else if(strOpValue.equals(strNOT_EQUAL))
        return blnResult;
    }//end of doNumericOperation(String strFieldData,String strValue,String strOpValue)

    /**
     * This method will perform the date comparisions on the Operands
     * based on the Operator and returns the Result
     *
     * @param strFieldData String First Operand
     * @param strValue  String Second Operand
     * @param strOpValue String Operator
     * @return blnResult boolean result of the operation performed
     */
    private boolean doDateOpertaion(String strFieldData,String strValue,
            String strOpValue)throws Exception
    {
        boolean blnResult=false;

        java.util.Date dtDate1 = VidalCommon.getUtilDate(strFieldData);
        java.util.Date dtDate2 = VidalCommon.getUtilDate(strValue);

        if(strOpValue.equals(strLESS_THAN))
        {
            blnResult = dtDate1.compareTo(dtDate2)< 0?true:false;
        }//end of if(strOpValue.equals(strLESS_THAN))

        else if(strOpValue.equals(strLESS_THAN_OR_EQUAL))
        {
            blnResult = dtDate1.compareTo(dtDate2)<=0?true:false;
        }//end of else if(strOpValue.equals(strLESS_THAN_OR_EQUAL))

        else if(strOpValue.equals(strGREATER_THAN))
        {
            blnResult = dtDate1.compareTo(dtDate2)>0?true:false;
        }//end of else  if(strOpValue.equals(strGREATER_THAN))

        else if(strOpValue.equals(strGREATER_THAN_OR_EQUAL))
        {
            blnResult = dtDate1.compareTo(dtDate2)>=0?true:false;
        }//end of else if(strOpValue.equals(strGREATER_THAN_OR_EQUAL))

        else if(strOpValue.equals(strEQUAL))
        {
            blnResult = dtDate1.compareTo(dtDate2)==0?true:false;
        }//end of else if(strOpValue.equals(strEQUAL))

        else if(strOpValue.equals(strNOT_EQUAL))
        {
            blnResult = dtDate1.compareTo(dtDate2)!=0?true:false;
        }//end of else if(strOpValue.equals(strNOT_EQUAL))
        return blnResult;
    }//end of doDateOpertaion(String strFieldData,String strValue,String strOpValue)

    /**
     * This method will perform the text/String operations on the Operands
     * based on the Operator and returns the Result
     *
     * @param strFieldData String First Operand
     * @param strValue  String Second Operand
     * @param strOpValue String Operator
     * @return blnResult boolean result of the operation performed
     */
    private boolean doTextOperation(String strFieldData,String strValue,String strOpValue)
    {
        boolean blnResult=false;
        
        if(strOpValue.equals(strEQUAL))
        {
            blnResult=strValue.equalsIgnoreCase(strFieldData);
        }//end of if(strOpValue.equals(strEQUAL))

        else if(strOpValue.equals(strNOT_EQUAL))
        {
            blnResult=!strValue.equalsIgnoreCase(strFieldData);
        }//end of else if(strOpValue.equals(strNOT_EQUAL)) 
        else if(strOpValue.equals(strIN))
        { 
        	
        	List<String> arrAl1=Arrays.asList(strFieldData.split("[|]"));
    		
    		List<String> arrAl2=Arrays.asList(strValue.split("[|]"));
    		//boolean status=false;
    		for(String value:arrAl1){
    			
    			if(arrAl2.contains(value)){
    				blnResult=true;				
    				break;
    			}}
        	
        	
           /* StringTokenizer stFieldValues=new StringTokenizer(strFieldData,"|");
         
            while(stFieldValues.hasMoreTokens())
            {
                if(strValue.indexOf(stFieldValues.nextToken())!=-1)
                {
                    blnResult=true;
                    break;
                }//end of if(strValue.indexOf(stFieldValues.nextToken())!=-1)
            }//end of while(stFieldValues.hasMoreTokens())
*/        }//end of else if(strOpValue.equals(strIN))

        else if(strOpValue.equals(strNOT_IN))
        {
            blnResult=true;
            
          List<String> arrAl1=Arrays.asList(strFieldData.split("[|]"));
    		
    		List<String> arrAl2=Arrays.asList(strValue.split("[|]"));
    		//boolean status=false;
    		for(String value:arrAl1){
    			
    			if(arrAl2.contains(value)){
    				blnResult=false;				
    				break;
    			}}
            
                   
            /*StringTokenizer stFieldValues=new StringTokenizer(strFieldData,"|");
            while(stFieldValues.hasMoreTokens())
            {
                if(strValue.indexOf(stFieldValues.nextToken())!=-1)
                {
                    blnResult=false;
                    break;
                }//end of if(strValue.indexOf(stFieldValues.nextToken())!=-1)
            }//end of while(stFieldValues.hasMoreTokens())
*/        }//end of else if(strOpValue.equals(strNOT_IN))
      
        else if(strOpValue.equals(strNOT_IN1))
        {
            blnResult=true;
            String[] stFieldValues=strValue.split(",");
            int size = stFieldValues.length;
            for (int i=0; i<size; i++)
            {
    			if(strFieldData.equalsIgnoreCase(stFieldValues[i])){
    				 blnResult=false;
                     break;
    			}
            }
        }//end of else if(strOpValue.equals(strNOT_IN1))
 
        else if(strOpValue.equals(strIN))
        {

            List<String> arrAl1=Arrays.asList(strFieldData.split("[|]"));
            List<String> arrAl2=Arrays.asList(strValue.split("[|]"));
            //boolean status=false;
            for(String value:arrAl1){
                if(arrAl2.contains(value)){
                    blnResult=true;
                    break;
                }}
        }//end of strIN(String strFieldData,String strValue,String strOpValue)


       

        else if(strOpValue.equals(strNOT_IN))
        {
            blnResult=true;
          List<String> arrAl1=Arrays.asList(strFieldData.split("[|]"));
          List<String> arrAl2=Arrays.asList(strValue.split("[|]"));
            //boolean status=false;
            for(String value:arrAl1){
                if(arrAl2.contains(value)){
                    blnResult=false;
                    break;
                }
                }
             }//end of strNOT_IN(String strFieldData,String strValue,String strOpValue)
        return blnResult;
    }//end of doTextOperation(String strFieldData,String strValue,String strOpValue)
    
    /**
     * This method will perform the text/String operations on the Operands
     * based on the Operator and returns the Result
     *
     * @param strFieldData String First Operand
     * @param strValue  String Second Operand
     * @param strOpValue String Operator
     * @return blnResult boolean result of the operation performed
     */
    private boolean doMultiTextOperation(String strFieldData,String strValue,String strOpValue)
    {
        boolean blnResult=false;
        
        if(strOpValue.equals(strIN))
        { 
        	 blnResult=true;
    		 String[] strValues=strFieldData.split(",");
          	 int size = strValues.length;
          	 System.out.println(size);
          	  for (int i=0; i<size; i++)
              {
      			if(!strValue.contains(strValues[i])){
      				 blnResult=false;
                     break;
      			}
              }
            return blnResult;
        }//end of else if(strOpValue.equals(strIN))

        else if(strOpValue.equals(strNOT_IN))
        {
        	blnResult=true;
        //	strValue
        //	strFieldData
        	String[] strValues=strFieldData.split(",");
         	 int size = strValues.length;
         	 System.out.println(size);
         	  for (int i=0; i<size; i++)
             {
     			if(strValue.contains(strValues[i])){
     				blnResult=false;
                    break;
     			}
             }
        }//end of else if(strOpValue.equals(strNOT_IN))
        return blnResult;
    }//end of doMultiTextOperation(String strFieldData,String strValue,String strOpValue)
    /**
     * This method will perform the text/String operations on the Operands
     * based on the Operator and returns the Result
     *
     * @param strFieldData String First Operand
     * @param strValue  String Second Operand
     * @param strOpValue String Operator
     * @return blnResult boolean result of the operation performed
     */
    private boolean doContainsTextOperation(String strFieldData,String strValue,String strOpValue)
    {
        boolean blnResult=false;
        
        if(strOpValue.equals(strIN))
        { 
        	blnResult=false;
      		if(strValue.contains(strFieldData)){
      			blnResult=true;
      		}
            return blnResult;
        }//end of else if(strOpValue.equals(strIN))

        else if(strOpValue.equals(strNOT_IN))
        {
        	blnResult=true;
      		if(strValue.contains(strFieldData)){
      			blnResult=false;
      		}
        }//end of else if(strOpValue.equals(strNOT_IN))
        return blnResult;
    }//end of doContainsTextOperation(String strFieldData,String strValue,String strOpValue)

	
}//end of Condition.java
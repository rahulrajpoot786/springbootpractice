package com.ttk.services.preauth.ruleengine;




import org.dom4j.Node;


public interface IAction {
	public Node execute(Node doc) throws Exception;
}

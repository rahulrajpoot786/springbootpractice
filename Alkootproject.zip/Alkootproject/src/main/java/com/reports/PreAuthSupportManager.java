package com.reports;

public interface PreAuthSupportManager {

	
	
}

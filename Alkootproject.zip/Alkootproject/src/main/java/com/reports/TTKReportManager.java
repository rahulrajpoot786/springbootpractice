package com.reports;

import java.sql.ResultSet;
import java.util.ArrayList;

import javax.sql.DataSource;

public interface TTKReportManager {
	//public ResultSet getReport(String strProcedureName, String strParameter) throws Exception;
	public ResultSet getReport(String strProcedureName, String strParameter,DataSource dataSource) throws Exception;


	public ArrayList getReport(String strProcedureName, String strParameter,DataSource dataSource, int intIndexCursor) throws Exception;

}

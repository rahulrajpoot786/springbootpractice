package com.reports;

import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.sql.DataSource;
import javax.sql.rowset.CachedRowSet;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRField;

public class TTKReportDataSource implements JRDataSource{

	ResultSet rs = null;
    ResultSet rsArray[] = null;
	ArrayList alLoadDesignList = new ArrayList();
    TTKReportManager tTKReportManager = null;
    public void setData(CachedRowSet crs)
    {
    	rs = crs;
    }//end of setData(CachedRowSet crs)
    
    public ResultSet getResultData() throws Exception
    {
    	return rs;
    }//end of getResultData()
    public ResultSet getResultData(int index) throws Exception
    {
    	return rsArray[index];
    }//end of getResultData(int index)
    
    public boolean isResultSetArrayEmpty() throws Exception
    {
    	boolean isEmpty= true;
    	for(int index=0;index<rsArray.length;index++) {
    		if(rsArray[index].next()){
    			isEmpty = false;
    		}//end of if(rsArray[index].next())
    		rsArray[index].beforeFirst();
    	}//end of for(int index=0;index<rsArray.length;index++)
    	return isEmpty;
    }//end of isResultSetArrayEmpty()
    private TTKReportManager getTTKReportManager() throws Exception
    {
        TTKReportManager tTKReportManager = null;
        try
        {
            if(tTKReportManager == null)
            {
                InitialContext ctx = new InitialContext();
                tTKReportManager = (TTKReportManager) ctx.lookup("java:global/TTKServices/business.ejb3/TTKReportManagerBean!com.ttk.business.reports.TTKReportManager");
            }//end if
        }//end of try
        catch(Exception exp)
        {
           /* throw new TTKException(exp, "tTKReport");*/
        }//end of catch
        return tTKReportManager;
    }//end getTTKReportManager()
    public TTKReportDataSource(String strReportID ,String strParameter,DataSource dataSource) throws Exception
    {
    	tTKReportManager = TTKReportManagerBean.getInstance();
        rs = tTKReportManager.getReport(strReportID,strParameter,dataSource);
    }//end of TTKReportDataSource(String strReportID ,String strParameter)
    
    
    
  /*  public TTKReportDataSource(String strReportID ,String strParameter) throws Exception
    {
    	tTKReportManager = getTTKReportManager();
        rs = tTKReportManager.getReport(strReportID,strParameter);
    }//end of TTKReportDataSource(String strReportID ,String strParameter)
    */
   
    

  /*  public TTKReportDataSource(String strReportID ,String strParameter,DataSource dataSource) throws Exception
    {
    	tTKReportManager = TTKReportManagerBean.getInstance();
        rs = tTKReportManager.getReport(strReportID,strParameter,dataSource);
    }//end of TTKReportDataSource(String strReportID ,String strParameter)
*/    //Added for IBM....7
    //new addition added by Praveen only for IBM Reports
    public TTKReportDataSource(String strReportID ,String strParameter,DataSource dataSource,int intIndexCursor) throws Exception
    {
    	tTKReportManager = TTKReportManagerBean.getInstance();
    	alLoadDesignList = tTKReportManager.getReport(strReportID,strParameter,dataSource,intIndexCursor);
    }//end of TTKReportDataSource(String strReportID ,String strParameter,int intIndexCursor)
	@Override
	public Object getFieldValue(JRField field) throws JRException {
		// TODO Auto-generated method stub
		Object value = null;
    	String fieldName = field.getName();
    	
    	try
    	{
    	    		
    		if(fieldName.equals("Image"))
    		{
    			value=(rs.getBlob(fieldName)).getBinaryStream();
    		}
    		else if("CLOB_DATA".equalsIgnoreCase(fieldName)){

                StringBuilder sb=new StringBuilder();

                Reader reader=rs.getCharacterStream(fieldName);
                if(reader!=null){

                    int charData;
                    while((charData=reader.read())!=-1)sb.append((char)charData);
                }

                value=sb.toString();
            } 
    		else{    		
    			value=rs.getObject(fieldName);
    			
    		}
    	}//end of try
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}//end of catch
    	return value;
	}

	@Override
	public boolean next() throws JRException {
		// TODO Auto-generated method stub
		try
        {
            if(rs.next()){
                return true;
            }//end of if
            else{
                return false;
            }//end of else
        }//end of try
        catch(SQLException exp)
        {
            return false;
        }//end of catch(SQLException exp);
	}
	
	public ArrayList getResultSetList() throws Exception
    {
    	return alLoadDesignList;
    }
	
	public void setResultData(CachedRowSet[] crs) throws Exception
    {
    	rsArray=crs;
    }
	

}

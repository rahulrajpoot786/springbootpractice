package com.reports;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jndi.JndiTemplate;
import org.springframework.stereotype.Repository;

import com.vidal.common.ResourceManager;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.rowset.OracleCachedRowSet;

//@Repository
public class TTKReportDAOImpl implements Serializable {
	
	private static TTKReportDAOImpl daoImpl;
	private TTKReportDAOImpl(){
	}
	
	public static TTKReportDAOImpl getInstance() 
    { 
        if (daoImpl==null) 
        	daoImpl = new TTKReportDAOImpl(); 
        return daoImpl; 
    }
	
	@Autowired
	private DataSource dataSource;

	 private static String strVIEW_INPUT_SUMMARY= "PRICING_APP_PKG.GENERATE_QUOTE";
		private static String strSERVERUSERCOUNT = "PRE_CLM_REPORTS_PKG.Server_usercount_letter";
		private static String strTOB="PRICING_APP_PKG.generate_tob";
		 private static String strVIEW_QUOTATION= "PRICING_APP_PKG. generate_pol_copy"; 
		 private static String strVIEW_What_Report= "PRICING_APP_PKG.get_whatif_print"; 
		 private static String strgroupid= "PRICING_APP_PKG.get_pricing_report"; 
		 
		//private static String strPR_HOSP_DOC_RCVD_REPORT = "HOSPITAL_EMPANEL_REPORTS_PKG.PR_HOSP_DOC_RCVD_REPORT";

	
	public ResultSet getReport(String strReportID, String strParameter,DataSource dataSource) throws Exception {
		
		ResultSet rs = null;
		Connection con = null;
	
		String strProcedureName = "";
		
		strProcedureName = getProcedureName(strReportID);
		

		if (strProcedureName == null) {
			

		} // end of if(strProcedureName==null)
		 OracleCachedRowSet crs = null;
		 crs = new OracleCachedRowSet();
			 con = dataSource.getConnection();
	      
	            String strCall = "{CALL "+strProcedureName.trim()+"(?,?)}";
	           
	           
	            crs = new OracleCachedRowSet();
	          
	      
	          try (
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCall);) {
	            cStmtObject.setString(1,strParameter);
	            cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
	            cStmtObject.execute();
	            rs = (java.sql.ResultSet) cStmtObject.getObject(2); 
	            
	            if(rs !=null)
	            {       
	            	crs.populate(rs);
	            	 
	            }//end of if(rs !=null)
	            return crs;
	        //end of try
		}catch(Exception e) {
			e.printStackTrace();
			
		}finally {
			con.close();
			rs.close();
		}
		
		  return crs;
	}// end of getReport(String strReportID,String strParameter)
		// Added for IBM....9.2
	
	   public ArrayList getReport(String strReportID,String strParameter,DataSource dataSource, int intNoOfCursors) throws Exception {

	        //Connection con = null;
//	        ResultSet rs[] = null;
	        String strProcedureName="";
	        strProcedureName =getProcedureName(strReportID);
	    //    String strCall = "{CALL "+strProcedureName.trim()+"(?,?,?,?,?,?)}";


	        String strCall = "{CALL "+strProcedureName.trim();
	        String strParameters = "(?";
	        for(int i=0;i<intNoOfCursors;i++){ //one more for OUT parameter for batch seq id
	            strParameters += ",?";
	        }//end of for(int i=0;i<intNoOfCursors+1;i++)
	        strParameters += ")}";
	        strCall += strParameters;

	 
	        //end of if(strProcedureName==null)
//	        OracleCachedRowSet crs[] = null;

	            ArrayList resultValues=new ArrayList();
	         
	            if(strReportID.equals("whatReportId")) {

	         try (     Connection con = dataSource.getConnection();
//	                 Connection con = dataSource.getConnection();
	                 CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCall);) {



//	                crs = new OracleCachedRowSet[5];
	            //    con = ResourceManager.getConnection();//getTestConnection();
	           //     cStmtObject = (java.sql.CallableStatement)con.prepareCall(strCall);
	                cStmtObject.setString(1,strParameter);
	            
	                for(int i=2;i<5;i++){
	                    if(i<5){
	                      
	cStmtObject.registerOutParameter(i,OracleTypes.CURSOR);
	                    }

	                }//end of for(int i=5;i<intNoOfCursors+5;i++)

	                cStmtObject.execute();
	                    try(ResultSet generalResulSet= (java.sql.ResultSet) cStmtObject.getObject(2);
	                    ResultSet benefitResulSet= (java.sql.ResultSet) cStmtObject.getObject(3);
	                    ResultSet maternityResulSet= (java.sql.ResultSet) cStmtObject.getObject(4);)

	                    {

	                        OracleCachedRowSet cachedRowSet[]=new OracleCachedRowSet[4];
	                        cachedRowSet[0]=new OracleCachedRowSet();
	                        cachedRowSet[1]=new OracleCachedRowSet();
	                        cachedRowSet[2]=new OracleCachedRowSet();
	                        cachedRowSet[3]=new OracleCachedRowSet();
	                        cachedRowSet[0].populate(generalResulSet);
	                        cachedRowSet[1].populate(benefitResulSet);
	                        cachedRowSet[2].populate(maternityResulSet);

	                        resultValues.add(cachedRowSet[0]);
	                        resultValues.add(cachedRowSet[1]);
	                        resultValues.add(cachedRowSet[2]);


	                    }
	                }//end of for(int index=0;index<intNoOfCursors;index++)

	         catch (Exception e) {
	             e.printStackTrace();            // TODO: handle exception
	        }

	            }else if (strReportID.equals("groupReport")) {
	              

	       	         try (     Connection con = dataSource.getConnection();
//	       	                 Connection con = dataSource.getConnection();
	       	                 CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCall);) {



//	       	                crs = new OracleCachedRowSet[5];
	       	            //    con = ResourceManager.getConnection();//getTestConnection();
	       	           //     cStmtObject = (java.sql.CallableStatement)con.prepareCall(strCall);
	       	                cStmtObject.setString(1,strParameter);
	       	            
	       	                for(int i=2;i<8;i++){
	       	                    if(i<8){
	       	                     
	       	cStmtObject.registerOutParameter(i,OracleTypes.CURSOR);
	       	                    }

	       	                }//end of for(int i=5;i<intNoOfCursors+5;i++)

	       	                cStmtObject.execute();
	       	                    try(ResultSet group1= (java.sql.ResultSet) cStmtObject.getObject(2);
	       	                    ResultSet group2= (java.sql.ResultSet) cStmtObject.getObject(3);
	       	                    ResultSet group3= (java.sql.ResultSet) cStmtObject.getObject(4);
	       	                    ResultSet group4= (java.sql.ResultSet) cStmtObject.getObject(5);
	       	                    ResultSet group5= (java.sql.ResultSet) cStmtObject.getObject(6);
	       	                    ResultSet group6= (java.sql.ResultSet) cStmtObject.getObject(7);)

	       	                    {

	       	                        OracleCachedRowSet cachedRowSet[]=new OracleCachedRowSet[6];
	       	                        cachedRowSet[0]=new OracleCachedRowSet();
	       	                        cachedRowSet[1]=new OracleCachedRowSet();
	       	                        cachedRowSet[2]=new OracleCachedRowSet();
	       	                        cachedRowSet[3]=new OracleCachedRowSet();
	       	                        cachedRowSet[4]=new OracleCachedRowSet();
	       	                        cachedRowSet[5]=new OracleCachedRowSet();
	       	                        
	       	                        
	       	                        cachedRowSet[0].populate(group1);
	       	                        cachedRowSet[1].populate(group2);
	       	                        cachedRowSet[2].populate(group3);
	       	                        cachedRowSet[3].populate(group4);
	       	                        cachedRowSet[4].populate(group5);
	       	                        cachedRowSet[5].populate(group6);

	       	                        resultValues.add(cachedRowSet[0]);
	       	                        resultValues.add(cachedRowSet[1]);
	       	                        resultValues.add(cachedRowSet[2]);
	       	                        resultValues.add(cachedRowSet[3]);
	       	                        resultValues.add(cachedRowSet[4]);
	       	                        resultValues.add(cachedRowSet[5]);


	       	                    }
	       	                }//end of for(int index=0;index<intNoOfCursors;index++)

	       	         catch (Exception e) {
	       	             e.printStackTrace();            // TODO: handle exception
	       	        }

	       	            }
					
				
	            
	            
	            else {

	         try (     Connection con = dataSource.getConnection();
//	                 Connection con = dataSource.getConnection();
	                 CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCall);) {



//	                crs = new OracleCachedRowSet[5];
	            //    con = ResourceManager.getConnection();//getTestConnection();
	           //     cStmtObject = (java.sql.CallableStatement)con.prepareCall(strCall);
	                cStmtObject.setString(1,strParameter);
	             
	                for(int i=2;i<intNoOfCursors+2;i++){
	                    if(i<=5){
	                       
	cStmtObject.registerOutParameter(i,OracleTypes.CURSOR);
	                    }
	                    else{
	                       
	cStmtObject.registerOutParameter(i,OracleTypes.NUMBER);
	                    }
	                }//end of for(int i=5;i<intNoOfCursors+5;i++)

	                cStmtObject.execute();
	                    try(ResultSet generalResulSet= (java.sql.ResultSet) cStmtObject.getObject(2);
	                    ResultSet benefitResulSet= (java.sql.ResultSet) cStmtObject.getObject(3);
	                    ResultSet maternityResulSet= (java.sql.ResultSet) cStmtObject.getObject(4);
	                    ResultSet premiumResulSet= (java.sql.ResultSet) cStmtObject.getObject(5);)
	                    {
	                        int firstFlag= cStmtObject.getInt(6);
	                        int secondFlag= cStmtObject.getInt(7);
	                        OracleCachedRowSet cachedRowSet[]=new OracleCachedRowSet[4];
	                        cachedRowSet[0]=new OracleCachedRowSet();
	                        cachedRowSet[1]=new OracleCachedRowSet();
	                        cachedRowSet[2]=new OracleCachedRowSet();
	                        cachedRowSet[3]=new OracleCachedRowSet();
	                        cachedRowSet[0].populate(generalResulSet);
	                        cachedRowSet[1].populate(benefitResulSet);
	                        cachedRowSet[2].populate(maternityResulSet);
	                        cachedRowSet[3].populate(premiumResulSet);
	                        resultValues.add(cachedRowSet[0]);
	                        resultValues.add(cachedRowSet[1]);
	                        resultValues.add(cachedRowSet[2]);
	                        resultValues.add(cachedRowSet[3]);
	                        resultValues.add(firstFlag);
	                        resultValues.add(secondFlag);
	                    }
	                }//end of for(int index=0;index<intNoOfCursors;index++)

	         catch (Exception e) {
	             e.printStackTrace();            // TODO: handle exception
	        }
	            }
	                return (ArrayList) resultValues;
	     //       }//end of if(strReportID.equals("TPACommissionRpt"))

	    //    }

	        }


	
   
   /* public ArrayList getReport(String strReportID,String strParameter,DataSource dataSource, int intNoOfCursors) throws Exception {

    	//Connection con = null;
//    	ResultSet rs[] = null;
    	String strProcedureName="";
    	strProcedureName =getProcedureName(strReportID);
    //    String strCall = "{CALL "+strProcedureName.trim()+"(?,?,?,?,?,?)}";
    	
    	
    	String strCall = "{CALL "+strProcedureName.trim();
        String strParameters = "(?";
        for(int i=0;i<intNoOfCursors;i++){ //one more for OUT parameter for batch seq id 
        	strParameters += ",?";
        }//end of for(int i=0;i<intNoOfCursors+1;i++)
        strParameters += ")}";
        strCall += strParameters;
    	
   System.out.println("strCall..."+strCall);
    	//end of if(strProcedureName==null)
//    	OracleCachedRowSet crs[] = null;
    	
    		ArrayList resultValues=new ArrayList();

    	 try ( 	Connection con = dataSource.getConnection();
//    			 Connection con = dataSource.getConnection();
 				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCall);) {
   
               
                
//                crs = new OracleCachedRowSet[5];
            //    con = ResourceManager.getConnection();//getTestConnection();
           //     cStmtObject = (java.sql.CallableStatement)con.prepareCall(strCall);
                cStmtObject.setString(1,strParameter);
               System.out.println("strParameter :"+strParameter);
                for(int i=2;i<intNoOfCursors+2;i++){
                	if(i<=5){
                		System.out.println("i for CVUrsor  "+i);
                	cStmtObject.registerOutParameter(i,OracleTypes.CURSOR);
                	}
                	else{
                		System.out.println("i for number  "+i);
                		cStmtObject.registerOutParameter(i,OracleTypes.NUMBER);	
                	}
                }//end of for(int i=5;i<intNoOfCursors+5;i++)
               
                cStmtObject.execute();
                	try(ResultSet generalResulSet= (java.sql.ResultSet) cStmtObject.getObject(2);
                	ResultSet benefitResulSet= (java.sql.ResultSet) cStmtObject.getObject(3);
                	ResultSet maternityResulSet= (java.sql.ResultSet) cStmtObject.getObject(4);
                	ResultSet premiumResulSet= (java.sql.ResultSet) cStmtObject.getObject(5);)
                	{
                		int firstFlag= cStmtObject.getInt(6);
                    	int secondFlag= cStmtObject.getInt(7);
                    	OracleCachedRowSet cachedRowSet[]=new OracleCachedRowSet[4];
                    	cachedRowSet[0]=new OracleCachedRowSet();
                    	cachedRowSet[1]=new OracleCachedRowSet();
                    	cachedRowSet[2]=new OracleCachedRowSet();
                    	cachedRowSet[3]=new OracleCachedRowSet();
                    	cachedRowSet[0].populate(generalResulSet);
                    	cachedRowSet[1].populate(benefitResulSet);
                    	cachedRowSet[2].populate(maternityResulSet);
                    	cachedRowSet[3].populate(premiumResulSet);
                    	resultValues.add(cachedRowSet[0]);
                    	resultValues.add(cachedRowSet[1]);
                    	resultValues.add(cachedRowSet[2]);
                    	resultValues.add(cachedRowSet[3]);
                    	resultValues.add(firstFlag);
                    	resultValues.add(secondFlag);
                	}
                }//end of for(int index=0;index<intNoOfCursors;index++)
    	 catch (Exception e) {
    		 e.printStackTrace();			// TODO: handle exception
		}
    	 
    	 
                return (ArrayList) resultValues;   
     //       }//end of if(strReportID.equals("TPACommissionRpt"))
    
    //	}
	
    	}
*/
	/*public ResultSet getReport(String strReportID, String strParameter,DataSource dataSource, int indexCursor) throws Exception {
  System.out.println("new....");
	
		ResultSet rs = null;
		String strProcedureName = "";
		
		Connection con = null;
		strProcedureName = getProcedureName(strReportID);
		if (strProcedureName == null) {

		} // end of if(strProcedureName==null)


		 OracleCachedRowSet crs = null;
		 crs = new OracleCachedRowSet();
			 con = dataSource.getConnection();
	      
	            String strCall = "{CALL "+strProcedureName.trim()+"(?,?,?,?,?,?)}";
	           
	            System.out.println("strReportID::::::::::::::"+strReportID);
	            crs = new OracleCachedRowSet();
	      
	          try (
				CallableStatement cStmtObject = (java.sql.CallableStatement) con.prepareCall(strCall);) {
	            cStmtObject.setString(1,strParameter);
	            cStmtObject.registerOutParameter(2,OracleTypes.CURSOR);
	            cStmtObject.registerOutParameter(3,OracleTypes.CURSOR);
	            cStmtObject.registerOutParameter(4,OracleTypes.CURSOR);
	            cStmtObject.registerOutParameter(5,OracleTypes.CURSOR);
	            cStmtObject.registerOutParameter(6,OracleTypes.CURSOR);
			cStmtObject.execute();
			rs = (java.sql.ResultSet) cStmtObject.getObject(indexCursor);
			if (rs != null) {
				crs.populate(rs);
			} // end of if(rs !=null)
			return crs;

		}

	}// end of getReport(String strReportID,String strParameter)
*/
	private String getProcedureName(String strReportID) {

/*		if (strReportID.equals("ImportantNotesClaimNote")) {
			return (strImportantNotesClaimNote);
		}
		if (strReportID.equals("ClaimNote")) {
			return (strClaimNote);
		} // end of if(strReportID.equals("viewClaimNote"))
*/		if(strReportID.equals("ViewInputPricing"))
		{
			return(strVIEW_INPUT_SUMMARY);
		}

if(strReportID.equals("groupReport"))
{
	return(strgroupid);
}
      if(strReportID.equals("TOB"))
      {
	return(strTOB);
      }
      if(strReportID.equals("PolicyCopy"))
		{
			return(strVIEW_QUOTATION);
		}
      if(strReportID.equals("GenerateQauotation"))
		{
			return(strVIEW_QUOTATION);
		}
      if(strReportID.equals("whatReportId"))
      {
          return(strVIEW_What_Report);
      } 

		if (strReportID.equals("severUserCount")) {
			return (strSERVERUSERCOUNT);
		} // end of if(strReportID.equals("severUserCount"))
	else {
			return ("");
		} // end of else
	}// end of getProcedureName(String strReportID)

	
	
	
	
	
	/*public DataSource getDbSource() {
		DataSource dataSource = null;
		JndiTemplate jndi = new JndiTemplate();
		try {
			dataSource = jndi.lookup("java:/VingsConnectionDataSource", DataSource.class);
		} catch (NamingException e) {
			// logger.error("NamingException for java:comp/env/jdbc/yourname", e);
		}
		return dataSource;
	}*/
	
	
}

package com.reports;

import java.sql.ResultSet;
import java.util.ArrayList;

import javax.sql.DataSource;

public class TTKReportManagerBean implements TTKReportManager{
	TTKReportDAOImpl tTKReportDAOImpl = TTKReportDAOImpl.getInstance();
	
	private static TTKReportManagerBean bean;
	private TTKReportManagerBean(){
	}
	public static TTKReportManagerBean getInstance() 
    { 
        if (bean==null) 
        	bean = new TTKReportManagerBean(); 
        return bean; 
    }
	@Override
	public ResultSet getReport(String strProcedureName, String strParameter,DataSource dataSource) throws Exception {
		  return tTKReportDAOImpl.getReport(strProcedureName,strParameter,dataSource);
	}
	
	 
	 public ArrayList getReport(String strProcedureName,String strParameter,DataSource dataSource,int intIndexCursor) throws Exception {
	        return tTKReportDAOImpl.getReport(strProcedureName,strParameter,dataSource,intIndexCursor);
	    }//end of getReport(String strProcedureName,String strParameter,int intIndexCursor)
	 
	/* public ResultSet getReport(String strProcedureName,String strParameter) throws Exception {
	        return tTKReportDAOImpl.getReport(strProcedureName,strParameter);
	    }//
*/
}
